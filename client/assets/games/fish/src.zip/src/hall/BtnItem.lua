
local BtnItem = class("BtnItem", cc.load("mvc").ViewBase)

BtnItem.AUTO_RESOLUTION   = 0
BtnItem.RESOURCE_FILENAME = "ui/hall/button/uibtn_hall"
BtnItem.RESOURCE_BINDING  = {  
 
    ["spr_light"] = { ["varname"] = "spr_light" },    
    ["btn"]       = { ["varname"] = "btn" }, 
    ["image_bg"]  = { ["varname"] = "image_bg" }, 
    ["text_word"] = { ["varname"] = "text_word" }, 

}

function BtnItem:onCreate(...)   
    self:runAction(self.resourceNode_["animation"])
    self.animation = self.resourceNode_["animation"]

    self.image_bg:setVisible(false)

end

function BtnItem:setBtnPic(path)
    if path == nil or path == "" then
        return false
    end
    self.btn:loadTextureNormal(path,0)
    self.btn:loadTexturePressed(path,0)
    self.btn:loadTextureDisabled(path,0)

    return true
end

function BtnItem:setBtnCallBack( backFun )
    if backFun == nil then
        backFun = function ( ... )end
    end
    self.btn:onClickDarkEffect(backFun)
end

function BtnItem:playAct( actName,isFov )
    self.animation:play(actName,isFov)
end

function BtnItem:lightAct(isAct)
    self.spr_light:setVisible(isAct)
    if isAct == true then
        self.spr_light:runAction(cc.RepeatForever:create(cc.RotateBy:create(1,FishCD.LIGHT_SPEED)))
    else
        self.spr_light:stopAllActions()
    end
end

--设置按键状态  0.没光，不跳   1.有光，不跳   2.没光，跳动   3.有光，跳动
function BtnItem:setBtnState(state)
    if state == 0 then
        self:lightAct(false)
        self:playAct("nojump",false)
    elseif state == 1 then
        self:lightAct(true)
        self:playAct("nojump",false)
    elseif state == 2 then
        self:lightAct(false)
        self:playAct("jump",true)
    elseif state == 3 then
        self:lightAct(true)
        self:playAct("jump",true)
    end
end

--倒计时
function BtnItem:setBtnCountDown(seconds,callBack)
    if callBack == nil then
        callBack = function ( ... )end
    end
    self:setBtnState(0)
    self.btn:setTouchEnabled(false)
    self.btn:setBright(false)
    self.image_bg:setVisible(true)
    local time = FishGF.getFormatTimeBySeconds(seconds)
    self.text_word:setString(time)
    self.seconds = seconds
    local function delayFunc()
        if self.seconds <= 0 then
            callBack()
            self:stopBtnCountDown()
        else
            self.seconds = self.seconds-1
            self.text_word:setString(FishGF.getFormatTimeBySeconds(self.seconds))
        end
    end
    local act = cc.RepeatForever:create(cc.Sequence:create(cc.DelayTime:create(1), cc.CallFunc:create(delayFunc)))
    act:setTag(11011)
    self.text_word:stopActionByTag(11011)
    self.text_word:runAction(act)
end

--停止倒计时
function BtnItem:stopBtnCountDown()
    self.image_bg:setVisible(false)
    self.btn:setTouchEnabled(true)
    self.btn:setBright(true)
    self.seconds = 0
    self.text_word:stopAllActions()
    self:setBtnState(3)
end

return BtnItem;
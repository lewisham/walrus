﻿
local HallBg = class("HallBg", cc.load("mvc").ViewBase)
--local netMsgTab = require("Other.NetMsgType")

HallBg.AUTO_RESOLUTION   = true
HallBg.RESOURCE_FILENAME = "ui/hall/uihallbg"
HallBg.RESOURCE_BINDING  = {
    ["spr_hall_bg"]        = { ["varname"] = "spr_hall_bg"  },
    ["node_light"]            = { ["varname"] = "node_light"  },
    ["node_bg"]            = { ["varname"] = "node_bg"  },
   
}

function HallBg:onCreate( ... )
    self:runAction(self.resourceNode_["animation"])
    self.resourceNode_["animation"]:play("wave_act", true);
    self.animation = self.resourceNode_["animation"]

    self:initBg()

end

--初始化背景
function HallBg:initBg()

    -- --播放粒子特效文件1  
    -- local emitter1 = FishGI.GameEffect.createBubble(1) 
    -- emitter1:setPosition(cc.p(139.52*self.scaleX_,-13.92*self.scaleY_))
    -- self.node_bg:addChild(emitter1,0)  

    -- --播放粒子特效文件2
    -- local emitter2 = FishGI.GameEffect.createBubble(1) 
    -- emitter2:setPosition(cc.p(967.39*self.scaleX_,-35.27*self.scaleY_))
    -- self.node_bg:addChild(emitter2,0)

    self.node_light.animation:play("light_act",true)

end


return HallBg;
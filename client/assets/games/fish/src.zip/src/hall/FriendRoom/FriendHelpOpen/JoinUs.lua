local JoinUs = class("JoinUs", cc.load("mvc").ViewBase)

JoinUs.AUTO_RESOLUTION   = false
JoinUs.RESOURCE_FILENAME = "ui/hall/friend/friendhelpopen/uijoinus"
JoinUs.RESOURCE_BINDING  = {
    ["panel"]            = { ["varname"] = "panel" },
    ["img_bg"]           = { ["varname"] = "img_bg"  },
    ["spr_page_0"]       = { ["varname"] = "spr_page_0"  },
    ["spr_page_1"]       = { ["varname"] = "spr_page_1"  },
    ["spr_page_2"]       = { ["varname"] = "spr_page_2"  },
    ["spr_contact_tips"] = { ["varname"] = "spr_contact_tips"  },
    ["spr_wxh"]          = { ["varname"] = "spr_wxh"  },
    ["text_wxh"]         = { ["varname"] = "text_wxh"  },
    ["pageview_show"]    = { ["varname"] = "pageview_show", ["nodeType"]="viewlist"},
    
    ["btn_copy"]         = { ["varname"] = "btn_copy" ,           ["events"]={["event"]="click",["method"]="onClickCopy"}},
    ["btn_close"]        = { ["varname"] = "btn_close" ,           ["events"]={["event"]="click",["method"]="onClickClose"}},

}

function JoinUs:onCreate(...)
    self.pageview_show:addEventListener(handler(self, self.pageviewEvent))
    self.pageview_show:setIndicatorEnabled(true);
    self.pageview_show:setIndicatorIndexNodesScale(0.5);
    local oldPos = self.pageview_show:getIndicatorPosition();
    self.pageview_show:setIndicatorPosition(cc.p(oldPos.x, oldPos.y-40));
    self.pageview_show:setIndicatorSpaceBetweenIndexNodes(10);
    self.pageview_show:stopAutoScroll();
    self.text_wxh:setString(WECHAT_ACCOUNT);

    self:openTouchEventListener()

    local function callfunc(res)
        local imgTag = res.data;
        if imgTag ~= nil then
            for key, val in pairs(imgTag) do
                local fileurl = FishGI.imageDownload:Start(val, function(ret_path,err_msg)
                    if ret_path then
                        self:addPage(ret_path);
                    end
                end)
                
            end
        end
    end

    FishGI.Dapi:getJoinUsImgAddr(callfunc)
    self:setDotSelected(0);

end

function JoinUs:onTouchBegan(touch, event)
    if not self:isVisible() then
         return false
    end
    return true
end


function JoinUs:addPage(path)
    local spr = cc.Sprite:create(path)
    if spr == nil then
        print("------------JoinUs:addPage-----path is no exist-------------")
        return 
    end
    local viewSize = self.pageview_show:getContentSize();
    local layout = ccui.Layout:create();
    layout:setBackGroundImage(path, 0);
    layout:setBackGroundImageScale9Enabled(true);

    layout:setBackGroundImageCapInsets(cc.rect(0, 0, spr:getContentSize().width, spr:getContentSize().height));

    self.pageview_show:addPage(layout);
    self.nativeSize = table.maxn(self.pageview_show:getItems());
end

function JoinUs:turnRight()
    local currentIndex = self.pageview_show:getCurrentPageIndex();
    self:setDotSelected(currentIndex)
end

function JoinUs:turnLeft()
    local currentIndex = self.pageview_show:getCurrentPageIndex();
    self:setDotSelected(currentIndex)

end

function JoinUs:pageviewEvent(sender,eventType)
    local touchBegPos = sender:getTouchBeganPosition();
    local touchEndPos = sender:getTouchEndPosition();
    if touchEndPos.x > touchBegPos.x then
        self:turnRight();
    else
        self:turnLeft();
    end
end

function JoinUs:setDotSelected(index)
    local key = 0;
    while true do
        local dot = self["spr_page_"..key];
        if dot == nil then
            break;
        end
        dot:setColor(cc.c3b(197, 198, 198));
        key = key+1;
    end

    local spr = self["spr_page_"..index]
    if spr ~= nil then
        spr:setColor(cc.c3b(58, 0, 146));
    end

end

function JoinUs:onClickCopy(sender)
    FishGF.copy(self.text_wxh:getString());
end

function JoinUs:onClickClose(sender)
    self:hideLayer()
end

return JoinUs;
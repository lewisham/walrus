﻿
local FriendRoom = class("FriendRoom", cc.load("mvc").ViewBase)

FriendRoom.AUTO_RESOLUTION   = true
FriendRoom.RESOURCE_FILENAME = "ui/hall/friend/uifriendroom"
FriendRoom.RESOURCE_BINDING  = {
    ["node_fr_btn"]       = { ["varname"] = "node_fr_btn"  },
    ["node_friendroom"]   = { ["varname"] = "node_friendroom"  },
    
    ["panel_create"]      = { ["varname"] = "panel_create"} , 
    ["panel_enter"]       = { ["varname"] = "panel_enter"  },    
    ["panel_helpopen"]    = { ["varname"] = "panel_helpopen"  },
    
    ["btn_rule"]          = { ["varname"] = "btn_rule" ,         ["events"]={["event"]="click_color",["method"]="onClickrule"}}, 
    ["btn_record"]        = { ["varname"] = "btn_record" ,       ["events"]={["event"]="click_color",["method"]="onClickrecord"}}, 
    ["btn_prop_1001"]     = { ["varname"] = "btn_prop_1001" ,    ["events"]={["event"]="click_color",["method"]="onClickprop_1001"}}, 
    ["btn_prop_13"]       = { ["varname"] = "btn_prop_13" ,      ["events"]={["event"]="click_color",["method"]="onClickprop_13"}}, 
    
    ["btn_heplopenrcord"] = { ["varname"] = "btn_heplopenrcord" ,         ["events"]={["event"]="click",["method"]="onClickhelpopenrcord"}}, 
    ["btn_league"]        = { ["varname"] = "btn_league" ,         ["events"]={["event"]="click",["method"]="onClickleague"}}, 
    
}

--底部的按键
FriendRoom.DOWN_BTN  = {
    { ["varname"] = "btn_prop_13"},   
    { ["varname"] = "btn_record"}, 
    { ["varname"] = "btn_rule"}, 
    { ["varname"] = "btn_heplopenrcord"},
    { ["varname"] = "btn_league"},
    { ["varname"] = "btn_prop_1001"},   
}

--中间的大图标
FriendRoom.BigRoomPanel  = {
    {["varname"] = "panel_create",["newScale"] = 1,["newPosX"] = -270,},
    {["varname"] = "panel_enter",["newScale"] = 1,["newPosX"] = 270,},
    {["varname"] = "panel_helpopen",["newScale"] = 1,["newPosX"] = 600,},
}

function FriendRoom:onCreate( ... )
    self.node_friendroom:setScale(self.scaleMin_)
    self.propData = {}
    self.isShow = nil
    self.curType = 0 --0没有状态   1.创建    2.加入
    FishGI.FRIEND_ROOMNO = nil
    self:setIsCurShow(false)
    self:openTouchEventListener(false)

    self.node_fr_btn:setScale(self.scaleMin_)

    local node_fish_create = self.panel_create:getChildByName("node_fish")
    node_fish_create.animation:play("roomact", true);

    local node_fish_enter = self.panel_enter:getChildByName("node_fish")
    node_fish_enter.animation:play("roomact", true);

    local node_fish_helpopen = self.panel_helpopen:getChildByName("node_fish")
    node_fish_helpopen.animation:play("roomact", true);

    self:updatePropData(13,0)
    self:updatePropData(1001,0)

    for k,v in pairs(self.BigRoomPanel) do
        local panel = self[v.varname]
        if panel ~= nil then
            panel.oldScale = panel:getScale()
            panel.oldPosX = panel:getPositionX()
            panel.newScale = v.newScale
            panel.newPosX = v.newPosX
        end
    end

    self:setIsCanHelpOpen(false)

    self:setBtnIsShow("btn_prop_1001",false)
end

--设置能否代开
function FriendRoom:setIsCanHelpOpen( isCanHelpOpen )
    print("----------------------FriendRoom:setIsCanHelpOpen-----------isCanHelpOpen="..tostring(isCanHelpOpen))
    if isCanHelpOpen then
        self.panel_helpopen:setVisible(true)
        for k,v in pairs(self.BigRoomPanel) do
            local panel = self[v.varname]
            if panel ~= nil then
                panel:setScale(panel.oldScale)
                panel:setPositionX(panel.oldPosX)
            end
        end
        self.btn_heplopenrcord:setVisible(true)
        self.btn_league:setVisible(true)
    else
        self.panel_helpopen:setVisible(false)
        for k,v in pairs(self.BigRoomPanel) do
            local panel = self[v.varname]
            if panel ~= nil then
                panel:setScale(panel.newScale)
                panel:setPositionX(panel.newPosX)
            end
        end
        self.btn_heplopenrcord:setVisible(false)
        self.btn_league:setVisible(false)
    end
    self:updateBtnPos()
end

function FriendRoom:onTouchBegan(touch, event)
    if self.isShow then
        return true
    end
    return false  
end

function FriendRoom:onTouchEnded(touch, event)
    print("-----panel_onTouchEnd-------")
    local curPos = touch:getLocation()
    local s1 = self.panel_create:getContentSize()
    local locationInNode1 = self.panel_create:convertToNodeSpace(curPos)
    local rect1 = cc.rect(0,0,s1.width,s1.height)
    local curType = 0
    if cc.rectContainsPoint(rect1,locationInNode1) then
        print("-----panel_create-------")
        -- local resuleData,canUsedCount = self:isAllowCreate()
        -- if  resuleData == nil or canUsedCount < 1 then
        --     local function callback(sender)
        --         local tag = sender:getTag()
        --         if tag == 2 then --ok
        --             FishGI.hallScene.uiBagLayer:showLayer(FishCD.PROP_TAG_13) 
        --         end
        --         FishGF.backToHall( )
        --     end
        --     FishGF.showMessageLayer(FishCD.MODE_MIDDLE_OK_CLOSE,FishGF.getChByIndex(800000285),callback, nil)
        --     return 
        -- end      

        FishGI.hallScene.uiCreateLayer:showLayer()
    end

    local s2 = self.panel_enter:getContentSize()
    local locationInNode2 = self.panel_enter:convertToNodeSpace(curPos)
    local rect2 = cc.rect(0,0,s2.width,s2.height)
    if cc.rectContainsPoint(rect2,locationInNode2) then
        print("-----panel_enter-------")
        self:setChooseType(2)
    end

    if self.panel_helpopen:isVisible() then
        local s3 = self.panel_helpopen:getContentSize()
        local locationInNode3 = self.panel_helpopen:convertToNodeSpace(curPos)
        local rect3 = cc.rect(0,0,s3.width,s3.height)
        if cc.rectContainsPoint(rect3,locationInNode3) then
            print("-----panel_helpopen-------")
            if FishGI.hallScene.uiHelpOpenLayer ~= nil then
                FishGI.hallScene.uiHelpOpenLayer:sendNetData("running") 
                FishGI.hallScene.uiHelpOpenLayer:sendNetData("StartMonitor")
            end
        end
    end

end

--1.创建房间   2.加入房间
function FriendRoom:setChooseType( curType,needCount)
    if curType == 1 then
        local resuleData,canUsedCount = self:isAllowCreate()
        if  needCount > 0 and (resuleData == nil or canUsedCount < needCount) then
            local function callback(sender)
                local tag = sender:getTag()
                if tag == 2 then --ok
                    --FishGI.hallScene.uiBagLayer:showLayer(FishCD.PROP_TAG_13) 
                    FishGI.hallScene.uiShopLayer:showLayer() 
                end
                FishGF.backToHall( )
            end
            FishGF.showMessageLayer(FishCD.MODE_MIDDLE_OK_CLOSE,FishGF.getChByIndex(800000285),callback, nil)
            return 
        end        
    elseif curType == 2 then


    end

    if curType ~= 0 then
        self.curType = curType
        self.friendRoomNo = nil
        self.friendGameId = nil
        FishGI.FriendRoomManage:sendGetFriendStatus();
    end

end

--判断是否能创建房间
function FriendRoom:isAllowCreate( )
    local resuleData = nil
    if FishGI.isFreeOpenFriend == true then
        resuleData = {}
        resuleData.propId = 0
        return resuleData,100000
    end
    --判断限时房卡是否有以及能用
    local playerData = FishGMF.getPlayerData(FishGI.myData.playerId)
    local limitCardS = playerData.seniorProps[tostring(FishCD.PROP_TAG_15)]
    local canUsedCount = 0
    if limitCardS ~= nil then
        for k,v in pairs(limitCardS) do
            local time = v.stringProp
            local date = os.date("%Y-%m-%d");
            if date == time then
                resuleData = v
                canUsedCount = canUsedCount + 1
            end
        end
    end

    --普通房卡
    local roomCardCount = playerData["props"][tostring(FishCD.PROP_TAG_13)]
    if roomCardCount ~= nil and roomCardCount > 0 then
        local data = {}
        data.propId = FishCD.PROP_TAG_13
        resuleData = data
        canUsedCount = canUsedCount + roomCardCount
    end
    return resuleData,canUsedCount

end

--设置是否返回大厅
function FriendRoom:setIsCurShow( isShow,isAct )
    if isShow == self.isShow then
        return
    end
    if isShow == true then
        self:setVisible(true)
    end
    for k,v in pairs(self.DOWN_BTN) do
        local node = self[v.varname]
        FishGF.setNodeIsShow(node,"down",isShow,nil,isAct)
    end

    FishGF.setNodeIsShow(self.node_friendroom,"up",isShow ,display.height,isAct)

    if not isShow then
        self.curType = 0
        self.friendRoomNo = nil
        self.friendGameId = nil
    end

    self.isShow = isShow

end

-- --返回普通场大厅
-- function FriendRoom:backToHall(  )
--     FishGF.print("------FriendRoom:backToHall-返回普通场大厅-----")
--     --返回原来的服务器
--     if FishGI.FRIEND_ROOM_STATUS ~= 0 then
--         FishGI.FRIEND_ROOM_STATUS = 4
--         FishGI.FRIEND_ROOMID = nil
--         FishGI.isExitRoom = true
--         self.curType = 0
--         FishGI.hallScene.net:dealloc();
--         FishGI.loginScene.net:DoAutoLogin();
--     end
-- end

--规则介绍
function FriendRoom:onClickrule( sender )
    print("onClickrule")
    FishGI.hallScene.uiRuleIntroduction:showLayer()
end

--历史记录
function FriendRoom:onClickrecord( sender )
    print("onClickrecord")
    FishGI.FriendRoomManage:sendGetFriendHistory()
end

--临时房卡
function FriendRoom:onClickprop_1001( sender )
    print("onClickprop_1001")
    if self.propData[FishCD.PROP_TAG_15] ~= nil and self.propData[FishCD.PROP_TAG_15] > 0 then
        FishGF.showSystemTip(nil,800000234,3)
    else
        FishGI.hallScene.uiMonthcard:showLayer()
    end
    
end

--房卡
function FriendRoom:onClickprop_13( sender )
    print("onClickprop_13")
    --FishGI.hallScene.uiBagLayer:showLayer(FishCD.PROP_TAG_13) 
    FishGI.hallScene.uiShopLayer:showLayer() 
end

--代开记录
function FriendRoom:onClickhelpopenrcord( sender )
    print("onClickhelpopenrcord")
    local userId = FishGI.hallScene.net:getUserId();
    FishGF.openWebWithClose("http://page.jiaxianghudong.com/fishReplaceRoom/index?user_id="..userId, FishGI.hallScene, "hall/rank/rank_pic_title_dkjl.png");
end

--加盟
function FriendRoom:onClickleague(sender)
    print("onClickleague")
    FishGI.hallScene.uiJoinUs:showLayer()
end

--创建朋友场
function FriendRoom:createFriendRoom(  )
    print("createFriendRoom")
    self.curType = 1
    self.friendRoomNo = nil
    self.friendGameId = nil
    FishGI.FriendRoomManage:sendGetFriendStatus();
end

--进入朋友场
function FriendRoom:enterFriendRoom( friendRoomNo ,friendGameId)
    print("enterFriendRoom")
    self.friendRoomNo = friendRoomNo
    self.friendGameId = friendGameId
    self.curType = 2
    --FishGI.FriendRoomManage:sendGetFriendStatus();
    self:OnChangeFriendServery(self.serverList)
    
end

--获取朋友场状态
function FriendRoom:onGetFriendStatus( netData )
    print("onGetFriendStatus")
    FishGI.isFriendStateInitEnd = true
    local data = netData
    local errorCode = netData.errorCode
    local friendStatus = netData.friendStatus
    local unreadFriendGameId = netData.unreadFriendGameId
    self.serverList = netData.serverList

    if friendStatus == 1 then           --上一场未开始
        self:unStartFriend(netData)

    elseif friendStatus == 2 then       --正在游戏中
        self:playingFriend(netData)

    elseif friendStatus == 3 then       --上一场未结算
        self:leaveFriend(netData)
        if FishGI.isUserInitEnd == true then
            FishGF.handleOpenUrl_()
        end
    elseif friendStatus == 4 and unreadFriendGameId ~= "" then       --不在游戏中,有未读
        self:unreadFriend(netData)
        if FishGI.isUserInitEnd == true then
            FishGF.handleOpenUrl_()
        end
        
    elseif friendStatus == 4 and unreadFriendGameId == "" then       --不在游戏中
        self:freeFriend(netData)
        if FishGI.isUserInitEnd == true then
            FishGF.handleOpenUrl_()
        end
    end

end

--选择服务器
function FriendRoom:choseServer(serverList)
    local serverList = serverList
    if #serverList <=0 then
        return nil
    end
    
    local roomId = nil
    if self.curType == 1 then
        --创建房间随机进入
        local index = math.random(1,#serverList)
        roomId = serverList[index].roomId
    elseif self.curType == 2 then
        --加入房间，筛选房间
        local friendRoomNo =  self.friendRoomNo
        local prefix = string.sub(friendRoomNo,0,2);
        for k,val in pairs(serverList) do
            if val.prefix == prefix then
                roomId = val.roomId
                break
            end
        end
    end

    return roomId

end

--切换服务器创建房间
function FriendRoom:OnChangeFriendServery(serverList)

    local roomId = self:choseServer(serverList)
    if roomId == nil then
        if self.curType == 1 then
            FishGF.showToast(FishGF.getChByIndex(800000298))
        elseif self.curType == 2 then
            local str = FishGF.getChByIndex(800000286)
            if #serverList <=0 then
                str = FishGF.getChByIndex(800000298)
            end
            local function callback(sender)
                local tag = sender:getTag()
                if tag == 0 then
                    self.curType = 2
                    self.friendRoomNo = nil
                    self.friendGameId = nil
                    FishGI.FriendRoomManage:sendGetFriendStatus();                
                end
            end   
            FishGF.showMessageLayer(FishCD.MODE_MIN_OK_ONLY,str,callback);
        end
        return
    end
    FishGF.print("-------------------------FishGI.FRIEND_ROOMID--roomId="..roomId)
    FishGI.FRIEND_ROOM_STATUS = self.curType
    if FishGI.FRIEND_ROOMID == nil or FishGI.FRIEND_ROOMID ~= roomId then
        FishGF.waitNetManager(true,nil,"ChangeServery")
    end
    self.curType = 0
    FishGI.FRIEND_ROOMID = roomId
    FishGI.isExitRoom = true
    FishGI.hallScene.net:dealloc();
    FishGI.loginScene.net:DoAutoLogin();

end

--服务器准备好了
function FriendRoom:OnFriendServerReady(data)
    print("-----FriendRoom-OnFriendServerReady-----")
   if FishGI.FRIEND_ROOM_STATUS == 1 and not FishGI.hallScene.uiCreateSuceed:isVisible() then
        --申请创建房间
        local createData = FishGI.hallScene.uiCreateLayer.createData
        FishGI.FriendRoomManage:sendCreateFriendRoom(createData.roomPropType,createData.roomPeopleCountType,createData.roomDurationType,createData.agent,createData.roomCardType)
   elseif FishGI.FRIEND_ROOM_STATUS == 2 then
        --直接加入房间
        self:sendJoinFriendRoom()
   end
end

--创建朋友场
function FriendRoom:OnCreateFriendRoom(netData)
    print("-----FriendRoom-OnCreateFriendRoom-----")
    local success = netData.success
    local friendRoomNo = netData.friendRoomNo
    local deskId = netData.deskId
    local free = netData.free
    if success then
        local agent = netData.agent
        local createData = FishGI.hallScene.uiCreateLayer.createData
        local newData = FishGI.GameTableData:getFriendCreateData("roomDurationType",createData.roomDurationType)
        local cardCount = newData.cardCount
        if free == nil then
            free = false
        end
        if free == false and (not agent) and createData.roomCardType == 0 then
            --界面减个数
            local limitCardCount = self.propData[FishCD.PROP_TAG_15]
            if limitCardCount > cardCount then
                self:updatePropData(FishCD.PROP_TAG_15,limitCardCount - cardCount)
            else
                self:updatePropData(FishCD.PROP_TAG_15,0)
                FishGMF.addTrueAndFlyProp(FishGI.myData.playerId,FishCD.PROP_TAG_13,-(cardCount - limitCardCount ),true)
            end
        end

        if agent == true then
            FishGF.backToHall()
            FishGI.hallScene.uiHelpOpenLayer:showLayer()
            return
        end

        self.friendRoomNo = friendRoomNo
        --弹出提示面板
        FishGI.hallScene.uiCreateSuceed:setRoomNo(friendRoomNo)
        FishGI.hallScene.uiCreateSuceed:showLayer()

        return
    end

    local errorCode = netData.errorCode
    if errorCode == 1 then                 --已经在房间
        FishGF.showToast(FishGF.getChByIndex(800000283))
    elseif errorCode == 2 then             --无可用房间
        FishGF.showToast(FishGF.getChByIndex(800000284))
    elseif errorCode == 4 then             --朋友场服务器已关闭
        FishGF.showToast(FishGF.getChByIndex(800000298))
    elseif errorCode == 5 then             --参数不合法
        FishGF.showToast(FishGF.getChByIndex(800000332))
    elseif errorCode == 3 then             --无房卡
        local function callback(sender)
            local tag = sender:getTag()
            if tag == 2 then --ok
                --FishGI.hallScene.uiBagLayer:showLayer(FishCD.PROP_TAG_13) 
                FishGI.hallScene.uiShopLayer:showLayer() 
            end
            FishGF.backToHall( )
        end
        FishGF.showMessageLayer(FishCD.MODE_MIDDLE_OK_CLOSE,FishGF.getChByIndex(800000285),callback, nil)
    elseif errorCode == 6 then             --使用平台房卡创建房间失败的错误原因
        FishGF.showToast(netData.webMsg)
        FishGF.backToHall( )
    end
end

--申请加入朋友场
function FriendRoom:sendJoinFriendRoom()
    print("-----FriendRoom-sendJoinFriendRoom-----")  
    FishGI.FRIEND_ROOMNO = self.friendRoomNo
    FishGI.FriendRoomManage:sendJoinFriendRoom(self.friendRoomNo,self.friendGameId)

end

--加入朋友场结果
function FriendRoom:OnJoinFriendRoom(data)
    print("-----FriendRoom-OnJoinFriendRoom-----")
    local success = data.success
    if success then
        FishGI.FRIEND_ROOMNO = self.friendRoomNo
        return
    end

    local str = ""
    local errorCode = data.errorCode
    if errorCode == 1 then              --桌子不存在
        str = FishGF.getChByIndex(800000286)
    elseif errorCode == 2 then             --游戏已开始
        str = FishGF.getChByIndex(800000287)
    elseif errorCode == 3 then           --游戏已结束
        str = FishGF.getChByIndex(800000288)
    elseif errorCode == 4 then           --玩家已经离开
        str = FishGF.getChByIndex(800000289)
    elseif errorCode == 5 then           --桌子已经满了
        str = FishGF.getChByIndex(800000290)
    elseif errorCode == 6 then           --朋友场服务器已关闭
        str = FishGF.getChByIndex(800000298)
    else                                --未知错误
        FishGF.print("------errorCode="..errorCode)
        str = FishGF.getChByIndex(800000291)..errorCode
    end

    FishGF.showToast(str)

    -- if FishGI.FRIEND_ROOM_STATUS == 1 then
    --     FishGF.showToast(str)
    -- elseif FishGI.FRIEND_ROOM_STATUS == 2 then
    --     local function callback(sender)
    --         local tag = sender:getTag()
    --         if tag == 0 then
    --             self.curType = 2
    --             self.friendRoomNo = nil
    --             self.friendGameId = nil
    --             FishGI.FriendRoomManage:sendGetFriendStatus();                
    --         end
    --     end   
    --     FishGF.showMessageLayer(FishCD.MODE_MIN_OK_ONLY,str,callback);
    -- end
    FishGF.waitNetManager(false,nil,"sendDataGetDesk")
    FishGI.FRIEND_ROOMNO = nil
    --返回正常服务器
    FishGF.backToHall( )  

end



--==============================--
--desc:朋友场的状态处理
--time:2017-05-10 11:30:06
--==============================--


--有未开始的游戏中的朋友场处理   1
function FriendRoom:unStartFriend(netData)
    print("-----FriendRoom-unStartFriend-----")
    --重新加入或者解散
    local friendRoomNo = netData.friendRoomNo
    local friendGameId = netData.friendGameId
    local function callback(sender)
        local tag = sender:getTag()
        if tag == 2 then --ok
            --加入房间
            self.friendRoomNo = friendRoomNo
            self.friendGameId = friendGameId
            self.curType = 2
            self:OnChangeFriendServery(netData.serverList)

        elseif tag == 3 then --cancel
            --发送解散消息
            FishGI.FriendRoomManage:sendFriendLeaveGame(friendGameId)
            if FishGI.isUserInitEnd == true then
                FishGF.handleOpenUrl_()
            end
        end
    end
    FishGF.showMessageLayer(FishCD.MODE_MIDDLE_OK_CLOSE,FishGF.getChByIndex(800000248),callback, nil)

end

--有正在游戏中的朋友场处理    2
function FriendRoom:playingFriend(netData)
    print("-----FriendRoom-playingFriend-----")
    --重新加入或者主动退出
    local friendRoomNo = netData.friendRoomNo
    local friendGameId = netData.friendGameId
    local function callback(sender)
        local tag = sender:getTag()
        if tag == 2 then --ok
            --加入房间
            self.friendRoomNo = friendRoomNo
            self.friendGameId = friendGameId
            self.curType = 2
            self:OnChangeFriendServery(netData.serverList)

        elseif tag == 3 then --cancel
            --发送强退
            FishGI.FriendRoomManage:sendFriendLeaveGame(friendGameId)
            if FishGI.isUserInitEnd == true then
                FishGF.handleOpenUrl_()
            end
        end
    end
    FishGF.showMessageLayer(FishCD.MODE_MIDDLE_OK_CLOSE,FishGF.getChByIndex(800000249),callback, nil)

end

--有上一场未结算的朋友场处理    3
function FriendRoom:leaveFriend(netData)
    print("-----FriendRoom-leaveFriend-----")
    --稍等，不能加入或创建
    if self.isShow and self.curType ~= 0 then
        --弹出提示
        print("------稍等，不能加入或创建-----")
        FishGF.showMessageLayer(FishCD.MODE_MIDDLE_OK_ONLY,FishGF.getChByIndex(800000251),nil, nil)
        return
    end

end

--有结算未读的朋友场处理  4
function FriendRoom:unreadFriend(netData)
    print("-----FriendRoom-unreadFriend-----")
    --一定查看，是否弹面板自己处理
    local friendRoomNo = netData.friendRoomNo
    local friendGameId = netData.unreadFriendGameId
    local function callback(sender)
        local tag = sender:getTag()
        if tag == 2 then --ok
            --设置已读，查询详细信息
            --FishGI.FriendRoomManage:sendGetFriendDetail(friendGameId)
            FishGI.FriendRoomManage:sendFriendMarkAsRead(friendGameId)
            FishGI.FriendRoomManage:sendGetFriendHistory()
            
        elseif tag == 3 then --cancel
            --设置已读
            FishGI.FriendRoomManage:sendFriendMarkAsRead(friendGameId)
        end
    end
    FishGF.showMessageLayer(FishCD.MODE_MIDDLE_OK_CLOSE,FishGF.getChByIndex(800000250),callback, nil)

end

--正常，不在游戏中  4
function FriendRoom:freeFriend(netData)
    print("-----FriendRoom-freeFriend-----")

    --在朋友场场景内加入游戏或者创建游戏
    if self.isShow then
        if self.curType == 1 then
            --切换服务器创建房间
            self:OnChangeFriendServery(netData.serverList)
        elseif self.curType == 2 then
            -- 弹出输入面板
            FishGI.hallScene.uiJoinRoom:showLayer()
        end
    end
end

--更新道具数量
function FriendRoom:updatePropData(propId,showCount)
    self.propData[propId] = showCount
    local node = self["btn_prop_"..propId]
    if node ~= nil then
        local fnt = node:getChildByName("fnt_count")
        fnt:setString(showCount)
        if FishGI.hallScene.uiCreateLayer ~= nil then
            FishGI.hallScene.uiCreateLayer:updatePropData(propId,showCount)
        end
    end
end

--设置是否免费开房
function FriendRoom:setFreeOpen(isFriendFree,friendFreeTimeStart,friendFreeTimeEnd)
    if isFriendFree == nil then
        return 
    end
    --isFriendFree = false
    local isFree = isFriendFree
    local startTime = friendFreeTimeStart
    local endTime = friendFreeTimeEnd
    local node_fish = self.panel_create:getChildByName("node_fish")
    local spr_free_act = node_fish:getChildByName("title"):getChildByName("spr_free_act")
    local node_activity = node_fish:getChildByName("title"):getChildByName("node_activity")

    FishGI.isFreeOpenFriend = isFree
    FishGI.hallScene.uiCreateLayer:setFreeOpen(isFree)
    self:setBtnIsShow("btn_prop_13",not isFree)
    if not isFree then
        spr_free_act:setVisible(false)
        node_activity:setVisible(false)
        return 
    else
        spr_free_act:setVisible(true)
        node_activity:setVisible(true)        
    end
    
    local panel = node_activity:getChildByName("panel")
    local text_start = panel:getChildByName("text_start")
    local text_end = panel:getChildByName("text_end")
    text_start:setString(FishGF.getChByIndex(800000369)..":"..startTime)
    text_end:setString(FishGF.getChByIndex(800000370)..":"..endTime)

    node_activity:setVisible(false)

    
end

function FriendRoom:setBtnIsShow( btnName,isShow )
    local btn = self[btnName]
    if btn == nil then
        return 
    end

    btn:setVisible(isShow)
    self:updateBtnPos()
end

function FriendRoom:updateBtnPos( )

    local leftPos = 80
    local index = 0
    local dis = 130
    for i,v in ipairs(self.DOWN_BTN) do
        local node = self[v.varname]
        if node ~= nil and node:isVisible() then
            local posX = leftPos + index*dis
            node:setPositionX(posX)
            index = index + 1
        end
    end
end

return FriendRoom;
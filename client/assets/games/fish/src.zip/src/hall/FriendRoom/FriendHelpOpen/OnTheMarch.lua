local OnTheMarch = class("OnTheMarch", cc.load("mvc").ViewBase)
local MAX_ROOM_NUM = 4

OnTheMarch.AUTO_RESOLUTION   = false
OnTheMarch.RESOURCE_FILENAME = "ui/hall/friend/friendhelpopen/uionthemarch"
OnTheMarch.RESOURCE_BINDING  = {
    ["panel"]              = { ["varname"] = "panel" },
    ["img_bg"]             = { ["varname"] = "img_bg"  },
    ["line"]               = { ["varname"] = "line"  },
    
    ["text_name_title"]    = { ["varname"] = "text_name_title"  },    
    ["text_roomid_title"]  = { ["varname"] = "text_roomid_title"} , 
    ["text_roomid"]        = { ["varname"] = "text_roomid"  },   
    ["text_duration"]      = { ["varname"] = "text_duration"  },
    ["text_openroom_time"] = { ["varname"] = "text_openroom_time"  }, 
    
    ["btn_roomrule"]       = { ["varname"] = "btn_roomrule" ,         ["events"]={["event"]="click",["method"]="onClickRule"}},
    ["btn_dissolution"]    = { ["varname"] = "btn_dissolution" ,         ["events"]={["event"]="click",["method"]="onClickDissolution"}}, 
    ["btn_invitation"]     = { ["varname"] = "btn_invitation" ,         ["events"]={["event"]="click",["method"]="onClickInvitation"}}, 
    
    ["node_head1"]         = { ["varname"] = "node_head1"  },
    ["node_head2"]         = { ["varname"] = "node_head2"  },
    ["node_head3"]         = { ["varname"] = "node_head3"  },
    ["node_head4"]         = { ["varname"] = "node_head4"  },
}

function OnTheMarch:onCreate(...)
    self:productPlayerHead(MAX_ROOM_NUM);

    self.btn_dissolution.firstPosX = self.btn_dissolution:getPositionX()
    self.btn_invitation.firstPosX = self.btn_invitation:getPositionX()
end

function OnTheMarch:productPlayerHead(num)
    self.headTab = {};

    local mode = require("common/HeadStyleSimple")
    for key = 1, num do
        local node = self["node_head"..key]
        --self:runAction(self["node_head"..key].animation)
        node = mode.new(self, node)
        self["node_head"..key] = node
        node:switchNull();
        node:setId(key);
        table.insert(self.headTab, node);
        local btn = node.btn_click
        btn:onClickDarkEffect(self:handler(self,self.onClickkick))
    end
end

function OnTheMarch:getHeadByLocalId(localId)
    if self.headTab == nil then
        return nil;
    end

    for key, val in pairs(self.headTab) do
        local id = val:getId();
        if localId == id then
            return val;
        end
    end
end

function OnTheMarch:getHeadByPlayerId(playerId)
    if self.headTab == nil then
        return nil;
    end

    for key, val in pairs(self.headTab) do
        local id = val:getPlayerId();
        if playerId == id then
            return val;
        end
    end
end

function OnTheMarch:setRoomId(roomId)
    self.text_roomid:setString(roomId);
end

function OnTheMarch:getRoomId()
    return tonumber(self.text_roomid:getString());
end

function OnTheMarch:setRoomDuration(duration)
    self.text_duration:setString(duration);
end

function OnTheMarch:getRoomDuration()
    return self.text_duration:getString();
end

function OnTheMarch:setRoomOpenTime(openTime)
    self.text_openroom_time:setString(openTime);
end

function OnTheMarch:getRoomOpenTime()
    return self.text_openroom_time:getString();
end

function OnTheMarch:setRoomMaxPlayerNum(num)
    self.maxPlayerNum = num;
    for key = 1, MAX_ROOM_NUM do
        local head = self:getHeadByLocalId(key);
        if key <= self.maxPlayerNum then
            if head ~= nil then
                head:setVisible(true);
            end
        else
            if head ~= nil then
                head:setVisible(false);
            end
        end
    end
end

function OnTheMarch:getRoomMaxPlayerNum()
    return self.maxPlayerNum;
end

function OnTheMarch:setInfo(roomInfo)
    self.roomInfo = roomInfo
    self.friendGameId = roomInfo.friendGameId;
    local friendRoomNo = roomInfo.friendRoomNo;
    local duration = roomInfo.duration;
    local createTime = roomInfo.createTime;
    local playerCount = roomInfo.playerCount

    self:setRoomMaxPlayerNum(playerCount)
    self:setRoomId(friendRoomNo);
    self:setRoomDuration(duration);
    self:setRoomOpenTime(createTime);

    self:setIsOpenWecaht(FishGI.isOpenWechat)
end

function OnTheMarch:setIsOpenWecaht(isOpen)
    if isOpen == false then
        self.btn_invitation:setVisible(false)
        local posx = (self.btn_dissolution.firstPosX + self.btn_invitation.firstPosX)/2
        self.btn_dissolution:setPositionX(posx)
    else
        self.btn_invitation:setVisible(true)
        self.btn_dissolution:setPositionX(self.btn_dissolution.firstPosX)
    end
end

function OnTheMarch:playerJoinRoom(info)
    local localId = info.chairId + 1;
    local headPath = info.path;
    local playerId = info.playerId;
    local name = info.name;
    local isReady = info.isReady
    local score = info.score

    if localId > self.maxPlayerNum then
        return;
    end

    local head = self:getHeadByLocalId(localId);
    if head == nil then
        return nil;
    end
    head:setPlayerId(playerId);
    head:setName(name);
    head:setHead(headPath);
    head:setIsReady(isReady);
    head:switchWithoutScoreMode();
end

function OnTheMarch:playerExitRoomByChairId(chairId)
    local head = self:getHeadByLocalId(chairId)
    if head ~= nil then
        head:switchNull();
        head:setIsReady(false);
    end
end

function OnTheMarch:playerExitRoom(playerId)
    local head = self:getHeadByPlayerId(playerId);
    if head ~= nil then
        head:switchNull();
        head:setIsReady(false);
    end
end

function OnTheMarch:playerIsReady(playerId,isReady)
    local head = self:getHeadByPlayerId(playerId)
    if head ~= nil then
        head:setIsReady(isReady)
    end
end

function OnTheMarch:onClickkick(sender)
    print("-----------onClickkick-----------")
    local playerId = sender.playerId
    if playerId == nil then
        return 
    end
    print("-----------onClickkick-----------playerId="..playerId)
    
end

function OnTheMarch:onClickRule(sender)
    local event = cc.EventCustom:new("openRuleTip")
    event._userdata = self.roomInfo
    local pos,size = FishGF.getWordPosAndSizeByNode(self)
    event._userdata.pos = pos
    cc.Director:getInstance():getEventDispatcher():dispatchEvent(event)
end

function OnTheMarch:onClickDissolution(sender)
    if self.friendGameId ~= nil then
        local function callback(sender)
            local tag = sender:getTag()
            if tag == 2 then
                FishGI.FriendRoomManage:sendFriendDissolveRoom(self.friendGameId)
            end
        end
        local str = FishGF.getChByIndex(800000383)
        FishGF.showMessageLayer(FishCD.MODE_MIDDLE_OK_CLOSE,str,callback);
    else
        print("----------friendGameId == nil------------")
    end
    
end

function OnTheMarch:onClickInvitation(sender)
    local createData = FishGI.hallScene.uiCreateLayer.createData
    FishGF.InviteFriend(self.roomInfo.friendRoomNo,FishGI.myData.nickName,createData.roomPropType,createData.roomPeopleCountType,createData.roomDurationType)
end

return OnTheMarch;

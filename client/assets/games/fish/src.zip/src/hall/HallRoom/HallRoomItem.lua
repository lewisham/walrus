
local HallRoomItem = class("HallRoomItem", cc.load("mvc").ViewBase)

HallRoomItem.AUTO_RESOLUTION   = false
HallRoomItem.RESOURCE_FILENAME = "ui/hall/hallroom/uihallroom1"
HallRoomItem.RESOURCE_BINDING  = {
    ["panel"]       = { ["varname"] = "panel" ,},
    ["btn_click"]   = { ["varname"] = "btn_click" ,}, 

}

function HallRoomItem:onCreate( ... )
    self:initAct()
end


function HallRoomItem:initAct( )
    self:stopAllActions()
    self:runAction(self.resourceNode_["animation"])
    self.resourceNode_["animation"]:play("room_act", true)

end

function HallRoomItem:setBtnCallBack( callback )
    if callback == nil then
        callback = function ( ... ) end
    end
    self.btn_click:onClickDarkEffect(callback)
end

function HallRoomItem:setIsCurShow( isShow,isAct,actTime )
    if isShow == self.isSow then
        return 
    end
    self.isSow = isShow
    self.panel:stopAllActions()
    if isAct ~= nil and isAct == false then
        if isShow then
            self.panel:setOpacity(255)
        else
            self.panel:setOpacity(0)
        end
    else
        if isShow then
            self.panel:runAction(cc.FadeTo:create(actTime,255))
        else
            self.panel:runAction(cc.FadeTo:create(actTime,0))
        end
    end
end

return HallRoomItem;
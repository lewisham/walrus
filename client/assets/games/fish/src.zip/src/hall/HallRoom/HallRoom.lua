
local HallRoom = class("HallRoom", cc.load("mvc").ViewBase)

HallRoom.AUTO_RESOLUTION   = false
HallRoom.RESOURCE_FILENAME = "ui/hall/hallroom/uihallroom"
HallRoom.RESOURCE_BINDING  = {
    ["panel"]          = { ["varname"] = "panel" ,},

    ["node_normal"]    = { ["varname"] = "node_normal" ,}, 
    ["node_friend"]    = { ["varname"] = "node_friend" ,}, 
    ["node_treasure"]  = { ["varname"] = "node_treasure" ,}, 
    ["node_smallgame"] = { ["varname"] = "node_smallgame" ,}, 
}

function HallRoom:onCreate( ... )

    --添加触摸监听
    self:openTouchEventListener()
    
    local mode = require("hall/HallRoom/HallRoomItem")
    self.node_normal = mode.new(self, self.node_normal)
    self.node_normal:setBtnCallBack(handler(self,self.onClicknormal))

    self.node_friend = mode.new(self, self.node_friend)
    self.node_friend:setBtnCallBack(handler(self,self.onClickfriend))

    self.node_treasure = mode.new(self, self.node_treasure)
    self.node_treasure:setBtnCallBack(handler(self,self.onClicktreasure))

    self.node_smallgame = mode.new(self, self.node_smallgame)
    self.node_smallgame:setBtnCallBack(handler(self,self.onClicksmallgame))

    self.roomList = {}
    table.insert( self.roomList,self.node_normal )
    table.insert( self.roomList,self.node_friend )
    table.insert( self.roomList,self.node_treasure )
    table.insert( self.roomList,self.node_smallgame )

    for k,v in pairs(self.roomList) do
        v.firstPos = cc.p(v:getPositionX(),v:getPositionY())
        v.firstScale = v:getScale()
    end
end

function HallRoom:onTouchBegan(touch, event)

end

function HallRoom:onClicknormal( sender )
    print("--------onClicknormal--------")
    FishGI.hallScene:setRoomType(1)
end

function HallRoom:onClickfriend( sender )
    print("--------onClickfriend--------")
    --朋友场
    local result = FishGF.judgeIsCanEnterFriend()
    if result == false then
        return 
    end
    FishGI.hallScene:updateFriendHelpOpen()
    
    FishGI.hallScene:setRoomType(2)
end

function HallRoom:onClicktreasure( sender )
    print("--------onClicktreasure--------")
    FishGI.hallScene:setRoomType(4)
end

function HallRoom:onClicksmallgame( sender )
    print("--------onClicksmallgame--------")
    FishGI.hallScene:setRoomType(3)
end

function HallRoom:setIsCurShow( isShow,isAct )
    print("--------setIsCurShow--------")
    if isShow == self.isSow then
        return 
    end
    self.isSow = isShow
    self:stopAllActions()
    if isShow then
        local showTime = FishCD.HALL_SHOW_TIME*2
        -- self:setOpacity(0)
        -- self:setScale(0)
        local swq = cc.Spawn:create(cc.ScaleTo:create(showTime,self.scaleMin_),cc.FadeTo:create(showTime,255))
        local seq = cc.Sequence:create(cc.Show:create(),swq)
        self:runAction(seq)
        for i,v in ipairs(self.roomList) do
            v:setIsCurShow(isShow,isAct,showTime)
        end
    else
        local hideTime = FishCD.HALL_SHOW_TIME
        -- self:setOpacity(255)
        -- self:setScale(self.scaleMin_)
        local swq = cc.Spawn:create(cc.ScaleTo:create(hideTime,0),cc.FadeTo:create(hideTime,0))
        local seq = cc.Sequence:create(swq,cc.Hide:create())
        self:runAction(seq)
        for i,v in ipairs(self.roomList) do
            v:setIsCurShow(isShow,isAct,hideTime)
        end
    end
end

function HallRoom:setAreaShow( nodeName,isShow )
    local node = self[nodeName]
    if node == nil then
        return 
    end
    node:setVisible(isShow)

end

return HallRoom;
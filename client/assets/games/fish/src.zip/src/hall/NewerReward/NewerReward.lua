local NewerReward = class("NewerReward", cc.load("mvc").ViewBase)

NewerReward.AUTO_RESOLUTION   = false
NewerReward.RESOURCE_FILENAME = "ui/hall/newerreward/uinewerreward"
NewerReward.RESOURCE_BINDING  = {    
    ["panel"]      = { ["varname"] = "panel"} , 
    ["node_list"]  = { ["varname"] = "node_list"} , 
    ["btn_get"]    = { ["varname"] = "btn_get" ,         ["events"] = {["event"] = "click",["method"] = "onClickget"}}, 
    ["spr_all_bg"] = { ["varname"] = "spr_all_bg"} ,
    
}

function NewerReward:onCreate( ... )
    self:openTouchEventListener()
    
    self.animation = self.resourceNode_["animation"]
    self:runAction(self.animation)
    self.animation:play("run_act",true)
    
    local eventDispatcher = self:getEventDispatcher()
    local GetNewerReward = cc.EventListenerCustom:create("onGetNewerReward", handler(self, self.onGetNewerReward))
    eventDispatcher:addEventListenerWithSceneGraphPriority(GetNewerReward, self)
    
    self:initView()

    self.curStates = 0         --0未领取且为申请   1.申请中   2.申请完播放动画   3.动画播放完
end

function NewerReward:initView(  )
    local propList = FishGI.GameTableData:getLVRewardData(0)
    local count = #propList
    local dis = 148
    local posLeft = dis*(count -1)/2
    for i,v in ipairs(propList) do
        local propId = v.propId
        local propCount = v.propCount
        local spr = self:createProp(propId,propCount)
        self.node_list:addChild(spr)
        self["prop_"..propId] = spr
        spr:setPositionX(-posLeft + (i-1)*dis)
    end
end

function NewerReward:createProp(propId, propCount) 
    local propname = "common/prop/"..FishGI.GameTableData:getItemTable(propId).res
    local uineweritem = require("ui/hall/newerreward/uineweritem").create()
    local item = uineweritem.root
    local spr_prop = uineweritem.spr_prop
    local fnt_count = uineweritem.fnt_count
    fnt_count:setString(propCount)
    if not spr_prop:initWithFile(propname) then
        print("--NewerReward--prop is no exidt----")
    end

    return item
end

function NewerReward:onTouchBegan(touch, event) 
    if self:isVisible() ~= true then
        return false
    end   

    return true
end

function NewerReward:onClickget( sender )
    if self.curStates == 0  then
        self:sendGetNewerReward()
    end
end

function NewerReward:playShowAct(  )
    self.curStates = 0
    self:showLayer(false)
    
end

function NewerReward:sendGetNewerReward( )
    self.curStates = 1
    --发送抽奖消息
    if FishGI.hallScene.net.roommanager == nil then
        return 
    end
    FishGI.hallScene.net.roommanager:sendGetNewerReward();

end

--领取新手奖励
function NewerReward:onGetNewerReward(data)
    print("--onGetNewerReward--")
    data = data._userdata
    local errorCode = data.errorCode
    if errorCode ~= 0 then
        print("-----NewerReward----errorCode="..errorCode)
        return 
    end

    local props = data.props
    local seniorProps = data.seniorProps

    local playerId = FishGI.myData.playerId
    --更新数据
    --普通道具
    for k,val in pairs(props) do
        FishGMF.addTrueAndFlyProp(playerId,val.propId,val.propCount,false)
        FishGMF.setAddFlyProp(playerId,val.propId,val.propCount,false)
    end

    --高级道具
    for k,val in pairs(seniorProps) do
        FishGMF.refreshSeniorPropData(playerId,val,8,0)
    end

    self:playPropFlyAct(playerId,props,seniorProps)
end

--播放道具飞行动画
function NewerReward:playPropFlyAct(playerId,props,seniorProps)

    --普通道具
    for k,val in pairs(props) do
        local propTab = {}
        propTab.playerId = playerId
        propTab.propId = val.propId
        propTab.propCount = val.propCount
        propTab.isRefreshData = true
        propTab.isJump = false
        propTab.firstPos = self:getFirstPosByPropId(val.propId)
        propTab.dropType = "normal"
        propTab.isShowCount = true
        propTab.maxScale = self.scaleMin_
        FishGI.GameEffect:playDropProp(propTab)
    end

    --高级道具
    for k,val in pairs(seniorProps) do
        local propTab = {}
        propTab.playerId = playerId
        propTab.propId = val.propId
        propTab.propCount = 1
        propTab.isRefreshData = true
        propTab.isJump = false
        propTab.firstPos = self:getFirstPosByPropId(val.propId)
        propTab.dropType = "normal"
        propTab.isShowCount = true
        propTab.seniorPropData = val
        propTab.maxScale = self.scaleMin_
        FishGI.GameEffect:playDropProp(propTab)
    end

    self:endAct()

end

function NewerReward:showAct()
    self.btn_get:setVisible(false)
    --self.node_list:setVisible(false)
    local callFun = function ( ... )
        self.btn_get:setVisible(true)
        --self.node_list:setVisible(true)
    end
    local winSize = cc.Director:getInstance():getWinSize();
    self.panel:setPositionX(winSize.width/self.scaleX_)
    
    local moveAct = cc.MoveTo:create(1.5,cc.p(0,0))
    local speedAct = cc.EaseExponentialOut:create(moveAct)
    local seq = cc.Sequence:create(speedAct,cc.CallFunc:create(callFun))
    
    seq:setTag(5050)
    self.panel:stopActionByTag(5050)
    self.panel:runAction(seq)

end

function NewerReward:endAct()
    self.btn_get:setVisible(false)
    self.node_list:setVisible(false)
    local callFun = function ( ... )
        self:removeFromParent()
        FishGI.hallScene.uiNewerReward = nil
        if FishGI.hallScene ~= nil and FishGI.hallScene.uiAllRoomView ~= nil then
            FishGI.hallScene.uiAllRoomView:fastStartGame()
        end
    end
    local winSize = cc.Director:getInstance():getWinSize();
    local moveAct = cc.MoveTo:create(1.5,cc.p(-winSize.width/self.scaleX_,self.panel:getPositionY()))
    local speedAct = cc.EaseExponentialIn:create(moveAct)
    local seq = cc.Sequence:create(speedAct,cc.CallFunc:create(callFun))
    seq:setTag(4040)
    self.panel:stopActionByTag(4040)
    self.panel:runAction(seq)

end

function NewerReward:getFirstPosByPropId(propId)
    local propItem = self["prop_"..propId]
    if propItem == nil then
        return nil
    end 
    local pos,size = FishGF.getWordPosAndSizeByNode(propItem)
    return pos
end

return NewerReward;
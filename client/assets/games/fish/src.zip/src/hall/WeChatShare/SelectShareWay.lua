
local SelectShareWay = class("SelectShareWay", cc.load("mvc").ViewBase)

SelectShareWay.AUTO_RESOLUTION   = false
SelectShareWay.RESOURCE_FILENAME = "ui/hall/wechatshare/uiselshareway"
SelectShareWay.RESOURCE_BINDING  = {    
    ["panel"]                  = { ["varname"] = "panel" },
    
    ["btn_close"]              = { ["varname"] = "btn_close" ,        ["events"]={["event"]="click",["method"]="onClickclose"}},     
    ["btn_share_friend"]       = { ["varname"] = "btn_share_friend" ,     ["events"]={["event"]="click",["method"]="onClickShareFriend"}},     
    ["btn_share_friendcircle"] = { ["varname"] = "btn_share_friendcircle" ,         ["events"]={["event"]="click",["method"]="onClickShareFriendCircle"}},    
    
    ["img_base"]               = { ["varname"] = "img_base" }, 
    ["img_frame"]              = { ["varname"] = "img_frame" }, 
    ["spr_friend_title"]       = { ["varname"] = "spr_friend_title" }, 
    ["spr_friendcircle_title"] = { ["varname"] = "spr_friendcircle_title" },  
    ["spr_share_way_title"]    = { ["varname"] = "spr_share_way_title" },    

}

function SelectShareWay:onCreate(...)
    self:openTouchEventListener();
end

function SelectShareWay:onTouchBegan(touch, event)
    if not self:isVisible() then
         return false;
    end
    return true;
end

function SelectShareWay:registerCallback(callback)
    self.callback = callback;
end

function SelectShareWay:onClickclose(sender)
    self:hideLayer();
end

function SelectShareWay:onClickShareFriend(sender)
    self.callback(0);
    self:onClickclose(sender);
end

function SelectShareWay:onClickShareFriendCircle(sender)
    self.callback(1);
    self:onClickclose(sender);
end

return SelectShareWay;
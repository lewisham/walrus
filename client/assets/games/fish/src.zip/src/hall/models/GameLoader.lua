--region *
--Date
--此文件由[BabeLua]插件自动生成



if GameClient == nil then
	dofile("")
else
	dofile(GameClient.mainfile)
end



--checkGameClient()

-- if GameClient == nil then
-- 	FishGF.print("game client is nil roommanager restart");
-- 	FishGI.hallScene.net.roommanager:StartGame();
-- 	Dofile(GameClient.mainfile);
-- else
-- 	FishGF.print("do file");
-- 	Dofile(GameClient.mainfile);
-- end

--endregion

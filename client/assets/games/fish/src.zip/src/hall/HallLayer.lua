﻿
local HallLayer = class("HallLayer", cc.load("mvc").ViewBase)
--local netMsgTab = require("Other.NetMsgType")

HallLayer.AUTO_RESOLUTION   = true
HallLayer.RESOURCE_FILENAME = "ui/hall/uiHallLayer"
HallLayer.RESOURCE_BINDING  = {
    
    ["node_msw"]           = { ["varname"] = "node_msw"} , 
    -- ["node_enter_friend"]  = { ["varname"] = "node_enter_friend"} ,
    ["node_righttop_btn"]  = { ["varname"] = "node_righttop_btn"} ,    
    ["image_option_bg"]    = { ["varname"] = "image_option_bg"  },    
    ["btn_option"]         = { ["varname"] = "btn_option" ,         ["events"]={["event"]="click",["method"]="onClickoption"}}, 
    ["btn_option_exit"]    = { ["varname"] = "btn_option_exit" ,    ["events"]={["event"]="click",["method"]="onClickexit"}}, 
    ["btn_option_feedback"]= { ["varname"] = "btn_option_feedback" , ["events"]={["event"]="click",["method"]="onClickfeedback"}}, 
    ["btn_option_service"] = { ["varname"] = "btn_option_service" , ["events"]={["event"]="click",["method"]="onClickservice"}}, 
    ["btn_mail"]           = { ["varname"] = "btn_mail" ,           ["events"]={["event"]="click",["method"]="onClickmail"}}, 
    ["btn_real_name"]      = { ["varname"] = "btn_real_name" ,      ["events"]={["event"]="click",["method"]="onClickreal_name"}},   
    ["image_real_name_bg"] = { ["varname"] = "image_real_name_bg"} ,   
    ["text_real_name_award"]           = { ["varname"] = "text_real_name_award"} , 

    ["image_coin_bg"]      = { ["varname"] = "image_coin_bg" }, 
    ["image_diamond_bg"]   = { ["varname"] = "image_diamond_bg" }, 
    ["btn_addcoin"]        = { ["varname"] = "btn_addcoin" ,        ["events"]={["event"]="click",["method"]="onClickcoin"}},
    ["btn_adddiamond"]     = { ["varname"] = "btn_adddiamond" ,     ["events"]={["event"]="click",["method"]="onClickdiamond"}},
    ["fnt_coin"]           = { ["varname"] = "fnt_coin"  },   
    ["fnt_diamond"]        = { ["varname"] = "fnt_diamond"  }, 
    
    ["spr_player_bg"]      = { ["varname"] = "spr_player_bg"  }, 
    ["spr_vip"]            = { ["varname"] = "spr_vip"  },    
    ["text_name"]          = { ["varname"] = "text_name"  },
    ["spr_player_photo"]   = { ["varname"] = "spr_player_photo"  },
    ["btn_player_head_bg"] = { ["varname"] = "btn_player_head_bg" , ["events"]={["event"]="click",["method"]="onClickplayerhead"}}, 
    ["fnt_vipnum"]         = { ["varname"] = "fnt_vipnum"  },
    ["spr_head_edge"]      = { ["varname"] = "spr_head_edge"  },	
    
    -- ["text_word"]          = { ["varname"] = "text_word"  }, 
    -- ["image_bg"]           = { ["varname"] = "image_bg"  }, 

    
    
}

FishCD.HALL_BTN_1  = 1 --背包
FishCD.HALL_BTN_2  = 2 --任务 
-- FishCD.HALL_BTN_3  = 3 --签到
FishCD.HALL_BTN_4  = 4 --排行榜
FishCD.HALL_BTN_5  = 5 --vip转盘
FishCD.HALL_BTN_6  = 6 --救济金
FishCD.HALL_BTN_7  = 7 --锻造

FishCD.HALL_BTN_8  = 8 --vip特权
FishCD.HALL_BTN_9  = 9 --月卡
FishCD.HALL_BTN_10 = 10 --商店
FishCD.HALL_BTN_11 = 11 --兑换话费

--按键 --用于更换按键图片和绑定函数
HallLayer.HALL_BTN_ARR   = {
    ["node_btn_1"]  = { ["btnName"] = "背包" ,    ["tag"] = FishCD.HALL_BTN_1 ,["isShowNow"] = true ,     ["varname"] = "node_btn_1" ,   ["filename"] = "hall_btn_bag" ,    ["method"] = "onClickbag"}, 
    ["node_btn_10"] = { ["btnName"] = "商店" ,    ["tag"] = FishCD.HALL_BTN_10,["isShowNow"] = true ,     ["varname"] = "node_btn_10" ,  ["filename"] = "hall_btn_shop" ,   ["method"] = "onClickshop"}, 
    ["node_btn_5"]  = { ["btnName"] = "vip转盘" , ["tag"] = FishCD.HALL_BTN_5 ,["isShowNow"] = true ,     ["varname"] = "node_btn_5" ,   ["filename"] = "hall_btn_dailvip" ,["method"] = "onClickdailvip"}, 
    ["node_btn_6"]  = { ["btnName"] = "救济金",   ["tag"] = FishCD.HALL_BTN_6 ,["isShowNow"] = false ,    ["varname"] = "node_btn_6" ,   ["filename"] = "hall_btn_jjj" ,    ["method"] = "onClickAlm"}, 
    ["node_btn_7"]  = { ["btnName"] = "锻造",     ["tag"] = FishCD.HALL_BTN_7 ,["isShowNow"] = false ,    ["varname"] = "node_btn_7" ,   ["filename"] = "hall_btn_dz" ,     ["method"] = "onClickdz"}, 
    ["node_btn_8"]  = { ["btnName"] = "vip特权" , ["tag"] = FishCD.HALL_BTN_8 ,["isShowNow"] = true ,     ["varname"] = "node_btn_8" ,   ["filename"] = "hall_btn_vip" ,    ["method"] = "onClickvip"}, 
    ["node_btn_9"]  = { ["btnName"] = "月卡" ,    ["tag"] = FishCD.HALL_BTN_9 ,["isShowNow"] = true ,     ["varname"] = "node_btn_9" ,   ["filename"] = "hall_btn_yklb" ,   ["method"] = "onClickYklb"}, 
    ["node_btn_2"]  = { ["btnName"] = "任务" ,    ["tag"] = FishCD.HALL_BTN_2 ,["isShowNow"] = true ,     ["varname"] = "node_btn_2" ,   ["filename"] = "hall_btn_rcrw" ,   ["method"] = "onClicktask"}, 
    ["node_btn_11"] = { ["btnName"] = "话费" ,    ["tag"] = FishCD.HALL_BTN_11,["isShowNow"] = true ,     ["varname"] = "node_btn_11" ,  ["filename"] = "hall_btn_hfdh" ,   ["method"] = "onClickexchange"}, 

    --    ["node_btn_4"] = { ["btnName"] = "排行榜" , ["tag"]   = 4 ,["isShowNow"] = true ,    ["varname"]  = "node_btn_4" ,    ["filename"] = "hall_btn_phb" ,  ["method"]   = "onClickrank"}, 

}

HallLayer.DOWN_BTN_DATA = {
    posX = 64,
    posY = 74,    
    dis = 130,
}
--根据key值排序，更新底部按键位置 
HallLayer.HALL_DOWN_BTN  = {
    { ["varname"] = "node_btn_1"}, 
    { ["varname"] = "node_btn_11"},
    { ["varname"] = "node_btn_2"}, 
    { ["varname"] = "node_btn_7"},   
    { ["varname"] = "node_btn_6"},   
}

HallLayer.LEFT_BTN_DATA = {
    posX = 64,
    posY = 370,
    height = 460,
    dis = 110,
}
--左边的按键
HallLayer.HALL_LEFT_BTN  = {
    { ["varname"] = "node_btn_10"}, 
    { ["varname"] = "node_btn_9"}, 
    { ["varname"] = "node_btn_8"},   
    { ["varname"] = "node_btn_5"}, 
}

function HallLayer:onCreate( ... )
    self:runAction(self.resourceNode_["animation"])
    self.resourceNode_["animation"]:play("wave_act", true);
    self.animation = self.resourceNode_["animation"]

    self.isOpen = false
    self:initBtnArr()
    self:setOptionIsOpen(false)

    local dataStr = FishGI.GameConfig:getConfigData("config",tostring(990000102), "data")
    local val = string.split(dataStr,",")
    self.text_real_name_award:setString(val[2])

    
    -- 头像裁剪
    local size = self.btn_player_head_bg:getContentSize();
    local node = FishGF.GetClippNode(cc.rect(0, 0, size.width, size.width), size.width / 2);
    self.spr_player_bg:addChild(node);
    self.spr_player_photo:setVisible(false)
    node:setPosition(cc.p(self.btn_player_head_bg:getPositionX(),self.btn_player_head_bg:getPositionY()))
    --头像
    self.mFigure = cc.Sprite:create("common/com_pic_photo_1.png");
    self.mFigure:setContentSize(cc.size(size.width, size.width));
    self.mFigure:setAnchorPoint(cc.p(0, 0));
    self.mFigure:setPosition(cc.p(0, 0));
    self.mFigure:setVisible(true)
    node:addChild(self.mFigure, 1, 25);
    node:setVisible(true)
    -- if CHANNEL_ID == CHANNEL_ID_LIST.tencent or CHANNEL_ID == CHANNEL_ID_LIST.yyb then
    --     self.image_option_bg:setContentSize(cc.size(self.image_option_bg:getContentSize().width,320))
    --     self.btn_mail:setPositionY(204)
    --     self.btn_option_feedback:setPositionY(128.00)
    --     self.btn_option_exit:setPositionY(52.00)
    --     self.btn_option_service:setVisible(false)
    -- end
    
    --node:setScale(self.scaleMin_)
    self.spr_head_edge:setLocalZOrder(node:getLocalZOrder() + 1)

    self:openTouchEventListener()

    FishGI.eventDispatcher:registerCustomListener("onUserInit", self, function(valTab) self:onUserInit(valTab) end)

    if CHANNEL_ID == CHANNEL_ID_LIST.oppo then
        self.image_real_name_bg:setVisible(false)
        self.btn_real_name:setVisible(false)
    end
end

function HallLayer:onEnter()
    self.super.onEnter(self)

    if FishGI.hallScene.net:getAvatarurl() ~= "" and FishGI.hallScene.net:getAvatarurl() ~= nil then
        local fileurl = FishGI.imageDownload:Start(FishGI.hallScene.net:getAvatarurl(), function(ret_path,err_msg)
            if ret_path then
                local size = self.mFigure:getContentSize();
                self.mFigure:setTexture(ret_path);
                self.mFigure:setScaleX(size.width/self.mFigure:getContentSize().width);
                self.mFigure:setScaleY(size.height/self.mFigure:getContentSize().height);
                self.mFigure:setContentSize(size);
            end
        end)
    end
end

--初始化按键
function HallLayer:initBtnArr()
    self.image_option_bg:setVisible(false)
    self.image_coin_bg:setScale(self.scaleMin_)
    self.image_diamond_bg:setScale(self.scaleMin_)
    self.spr_player_bg:setScale(self.scaleMin_)
    self.node_righttop_btn:setScale(self.scaleMin_)
    self.node_righttop_btn:setLocalZOrder(20)

    self.btn_msw = self.node_msw:getChildByName("btn_msw")
    self.btn_msw:onClickScaleEffect(handler(self,self.onClickmsw))
    self.node_msw.animation:play("msw_light", true);
    self.node_msw:setScale(self.scaleMin_)

    self:initAllBtnArr()

    --救济金
    self:initAlm();
    
    self:updateDownBtnPos()
    self:updateLeftBtnPos()

end

--初始化按键列表按键
function HallLayer:initAllBtnArr()
    --绑定按键和更换按键图片
    for key,val in pairs(self.HALL_BTN_ARR) do
        local path = "hall/btn/"..val.filename..".png"
        local backFun = handler(self,self[val.method])
        local btn = require("hall/BtnItem").create()
        btn:setScale(self.scaleMin_)
        btn:setBtnCallBack(backFun)
        btn:setBtnPic(path)
        self:addChild(btn)
        self[val.varname] = btn
    end

    self:initAllBtnArrPos()

    for k,v in pairs(self.HALL_BTN_ARR) do
        local tag = v.tag
        self:setBtnIsLight(tag,false)
        local node_btn = self[v.varname]
        node_btn:setVisible(v.isShowNow)
    end

end

--初始化按键列表按键位置
function HallLayer:initAllBtnArrPos()
    for i=1,#self.HALL_DOWN_BTN do
        local btnData = self.HALL_DOWN_BTN[i]
        local node_btn = self[btnData.varname]
        if node_btn ~= nil and node_btn:isVisible() then
            node_btn:setPositionY(HallLayer.DOWN_BTN_DATA.posY*self.scaleY_)
        end
    end

    for i=1,#self.HALL_LEFT_BTN do
        local btnData = self.HALL_LEFT_BTN[i]
        local node_btn = self[btnData.varname]
        if node_btn ~= nil and node_btn:isVisible() then
            node_btn:setPositionX(HallLayer.LEFT_BTN_DATA.posX*self.scaleX_)
        end
    end
end

--更新按键位置
function HallLayer:updateDownBtnPos()
    FishGF.UpdataWechat()

    local count = 0
    for i=1,#self.HALL_DOWN_BTN do
        local btnData = self.HALL_DOWN_BTN[i]
        local node_btn = self[btnData.varname]
        if node_btn ~= nil and node_btn:isVisible() then
            node_btn:setPositionX((HallLayer.DOWN_BTN_DATA.posX + count * HallLayer.DOWN_BTN_DATA.dis)*self.scaleX_)
            count = count + 1
        end
    end

end

--更新左边按键位置
function HallLayer:updateLeftBtnPos()
    local count = 0
    for i=1,#self.HALL_LEFT_BTN do
        local btnData = self.HALL_LEFT_BTN[i]
        local node_btn = self[btnData.varname]
        if node_btn ~= nil and node_btn:isVisible() then
            count = count + 1
        end
    end

    local middlePosY = HallLayer.LEFT_BTN_DATA.posY*self.scaleY_
    local disY = HallLayer.LEFT_BTN_DATA.dis*self.scaleY_
    local topPosY = middlePosY + (count-1)*disY/2
    for i=1,#self.HALL_LEFT_BTN do
        local btnData = self.HALL_LEFT_BTN[i]
        local node_btn = self[btnData.varname]
        if node_btn ~= nil and node_btn:isVisible() then
            local posY = topPosY - disY*(i-1)
            node_btn:setPositionY(posY)
        end
    end

end

--设置按键是否跳动和亮光圈
function HallLayer:setBtnIsLight(btnId,isLight)  
    if btnId == nil then
        return 
    end
    local strname = string.format("node_btn_%d",btnId)
    local node_btn = self[strname]
    if node_btn == nil then
        return 
    end
    
    if isLight then
        node_btn:setBtnState(3)
        node_btn:setLocalZOrder(15)
    else
        node_btn:setBtnState(0)
        node_btn:setLocalZOrder(3)

    end
end

function HallLayer:openAlmCountDown(seconds)
    self.node_btn_6:setVisible(true);
    self.node_btn_6:setBtnCountDown(seconds,nil)
end

function HallLayer:canReceiveAlm()
    self.node_btn_6:stopBtnCountDown()
end

function HallLayer:initAlm()
    self.node_btn_6:setVisible(false);
    self.node_btn_6:stopBtnCountDown()
end

function HallLayer:isAlmRunning()
    return self.node_btn_6:isVisible();
end

function HallLayer:onTouchBegan(touch, event)
    self:setOptionIsOpen(false)
    return false  
end

--设置右上角按键收取或打开
function HallLayer:setOptionIsOpen( isOpen )
    print("-setOptionIsOpen-----")
    self.isOpen = isOpen
    if self.isOpen then
        self.image_option_bg:setVisible(true)
        self.btn_option:setRotation(180)
    else
        self.image_option_bg:setVisible(false)
        self.btn_option:setRotation(0)
    end

    local redDot = self.node_righttop_btn:getChildByName("spr_dot")
    local isNew = self.btn_option["isNew"]
    if isNew~= nil and isNew == true and not self.isOpen then
        redDot:setVisible(true)
    else
        redDot:setVisible(false)
    end

end

------------------------------------------------------------------------------------------------------
-----------------------------------------------按键回调-----------------------------------------------
------------------------------------------------------------------------------------------------------

function HallLayer:onClickexit( sender )
    self.parent_:buttonClicked("HallLayer", "exit")
end

function HallLayer:onClickdz( sender )
    FishGI.hallScene.uiForgedLayer:showLayer() 
end

function HallLayer:onClickplayerhead( sender )
    FishGI.myData.isActivited = FishGI.WebUserData:isActivited()
    FishGI.myData.isBindPhone = FishGI.WebUserData:isBindPhone()
    FishGI.hallScene.uiPlayerInfo:upDataBtnState(FishGI.myData.isActivited,FishGI.myData.isBindPhone )
    FishGI.hallScene.uiPlayerInfo:showLayer() 
end

function HallLayer:onClickYklb( sender )
    FishGI.hallScene.uiMonthcard:showLayer() 
end

function HallLayer:onClickbag( sender )
    FishGI.hallScene.uiBagLayer:showLayer() 
end

function HallLayer:onClickvip( sender )
    FishGI.hallScene.uiVipRight:upDataLayerByMyVIPLV()
    FishGI.hallScene.uiVipRight:showLayer()
end

function HallLayer:onClickshop( sender )
    FishGI.hallScene.uiShopLayer:showLayer() 
    FishGI.hallScene.uiShopLayer:setShopType(1)
end

function HallLayer:onClickmsw( sender )
    FishGI.hallScene.uiAllRoomView:fastStartGame()
end

function HallLayer:onClickdailvip( sender )
    if FishGI.myData.vip_level > 0 then
        if FishGI.hallScene.uiDialVIP ~= nil then
            FishGI.hallScene.uiDialVIP:initDialAge()
            FishGI.hallScene.uiDialVIP:showLayer()
        end
    else
        FishGF.showSystemTip(nil,800000173,1.5);
    end
end

function HallLayer:onClickoption( sender )
    self.isOpen = not self.isOpen
    self:setOptionIsOpen(self.isOpen)
end

function HallLayer:onClickfeedback( sender )
    FishGI.hallScene.uiFeedback:showLayer() 
end

--客服
function HallLayer:onClickservice( sender )
    print("-onClickservice-----")
    
    FishGF.doCustomServiceSdk()
    --[[
    local function callback(data)
        local url = data.url;
        cc.Application:getInstance():openURL(url);
    end
    FishGI.Dapi:feedBackUrl(callback)
    ]]
end

function HallLayer:onClickcoin( sender )
    FishGI.hallScene.uiShopLayer:showLayer() 
    FishGI.hallScene.uiShopLayer:setShopType(1)
end

function HallLayer:onClickdiamond( sender )
    FishGI.hallScene.uiShopLayer:showLayer() 
    FishGI.hallScene.uiShopLayer:setShopType(2)
end

function HallLayer:onClickAlm( sender )
    FishGI.hallScene.net.roommanager:sendApplyAlm();
end

function HallLayer:onClickcheck( sender )
    --FishGI.hallScene.uiCheck:showLayer() 
end

function HallLayer:onClickrank( sender )
    local url = "";
    if RANK_URL == nil then
        if BRAND == 0 then
            url = "https://userapi-fish.jixiang.cn/rank/index";
        elseif BRAND == 1 then
            url = "https://userapi-fish.weile.com/fish/rank/";
        end
    else
        url = RANK_URL
    end
    FishGF.openWebWithClose(url, FishGI.hallScene, "hall/rank/rank_pic_phb.png");
end

function HallLayer:onClickshare( sender )
    FishGI.hallScene.uiWeChatShare:showLayer() 
end

function HallLayer:onClickmail( sender )
    print("-----HallLayer:onClickmail-------")
    FishGI.hallScene.uiMail:showLayer() 
    FishGI.hallScene.uiMail:closeAllSchedule()
    FishGI.hallScene.uiMail:upDataMailList()

end

function HallLayer:onClicktask( sender )
    print("-----HallLayer:onClicktask-------")
    FishGI.hallScene.taskPanel:onClickShow()
end

function HallLayer:onClickfriend( sender )
    -- print("-----HallLayer:onClickfriend-------")
    --     --朋友场
    -- if not FishGI.hallScene.uiAllRoomView:isFriendCanOpen() then
    --     FishGF.showToast(FishGF.getChByIndex(800000298))
    --     return     
    -- end

    -- --判断玩家是否手机激活
    -- if true and (not FishGI.WebUserData:isActivited()) then
    --     local function callback(sender)
    --         local tag = sender:getTag()
    --         if tag == 2 then --ok
    --             FishGI.hallScene.uiPhoneAct:showLayer() 
    --         end
    --     end
    --     FishGF.showMessageLayer(FishCD.MODE_MIDDLE_OK_CLOSE,FishGF.getChByIndex(800000331),callback, nil)
    --     return 
    -- end

    -- FishGI.hallScene:updateFriendHelpOpen()

    -- FishGI.hallScene:setIsToFriendRoom(true)

end

function HallLayer:onClickexchange( sender )
    print("-----HallLayer:onClickexchange-------")
    FishGI.hallScene.uiExchange:showLayer() 
end

function HallLayer:onClickgame1( sender )
    print("-----HallLayer:onClickgame1-------")
    FishGF.waitNetManager(true,nil,"enteringChildGame")
    FishGF.checkUpdate(FishGI.GameList.saig)
end

--设置是否返回大厅
function HallLayer:setIsCurShow( isShow,isAct )
    if isShow == self.isShow then
        return
    end

    FishGF.setNodeIsShow(self.node_righttop_btn,"right",isShow,nil,isAct)
    FishGF.setNodeIsShow(self.node_msw,"down",isShow,nil,isAct)
    -- FishGF.setNodeIsShow(self.node_enter_friend,"down",isShow,nil,isAct)

    for k,v in pairs(self.HALL_DOWN_BTN) do
        local name = v.varname
        FishGF.setNodeIsShow(self[name],"down",isShow,nil,isAct)
    end

    for k,v in pairs(self.HALL_LEFT_BTN) do
        local name = v.varname
        FishGF.setNodeIsShow(self[name],"left",isShow,nil,isAct)
    end
    self.isShow = isShow

end

--得到按键位置
function HallLayer:getBtnPosByIndex( index )
    local node_btn = self["node_btn_"..index]
    local pos = {}
    pos.x = node_btn:getPositionX()
    pos.y = node_btn:getPositionY()
    print("-------node_btn------pos.x="..pos.x.."---------pos.y="..pos.y)
    return pos
end

--大厅中通过id得到道具的目标点 
function HallLayer:getHallPropAimByID(propId)
    local pos = cc.p(0,0)
    local spr = nil
    if propId == 1 then
        spr = self.fnt_coin
    elseif propId == 2 then
        spr = self.fnt_diamond
    else
        spr = self.node_btn_1
    end
    local pos,size = FishGF.getWordPosAndSizeByNode(spr)
    return pos,size
end

function HallLayer:onClickreal_name( sender )
    print("-----HallLayer:onClickreal_name-------")
    FishGI.hallScene.uiRealName:showLayer()
    local function callback()
        self.image_real_name_bg:setVisible(false)
        self.btn_real_name:setVisible(false)
    end
    FishGI.hallScene.uiRealName:setCallback(callback) 
end

function HallLayer:onUserInit( valTab )
    print("--------------------web init end--------------")
    if FishGI.WebUserData:isVerifyRealName() then
        self.image_real_name_bg:setVisible(false)
        self.btn_real_name:setVisible(false)
    else
        self.image_real_name_bg:setVisible(true)
        self.btn_real_name:setVisible(true)
    end

    if CHANNEL_ID == CHANNEL_ID_LIST.oppo then
        self.image_real_name_bg:setVisible(false)
        self.btn_real_name:setVisible(false)
    end
    
    FishGI.isUserInitEnd = true
    if FishGI.isFriendStateInitEnd == true then
        print("--------------------web init end-----------FishGF.handleOpenUrl_-----")
        FishGF.handleOpenUrl_()
    end
    
end

--设置按键是否显示
function HallLayer:setBtnIsShow( btnName,isShow )
    local btn = self[btnName]
    if btn == nil then
        return 
    end
    local dir = nil
    for k,v in pairs(HallLayer.HALL_DOWN_BTN) do
        if btnName == v.varname then
            dir = "down"
            break 
        end
    end

    for k,v in pairs(HallLayer.HALL_LEFT_BTN) do
        if btnName == v.varname then
            dir = "left"
            break 
        end
    end
    btn:setVisible(isShow)

    if dir == "down" then
        self:updateDownBtnPos()
    elseif dir == "left" then
        self:updateLeftBtnPos()
    end

end


return HallLayer;
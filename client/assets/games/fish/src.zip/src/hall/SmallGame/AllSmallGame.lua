
local AllSmallGame = class("AllSmallGame", cc.load("mvc").ViewBase)
AllSmallGame.error_dis         = 6
AllSmallGame.moveTime          = 0.2

AllSmallGame.AUTO_RESOLUTION   = false
AllSmallGame.RESOURCE_FILENAME = "ui/hall/smallgame/uiallsmallgame"
AllSmallGame.RESOURCE_BINDING  = {  
    ["panel"]        = { ["varname"] = "panel" },
    ["btn_left"]     = { ["varname"] = "btn_left" ,          ["events"]   = {["event"] = "click",["method"] = "onClickleft"}},   
    ["btn_right"]    = { ["varname"] = "btn_right" ,         ["events"]   = {["event"] = "click",["method"] = "onClickright"}},   

    ["pv_game_list"] = { ["varname"] = "pv_game_list" ,      ["nodeType"] = "viewlist"   },

    ["node_dot"]     = { ["varname"] = "node_dot" },
    ["btn_dot"]      = { ["varname"] = "btn_dot" ,           ["events"]   = {["event"] = "click",["method"] = "onClickdot"}},   
    
}

AllSmallGame.GAME_LIST  = {  
    [1]={
        gameName="赛狗",
        picPath = "hall/littlegame/game_icon/game_1.png",
        updateFileName = "saig",
        gameLittleName = FishGI.GameList.saig,
        config = require("VersionConfig")["saig"]
    },
    -- [2]={
    --     gameName="套牛",
    --     picPath= "hall/littlegame/game_icon/game_2.png",
    --     filePath = "fknz",
    --     gameLittleName = FishGI.GameList.fknz
    -- },
}


function AllSmallGame:onCreate( ... )
    --添加触摸监听
    self:openTouchEventListener(false)
    
    self.pvSize = self.pv_game_list:getContentSize()
    self.pv_game_list:setSwallowTouches(false)

    local data = FishGI.GameConfig:getConfigData("config", tostring(990000108), "data")
    local tab = string.split(data,",")

    self.count = tonumber(tab[1])
    self.pageCount = tonumber(tab[2])

    self:initRoomIcon()
    self:initPageDot()
    self:updateView()

end

function AllSmallGame:initRoomIcon()
    self.itemList = {}
    for i=1,self.pageCount do
        local page = self:createOncePage(i,self.count)
        self.pv_game_list:addPage(page)
    end

    local callBack = function(sender,event)
        if event==ccui.PageViewEventType.turning then
            print("--pv_game_list--addEventListener--")
            self:updateView()
        end
    end

    self.pv_game_list:addEventListener(callBack)

    if  #(self.pv_game_list:getItems()) >= 1 then
        self.pv_game_list:setCurrentPageIndex(0)
    end

end

function AllSmallGame:initPageDot()
    local dotCount = #(self.node_dot:getChildren())
    if dotCount < self.pageCount then
        local addCounr = self.pageCount - dotCount
        for i=1,addCounr do
            local btn_dot_new = (self.btn_dot):clone()
            self.node_dot:addChild(btn_dot_new)
        end
    elseif dotCount > self.pageCount then
        for i,v in ipairs(table_name) do
            if i > self.pageCount then
                v:removeFromParent()
            end
        end
    end

    self:updatePageDot()

end

function AllSmallGame:updatePageDot()
    local dotList = self.node_dot:getChildren()
    local curIndex = self.pv_game_list:getCurrentPageIndex()
    local dis = 50
    local leftPosX = (#dotList -1)*dis/2
    for i,v in ipairs(dotList) do
        local posX = -leftPosX + (i -1)*dis
        v:setPositionX(posX)
        v:setPositionY(0)
        v:setTag(i)
    end

end

function AllSmallGame:updatePageDotState( )
    local dotList = self.node_dot:getChildren()
    local curIndex = self.pv_game_list:getCurrentPageIndex()

    for k,v in pairs(dotList) do
        local tag = v:getTag()
        if curIndex + 1 == tag then
            v:setEnabled(false)
        else
            v:setEnabled(true)
        end
    end

end

function AllSmallGame:updateView( )
    local curIndex = self.pv_game_list:getCurrentPageIndex()
    local allPagesCount = #(self.pv_game_list:getItems())
    if allPagesCount <= 1 then
        self:setBtnType("none")
    elseif curIndex == 0 then
        self:setBtnType("left")
    elseif curIndex >= allPagesCount - 1 then
        self:setBtnType("right")
    else
        self:setBtnType("running")
    end

    self:updatePageDotState()
end

function AllSmallGame:setBtnType( type,isSaveDir )
    if isSaveDir == nil or isSaveDir == true then
        self.curDirType = type
    end
    
    if type == "left" then
        self.btn_left:setVisible(false)
        self.btn_right:setVisible(true)
    elseif type == "right" then
        self.btn_left:setVisible(true)
        self.btn_right:setVisible(false)
    elseif type == "none" then
        self.btn_left:setVisible(false)
        self.btn_right:setVisible(false)
    elseif type == "running" then
        self.btn_left:setVisible(true)
        self.btn_right:setVisible(true)
    end
end

function AllSmallGame:createOncePage(index,count)
    -- 创建一个布局  
    local page = ccui.Layout:create() 
    page.nodeType = "cocosStudio"
    -- 设置内容大小  
    page:setContentSize(self.pvSize)  

    local dis = 250
    local leftPosX = self.pvSize.width/2 -(count -1)*dis/2
    for i=1,count do
        local item = self:createGameItem()
        page:addChild(item)
        item:setTag((index -1)*count + i)
        item:setPositionY(self.pvSize.height/2)
        item:setPositionX(leftPosX + (i-1)*dis)
        table.insert( self.itemList, item )
        item:setGameData(AllSmallGame.GAME_LIST[i])
    end

    return page
end

function AllSmallGame:createGameItem()
    local item = require("hall/SmallGame/SmallGameItem").create()

    return item
end

function AllSmallGame:onTouchBegan(touch, event)
    local roomType = FishGI.hallScene.roomType
    if roomType ~= 3 then
        return false
    end
    return true
end

function AllSmallGame:onTouchMoved(touch, event)
    self:updateView()
end

function AllSmallGame:onTouchEnded(touch, event)
    local curPage = self.pv_game_list:getCurrentPageIndex()
    self.pv_game_list:scrollToItem(curPage)
end

function AllSmallGame:onTouchCancelled(touch, event)
end

function AllSmallGame:onClickleft( sender )
    local curPage = self.pv_game_list:getCurrentPageIndex()
    local allPagesCount = #(self.pv_game_list:getItems())
    curPage = curPage - 1
    if curPage < 0 then
        curPage = 0
    end
    self:setCurPageIndex(curPage,true)
end

function AllSmallGame:onClickright( sender )
    local curPage = self.pv_game_list:getCurrentPageIndex()
    local allPagesCount = #(self.pv_game_list:getItems())
    curPage = curPage +1
    if curPage > allPagesCount -1 then
        curPage = allPagesCount - 1
    end
    self:setCurPageIndex(curPage,true)
end

function AllSmallGame:onClickdot( sender )
    local tag = sender:getTag()
    self:setCurPageIndex(tag-1,true)
end

function AllSmallGame:setCurPageIndex( index,isAct )
    if index == nil then
        index = 0
    end
    if isAct == nil then
        isAct = false
    end
    if isAct then
        self.pv_game_list:scrollToItem(index)
    else
        self.pv_game_list:setCurrentPageIndex(index)
    end
    
    self:updateView()
end

function AllSmallGame:setIsCurShow( isShow ,isAct )
    if isShow == self.isShow then
        return
    end
    if isShow == true then
        self:setVisible(true)
    end
    self.isShow = isShow
    FishGF.setNodeIsShow(self.pv_game_list,"up",isShow ,display.height,isAct)
    FishGF.setNodeIsShow(self.btn_left,"left",isShow,nil,isAct)
    FishGF.setNodeIsShow(self.btn_right,"right",isShow,nil,isAct)
    FishGF.setNodeIsShow(self.node_dot,"down",isShow,nil,isAct)

end

function AllSmallGame:updateGameState(  )

    for i,item in ipairs(self.itemList) do
        local tag = item:getTag()
        local gameData = AllSmallGame.GAME_LIST[tag]
        if gameData == nil then
            item:setGameIsOpen(false)
            item:setGameIsExist(false)
        else
            item:setGameIsOpen(true)
            item:setGameIcon(gameData.picPath) 
            local isExistGame = self:judgeGameIsExist(gameData.updateFileName)
            item:setGameIsExist(isExistGame)
        end
    end

end

function AllSmallGame:judgeGameIsExist( updateFileName )
    if updateFileName == nil or updateFileName == "" then
        return false
    end
    local isExistGame = false
    if updateFileName ~= nil then
       local path = Helper.writepath .. "games/"..updateFileName.."/manifest"
        if FishGF.file_exists(path..".lua") then
            isExistGame = true
            print("-------------".."manifest.lua".."已经存在")
        end
        if FishGF.file_exists(path..".wld") then
            isExistGame = true
            print("-------------".."manifest.wld".."已经存在")
        end
    end
    return isExistGame
end


function AllSmallGame:clearData( )
    for i,item in ipairs(self.itemList) do
        item:removeUpdateListener()
    end
end

return AllSmallGame;
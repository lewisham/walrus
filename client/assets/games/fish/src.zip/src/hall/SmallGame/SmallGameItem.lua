
local SmallGameItem = class("SmallGameItem", cc.load("mvc").ViewBase)

SmallGameItem.AUTO_RESOLUTION   = false
SmallGameItem.RESOURCE_FILENAME = "ui/hall/smallgame/uismallgameitem"
SmallGameItem.RESOURCE_BINDING  = {
    ["panel"]         = { ["varname"] = "panel" ,},
    ["spr_bg"]        = { ["varname"] = "spr_bg" , },  
    ["spr_game"]      = { ["varname"] = "spr_game" , },  

    ["node_load"]     = { ["varname"] = "node_load" , }, 
    ["spr_load_bg"]   = { ["varname"] = "spr_load_bg" , },  
    ["spr_load_gray"] = { ["varname"] = "spr_load_gray" , },  
    ["spr_load"]      = { ["varname"] = "spr_load" , },  
    ["txt_per"]       = { ["varname"] = "txt_per" , },   
}

function SmallGameItem:onCreate( ... )
    self.animation = self.resourceNode_["animation"];
    self:runAction(self.animation)

    --添加触摸监听
    self:openTouchEventListener(false)

    self.node_load:setVisible(false)
    self:initProgressTimer()

    self:setGameIsOpen(false)
    self:setGameIsExist(false)

    

    self.update = require("Update/UpdateModule/Update").create();
    self:registerUpdateListener();

    self.isEnableEnter = true;
    self.isLoad = false
end

function SmallGameItem:playUpdateEndAct()
    self.animation:play("endact", false)
    self.isLoad = false
end

function SmallGameItem:registerUpdateListener()
    --注册热更新模块所需的监听器
	self.updateCompelteListener=cc.EventListenerCustom:create("updateComplete",handler(self, self.updateFinish))  
    cc.Director:getInstance():getEventDispatcher():addEventListenerWithFixedPriority(self.updateCompelteListener, 2)

	self.updateErrorListener=cc.EventListenerCustom:create("updateError",handler(self, self.checkVersionRetry))  
    cc.Director:getInstance():getEventDispatcher():addEventListenerWithFixedPriority(self.updateErrorListener, 2)

	self.beginDownloadListener=cc.EventListenerCustom:create("beginDownload",handler(self, self.openUpdateUI))  
    cc.Director:getInstance():getEventDispatcher():addEventListenerWithFixedPriority(self.beginDownloadListener, 2)

	self.updateNoticeListener=cc.EventListenerCustom:create("updating",handler(self, self.updateViewPercent))  
    cc.Director:getInstance():getEventDispatcher():addEventListenerWithFixedPriority(self.updateNoticeListener, 2)
end

function SmallGameItem:removeUpdateListener()
    cc.Director:getInstance():getEventDispatcher():removeEventListener(self.updateCompelteListener)
    cc.Director:getInstance():getEventDispatcher():removeEventListener(self.updateErrorListener)
    cc.Director:getInstance():getEventDispatcher():removeEventListener(self.beginDownloadListener)
    cc.Director:getInstance():getEventDispatcher():removeEventListener(self.updateNoticeListener)
    self.isLoad = false
end

--更新完成
function SmallGameItem:updateFinish(evt)
    --self:removeUpdateListener();
    local data = evt._userdata;
    local updateId = data.id;
    if self.update and updateId == self.update:getId() then
        self.update = nil;
        self.update = require("Update/UpdateModule/Update").create();
        self:setGameIsExist(true);
        if self.isEnableEnter then
            FishGF.enterSmallGame(self.gameData.gameLittleName)
        end

        self.isEnableEnter = true;
    end
    self.isLoad = false
end

--版本检测失败
function SmallGameItem:checkVersionRetry()
    --清除更新任务
    if self.update == nil then
        return;
    end
	local event = cc.EventCustom:new("cleanUpdate")
    event._userdata = {id = self.update:getId() }
    cc.Director:getInstance():getEventDispatcher():dispatchEvent(event)

    local function callback(sender)
        local tag = sender:getTag()
        if tag == 2 then
        	--ok
            self:checkVersion();
        elseif tag == 3 then
        	os.exit(0);
        end
    end
    --modifier wxs 提示网络错误 字要改成读取配置
    FishGF.showMessageLayer(FishCD.MODE_MIDDLE_OK_CLOSE,"网络错误，请重试！",callback);
    print("checkVersionRetry")
    self.isLoad = false
end

--开始下载
function SmallGameItem:openUpdateUI()
    self.isLoad = true
end


function SmallGameItem:updateViewPercent(evt)
    
    local data = evt._userdata
    local updateId = data.id
	local cur = data.cur
	local all = data.total
	local speed = data.speed
	local progress = data.progress
    if self.update and updateId == self.update:getId() then
        self.isEnableEnter = false;
        self.isLoad = true
        self:setPercent(progress)
        if progress >= 100 then
            self:playUpdateEndAct();
        end
    end
end

--阴影进度条
function SmallGameItem:initProgressTimer( )
    self.spr_load:setVisible(false)
    if self.loadBar ~= nil then
        self.loadBar:setPercentage(0) 
        return 
    end
    self.loadBar = cc.ProgressTimer:create(self.spr_load)  
    self.loadBar:setType(cc.PROGRESS_TIMER_TYPE_RADIAL)
    self.loadBar:setPercentage(100) 
    self.loadBar:setPosition(cc.p(self.spr_load:getPositionX(),self.spr_load:getPositionY()))  
    self.node_load:addChild(self.loadBar) 
    self.loadBar:setLocalZOrder(self.spr_load:getLocalZOrder())

end

function SmallGameItem:setPercent(per)
    if per >=100 then
        self.node_load:setVisible(false)
    else
        self.node_load:setVisible(true)
    end
    
    self.loadBar:setPercentage(per) 
    self.txt_per:setString(math.floor(per).."%")
end

function SmallGameItem:onTouchBegan(touch, event)
    local roomType = FishGI.hallScene.roomType
    if roomType ~= 3 then
        return false
    end

    local curPos = touch:getLocation()
    local s = self.spr_game:getContentSize()
    local locationInNode = self.spr_game:convertToNodeSpace(curPos)
    local rect = cc.rect(0,0,s.width,s.height)
    if cc.rectContainsPoint(rect,locationInNode) then
        print("--SmallGameItem--onTouchBegan--tag="..self:getTag())
        self.beganPos = curPos
        FishGI.AudioControl:playEffect("sound/com_btn03.mp3")
        return true
    end

    return false  

end

function SmallGameItem:onTouchMoved(touch, event)
end

function SmallGameItem:onTouchEnded(touch, event)
    print("--SmallGameItem--onTouchEnded--")
    local curPos = touch:getLocation()
    if self.beganPos == nil then
        return false
    end   
    if self.beganPos.x - curPos.x > 6 or self.beganPos.x - curPos.x < -6 then
        return false
    end

    if self.isOpen == false then
        return 
    end

    if self.isLoad == true then
        return 
    end

    local gameTag = self:getTag()

    if self.isExist == false then
        local function callback(sender)
            local tag = sender:getTag()
            if tag == 2 then
                self:downloadGame(gameTag)
            end
        end
        local str = "还没下载该游戏，是否下载该游戏？"
        FishGF.showMessageLayer(FishCD.MODE_MIDDLE_OK_CLOSE,str,callback);
        print("------------------------str="..str)
    else
        self:downloadGame(gameTag)
    end

end

function SmallGameItem:onTouchCancelled(touch, event)
end

function SmallGameItem:setGameIsOpen( isOpen )
    self.isOpen = isOpen
    if isOpen == false then
        self.spr_game:setVisible(false)
        self.node_load:setVisible(false)
    else
        self.spr_game:setVisible(true)
    end
end

function SmallGameItem:setGameIcon( picPath )
    if self.spr_game:initWithFile(picPath) then
        return true
    end
    return false
end

function SmallGameItem:setGameIsExist( isExist )
    self.isExist = isExist
    if isExist == false and self.isOpen == true then
        self.spr_game:setColor(cc.c3b(127,127,127))
    else
        self.spr_game:setColor(cc.c3b(255,255,255))
        self.node_load:setVisible(false)
        
    end
    
end

function SmallGameItem:setGameData( gameData )
    self.gameData = gameData
end

function SmallGameItem:getSmallGameVersion()
    local ok, manifest_table= FishGF.getGameManifestTable(self.gameData.gameLittleName)
    local version = 0
    if ok and checktable(manifest_table).mainfile then
        version = manifest_table.version
    end

    return tonumber(version)
end

function SmallGameItem:downloadGame(  )
    if self.gameData == nil or self.gameData.gameLittleName == nil or self.gameData.gameLittleName == "" then
        print("--game-is no exist----")
        return 
    end
    print("download small game")
    self.isLoad = true
    local name = self.gameData.gameLittleName
    local event = cc.EventCustom:new("startUpdate");
    local url = GET_SMALL_GAME_UPDATE_URL(self.gameData.config.GAME_ID, self:getSmallGameVersion());
    local cmdType = require("Update/UpdateModule/UpdateConstant").CommandType.GET_SGAME_DOWNLOAD_URL;
    event._userdata = {id = self.update:getId(), url = url, cmdType = cmdType};
    cc.Director:getInstance():getEventDispatcher():dispatchEvent(event);
    --FishGF.checkUpdate(self.gameData.gameLittleName,self)
end

return SmallGameItem;
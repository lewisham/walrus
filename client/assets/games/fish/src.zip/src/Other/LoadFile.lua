﻿
require("Other/LogUtil");
require("GlobalCom/ConstantDef");

require("GlobalCom/GlobalFunc");
require("GlobalCom/GameFunc");
require("GlobalCom/GlobalInstance");
require("Other/NetMessage");
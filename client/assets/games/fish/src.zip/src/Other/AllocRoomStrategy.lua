local AllocRoomStrategy = class("AllocRoomStrategy")
local oldRoomTab = {527, 606}
local newRoomTab = {610}


function AllocRoomStrategy.create()
	local obj = AllocRoomStrategy.new();
	obj:init();
	return obj;
end

function AllocRoomStrategy:init()

end

function AllocRoomStrategy:getBuyuRoomId(roomTab, versionTab, channelId)
	local bigVersion = versionTab[2];
	local rooms = {}
	for key, val in pairs(roomTab) do
		if val.gameid == GAME_ID then
			if val.cmd.test ~= nil and tonumber(val.cmd.test) == 1 then
				--测试
				if val.cmd.fri ~= nil and tonumber(val.cmd.fri) == 1 then
					--朋友场
				else
					--普通场
					if val.cmd.v ~= nil and bigVersion == tonumber(val.cmd.v) then
						--版本相同
						return key;
					end
				end
			else
				if val.cmd.fri ~= nil and tonumber(val.cmd.fri) == 1 then
					--朋友场
				else
					--普通场
					if val.cmd.v ~= nil and bigVersion == tonumber(val.cmd.v) then
						--版本相同
						rooms[key] = val;
					end
				end
			end
		end
	end
	
	return self:selectStrategy(rooms);
end

function AllocRoomStrategy:getSmallGameRoomId(roomTab, gameId, version)
	local roomIndexTab = {}
	for key, val in pairs(roomTab) do
		if tonumber(val.gameid) == tonumber(gameId) then
			if val.cmd.test ~= nil and tonumber(val.cmd.test) == 1 then
				--测试
				if val.cmd.v ~= nil and tonumber(version) == tonumber(val.cmd.v) then
					--版本一样
					return key;
				end
			else
				--正式房间
				if val.cmd.v ~= nil and tonumber(version) == tonumber(val.cmd.v) then
					table.insert(roomIndexTab, key);
				end
			end
		end
	end

	return self:randomSelectRoom(roomIndexTab);
end

function AllocRoomStrategy:selectStrategy(rooms)
	local limitDownNum = 500;	--下限 小于这个数量就优先导入玩家
	local limitUpNum = 5000;	--上限 大于这个数就不导入玩家

	local limitDownMax = 0
	local index = 0
	for key, val in pairs(rooms) do
		if val.gameid == GAME_ID then
			local playerNum = val.players;
			if playerNum <= limitDownNum and playerNum >= limitDownMax then
				
				limitDownMax = playerNum;
				index = key;
			end
		end
	end

	if limitDownMax == 0 and index == 0 then
		--没有低于500的房间
		--排除大于5000的房间
		local selectTab = {}
		local limitUpMin = 0
		for key, val in pairs(rooms) do
			local playerNum = val.players;
			if playerNum < limitUpNum then
				table.insert(selectTab, key);
			end
		end

		if table.maxn(selectTab) == 0 then
			return nil;
		else
			return self:randomSelectRoom(selectTab);
		end

	else
		return index;
	end
end

function AllocRoomStrategy:randomSelectRoom(roomIndexTab)
	local roomIndex = math.random(1,table.maxn(roomIndexTab));
	return roomIndexTab[roomIndex];
end

return AllocRoomStrategy;
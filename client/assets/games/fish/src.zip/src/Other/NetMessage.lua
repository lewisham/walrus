cc.exports.FishNM = {}
FishNM.HEAD = {
	["MSG_C2S_GET_DESK"] = 6,	--房间内获取桌子
	["MSG_C2S_HALL_JMSG"] = 8,
	["MSG_S2C_HALL_JMSG"] = 4296,
	--["MSG_S2C_GET_DATA"] = 4296, --房间内获取数据

	["MSG_C2S_CLIENT_READY"] = 11, -- 客户端就绪
    ["MSG_C2S_JMSG"] = 30, -- 客户端就绪
    ["MSG_S2C_JMSG"] = 31, -- 客户端就绪
    ["EVENT_RECV_FISH_DATA"] = "RECV_FISH_DATA"
}
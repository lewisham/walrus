
cc.FileUtils:getInstance():setPopupNotify(false)
cc.FileUtils:getInstance():addSearchPath("src/")
cc.FileUtils:getInstance():addSearchPath("res/platform/")
cc.FileUtils:getInstance():addSearchPath("res/")
cc.FileUtils:getInstance():addSearchPath(cc.FileUtils:getInstance():getWritablePath())

LIB_SOCKET = require("socket.core")
LIB_CJSON = require("cjson")

require "config"

OLD_FISH_TEST = true

--------------------------------
-- Log
--------------------------------

local function valToStr(val)
    local str = ""
    if str == nil then
        str = str .. "nil"
    elseif type(val) == "boolean" then
        str = val and str .. "true" or str .. "false"
    elseif type(val) == "number" then
        str = str .. tostring(val)
    elseif type(val) == "string" then
        str = str .. tostring(val)
    elseif type(val) == "userdata" then
        str = str .. "userdata"
    end
    return str
end

local oldPrint = print
local function print(...)
    local tb = {...}
    local str = ""
    local bFirst = true
    for _, val in ipairs(tb) do
        if not bFirst then
            str = str .. "   "
        end
        str = str .. valToStr(val)
        bFirst = false
    end
    oldPrint(str)
end

local function LogTable(obj,parentDic,indent,deep)
	if not deep then
		deep = 10
	end
	deep = deep - 1 
	if deep < 0 then
		return
	end
	parentDic = parentDic or {}
	parentDic[obj] = true
	indent = indent or ""
	local oldIndent = indent
	print(indent.."{")
	indent = indent.."    "

	for k, v in pairs(obj) do
		local kType = type(k)
		local kStr = indent
		if kType == "number" then
			kStr = kStr.."["..k.."]"
		else
			kStr = kStr..tostring(k)
		end
		local sType = type(v)
		if sType == "table" then
			if parentDic[v] then
				print(kStr,"=","table is nest in parent")
			else
				print(kStr,"=")
				LogTable(v,parentDic,indent,deep)
			end
		elseif sType == "string" then
			print(kStr,"=", "'"..tostring(v).."'")
		else
			print(kStr,"=", tostring(v))
		end
	end

	print(oldIndent.."}")
	parentDic[obj] = nil
end

function LogKeys(obj, sFind)
	if not sFind then
		Log(obj)
		return 
	end

	sFind = sFind:upper()
	local t = {}
	for k,v in pairs(obj) do
		if type(k) == "string" and k:upper():find(sFind) then
			t[k] = v
		end
	end
	Log(t)
end

function log() end

-- Log 支持多参数
function Log(...)
	local str = debug.traceback("", 2)
	local tb = string.split(str, "\n")
	str = tb[3]
	print(str)
	local args = {...}
	if #args == 0 then
		print("nil")
		return 
	end

	for _, v in ipairs(args) do
		local sType = type(v)
		if sType == "table" then
			LogTable(v)
		else
			print(tostring(v))
		end
	end
end

-- Log 支持加打印的层数
function LogSimple(tab,n)
	if not n then
		n = 2
	end
	if not tab then
		print("nil")
		return
	end
	LogTable(tab,nil,nil,n)
end


-- 显示图片占用内存
function LogPicMem()
	cc.TextureCache:getInstance():dumpCachedTextureInfo()
end

--LuaDebug配置
if cc.FileUtils:getInstance():isFileExist("LuaDebugjit1.lua") then
    local breakInfoFun, xpcallFun = require("LuaDebugjit")("localhost", 7003)
    cc.Director:getInstance():getScheduler():scheduleScriptFunc(breakInfoFun, 0.3, false)
end

require "cocos.init"

function cc.Node:visitAll(fn)
	local function fnVisitAll(nd, fn)
		for k, child in pairs(nd:getChildren()) do
			local bStop = fn(child)
			if bStop then
				return bStop
			end
            if not tolua.iskindof(child, 'cc.TMXTiledMap') then
                bStop = fnVisitAll(child, fn)
			    if bStop then
				    return bStop
			    end
            end
		end
	end

	return fnVisitAll(self, fn)
end

function cc.Node:callAfter(seconds, fn)
	local arr = {cc.DelayTime:create(seconds),
					cc.CallFunc:create(fn)}
	self:runAction(cc.Sequence:create(arr))
	return self
end

--require所有global文件
--require("Other/LoadFile");

local xpcallFun
if DEBUG > 0 then
    local target = cc.Application:getInstance():getTargetPlatform()
    if target == cc.PLATFORM_OS_WINDOWS then
        --LuaDebug配置
        local breakInfoFun
        breakInfoFun, xpcallFun = require("Other/LuaDebug")("localhost", 7003)
        --断点定时器添加，用于LuaDebug
        cc.Director:getInstance():getScheduler():scheduleScriptFunc(breakInfoFun, 0.3, false)
    end
end

-- for CCLuaEngine traceback
function __G__TRACKBACK__(msg)
    if xpcallFun then
        xpcallFun()
    end
    print("----------------------------------------")
    print("LUA ERROR: " .. tostring(msg) .. "\n")
    print(debug.traceback())
    print("----------------------------------------")
    return msg
end

local function main()
    collectgarbage("collect")
    -- avoid memory leak
    collectgarbage("setpause", 100)
    collectgarbage("setstepmul", 5000)
    math.randomseed(os.time());
    -- initialize director
    local director = cc.Director:getInstance()
    local glview = director:getOpenGLView()
    if nil == glview then
        glview = cc.GLViewImpl:createWithRect("HelloLua", FishCD.BASE_WIN_RECT)
        director:setOpenGLView(glview)
    end

   -- glview:setDesignResolutionSize(960, 640, cc.ResolutionPolicy.NO_BORDER)

    --turn on display FPS
    director:setDisplayStats(false)

    --set FPS. the default value is 1.0/60 if you don't call this
    director:setAnimationInterval(1.0 / 60)

    --require("app.MyApp"):create():run()


    cc.exports.mainInstance = require("src/MainManager").create();
    local hotScene = require("Update/UpDateScene").create(false, URLKEY, APP_ID, nil, nil, HALL_WEB_VERSION)
    if cc.Director:getInstance():getRunningScene() then
        cc.Director:getInstance():replaceScene(hotScene)
    else
        cc.Director:getInstance():runWithScene(hotScene)
    end
    Log(cc.FileUtils:getInstance():getSearchPaths())
    --LuaCppAdapter:getInstance():loadDataBin();

    
end

local status, msg = xpcall(main, __G__TRACKBACK__)
if not status then
    print(msg)
end

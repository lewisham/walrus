local evt = {};
local function ClassEx(clsname,fncreate)
    local cls;
    local function _create() 
        local obj = fncreate();
        for k,v in pairs(cls) do
            obj[k] = v;
        end
        return obj;
    end
    cls = class(clsname, _create)
    return cls;
end
local MainManager = ClassEx("MainManager", function()
    local  obj = CGameHallApp.New();
	obj.event= evt;
	return obj ;
end)

function MainManager.create()
	local manager = MainManager.new();
    manager:Initialize();
    manager:init();
	return manager;
end

function MainManager:isReconnecting()
    return self.isReconnecting;
end

--退到后台 断开连接
function MainManager:disconnectHall()
    
end

--进到前台恢复连接
function MainManager:recoveryConnect()
    
end

function MainManager:init()
    self.isReconnecting = false;
end

function MainManager:createLoginManager()
	--登录界面可以在进入场景后玩家使用网络功能后出现网络问题再提示玩家 
    --FishGF.getCurScale()
    if FishGI.hallScene ~= nil then
        if FishGI.hallScene.closeAllSchedule ~= nil then
            FishGI.hallScene:closeAllSchedule()
        end
    end
    FishGI.curGame =  FishGI.GameList.buyu
    local tempTab = HOT_VERSION_FILE;
    local ok,ver=pcall(HOT_VERSION_FILE)
	local scene = require("Login/LoginManager").create();
    FishGI.loginScene = scene;
    if cc.Director:getInstance():getRunningScene() then
        cc.Director:getInstance():replaceScene(scene)
    else
        cc.Director:getInstance():runWithScene(scene)
    end

    --热更新
    --local upDateLayer = require("Updata/hotUpdate/UpDate").create()
    --scene:addChild(upDateLayer,2000)
end

function MainManager:createHallManager(valTab)
    local session = valTab.session;
    local userid = valTab.userid;
    local serverip = valTab.serverip;
    local serverport = valTab.serverport;
	--大厅场景最好等待网络正常连接成功后再转入大厅场景
	local hallNet = require("hall/HallNet").create();
    print("连接到大厅1111");
    if hallNet ~= nil then
        if session == nil or userid == nil or serverip == nil or serverport == nil then
            print("-----------createHallManager--session == nil or userid == nil or serverip == nil or serverport == nil---")
            return 
        end
        if hallNet:ConnectToHall(session,userid,serverip,serverport) then
            if FishGI.isEnterBg then
                print("createHallManager ---------HallManager-----00000---set-");
                --FishGI.hallScene:release();
                FishGI.hallScene:setNet(hallNet);
                FishGI.isEnterBg = false;
            else
                print("createHallManager ---------HallManager-------11111--");
                if FishGI.FRIEND_ROOM_STATUS ~= 0 then
                    FishGF.print("createHallManager ---------HallManager-----friend--11111-setNet-");
                    FishGI.hallScene:setNet(hallNet);
                else
                    local scene = require("hall/HallManager").create(hallNet);
                    scene:retain();
                    FishGI.hallScene = scene;
                    print("createHallManager ----0000-----HallManager----11111-crat-");
                end
            end
            

            --[[if FishGI.hallScene ~= nil then
                cc.Director:getInstance():popScene();
                FishGI.hallScene:release();
                FishGI.hallScene = nil;
            end]]--
            
             print("连接到大厅2222");
        else
            print("连接到大厅失败 ConnectToHall");
        end
    else

    end

end

--解析协议
function MainManager:HandleUrlScheme(uri)
    printf("handleUrlScheme %s",tostring(uri))
    local sctb = string.split(uri,"://")
    if #sctb>1 then
        local func={
            ["joinroom"]= function(p)
                if p.key and #p.key>0 then
                    hallmanager:JoinFriendRoomByRoomKey(p.key)
                else
                    printf("无效scheme参数 %s",tostring(p.key))
                end
            end
        }
        local paths = checktable(string.split(string.split(sctb[#sctb],"?")[1],'/'))
        local cmd= string.lower(checkstring(paths[#paths]))
        if hallmanager and func[cmd] then
            local params=string.parseurl(sctb[#sctb])
            return  pcall(func[cmd],params)
        else
            printf("error scheme  params ")
        end
    end
end

-----------------------------------------------------evt事件表-------------------------------------------
function evt.Initialize(obj)
    return true;
end

return MainManager;
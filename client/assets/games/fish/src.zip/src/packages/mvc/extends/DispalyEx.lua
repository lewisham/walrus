--
-- Author: Your Name
-- Date: 2016-09-19 17:57:54
--

local M=display

function M.pushScene(scene)
	printf("M.pushScene")

end

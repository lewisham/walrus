local CannonPanel = class("CannonPanel", cc.load("mvc").ViewBase)

CannonPanel.isOpen            = false
CannonPanel.AUTO_RESOLUTION   = false
CannonPanel.RESOURCE_FILENAME = "ui/battle/uigunchange"
CannonPanel.RESOURCE_BINDING  = {    
    ["btn_face"]         = { ["varname"] = "btn_face" ,         ["events"]={["event"]="click",["method"]="onClickFace"}},
    ["btn_autofire"]     = { ["varname"] = "btn_autofire" ,     ["events"]={["event"]="click",["method"]="onClickAutoFire"}},
    ["btn_changecannon"] = { ["varname"] = "btn_changecannon" , ["events"]={["event"]="click",["method"]="onClickChange"}},
}

CannonPanel.btn_list  = {    
    { ["varname"] = "btn_autofire"}, 
    { ["varname"] = "btn_face"}, 
    { ["varname"] = "btn_changecannon"}, 
}

function CannonPanel:onCreate( ... )
    self.posArr = {}
    
    local count =  0
    for i, val in ipairs(self.btn_list) do  
        local nodeName = val.varname
        self.posArr[nodeName] = {}
        self.posArr[nodeName].x = self[nodeName]:getPositionX()
        self.posArr[nodeName].y = self[nodeName]:getPositionY()
        self[nodeName].isUsed = true
        count = count +1
    end
    self.btnCount = count

    local spr_autofire = self.btn_autofire:getChildByName("spr_autofire")
    local spr_cancelauto = self.btn_autofire:getChildByName("spr_cancelauto")
    if FishGI.isAutoFire then
        spr_autofire:setVisible(false)
        spr_cancelauto:setVisible(true)
    else
        spr_autofire:setVisible(true)
        spr_cancelauto:setVisible(false)
    end
    
    self.emoji = require("Game/Emoji/EmojiLayer").new()
    FishGI.gameScene:addChild(self.emoji, FishCD.ORDER_GAME_emotion);
    self.emoji:setVisible(false)
    
    self:updateBtnList()

    --self:setBtnIsUsed("btn_changecannon",false)
end

function CannonPanel:getBtnViewData(btnName)
    local btn = self[btnName]
    if btn == nil then
        return 
    end
    return FishGF.getWordPosAndSizeByNode(btn)
end

--
function CannonPanel:setBtnIsUsed(btn, isUsed )
    self[btn]:setVisible(isUsed)
    self[btn].isUsed = isUsed

    local count = 0
    for i,v in ipairs(self.btn_list) do
        local btn = self[v.varname]
        if btn.isUsed == true then
            count = count +1
        end
    end
    self.btnCount = count
    self:updateBtnList()
end

function CannonPanel:updateBtnList()
    local radius = 138
    local angle = 0
    if self.btnCount == 1 then
        angle = 0
    elseif self.btnCount == 2 then
        angle = 60
    else
        angle = 55
    end
    local count = 0
    for i,v in ipairs(self.btn_list) do
        local btn = self[v.varname]
        if btn.isUsed == true then
            count = count +1
            local newAngle = (count - (self.btnCount+1)/2)*angle
            local posY = radius*math.cos(math.rad(newAngle))
            local posX = radius*math.sin(math.rad(newAngle))
            self.posArr[v.varname].x = posX
            self.posArr[v.varname].y = posY
        end
    end

end

function CannonPanel:setIsOpen( isOpen )
    -- if self.isOpen == isOpen then
    --     return
    -- end
    self.isOpen = isOpen
     self:setVisible(true)
    if self.isOpen == true then
        self:setVisible(true)
        local callFun = cc.CallFunc:create(function ( ... )
            local data = {}
            data.node = self
            FishGI.GuideManager:onPlayStep("GunOpen",data)
        end)
        local seq = cc.Sequence:create(cc.DelayTime:create(0.3),callFun)
        seq:setTag(3030)
        self:stopActionByTag(3030)
        self:runAction(seq)
        for nodeName, node in pairs(self.RESOURCE_BINDING) do 
            if self[nodeName].isUsed == true then
                self[nodeName]:setVisible(true)  
                self[nodeName]:stopAllActions()
                self[nodeName]:setPosition(cc.p(0,0))
                self[nodeName]:setScale(0)
                self[nodeName]:runAction(cc.ScaleTo:create(0.1,1))
                self[nodeName]:runAction(cc.MoveTo:create(0.2,cc.p(self.posArr[nodeName].x,self.posArr[nodeName].y)))
            end
        end
    else
        self:stopActionByTag(3030)
        for nodeName, node in pairs(self.RESOURCE_BINDING) do   
            if self[nodeName].isUsed == true then
                self[nodeName]:stopAllActions()
                self[nodeName]:runAction(cc.ScaleTo:create(0.1,0))
                self[nodeName]:runAction(cc.MoveTo:create(0.1,cc.p(0,0)))
                self[nodeName]:runAction(cc.Sequence:create(cc.DelayTime:create(0.1), cc.CallFunc:create( 
                    function() 
                        self[nodeName]:setPosition(cc.p(self.posArr[nodeName].x,self.posArr[nodeName].y))
                        self[nodeName]:setScale(1)
                        self[nodeName]:setVisible(false)
                    end)));
            end
        end
    end
end

function CannonPanel:onClickFace( sender )
    self:setIsOpen(false)
    if self.emoji:isVisible() then
        self.emoji:showFaceDlg(false)
    else
        self.emoji:showFaceDlg(true)
        --self:setVisible(false)
    end

end

function CannonPanel:onClickAutoFire( sender )

    if not FishGI.isGetMonthCard then
        local uiMonthcard = FishGF.getLayerByName("uiMonthcard")
        uiMonthcard:showLayer()
        return
    end
    print("onClickAutoFire")
    if FishGI.isLock then
        return
    end

    FishGI.isAutoFire = not FishGI.isAutoFire
    local spr_autofire = self.btn_autofire:getChildByName("spr_autofire")
    local spr_cancelauto = self.btn_autofire:getChildByName("spr_cancelauto")
    local playerSelf =  FishGI.gameScene.playerManager:getMyData()
    if FishGI.isAutoFire then
        spr_autofire:setVisible(false)
        spr_cancelauto:setVisible(true)
        local degree = playerSelf.cannon.node_gun:getRotation()
        playerSelf:shootByDegree(degree +90);
    else
        spr_autofire:setVisible(true)
        spr_cancelauto:setVisible(false)
        playerSelf:endShoot();
    end
end

function CannonPanel:setAutoFire( isAuto )
    print("setAutoFire")
    FishGI.isAutoFire = isAuto
    local spr_autofire = self.btn_autofire:getChildByName("spr_autofire")
    local spr_cancelauto = self.btn_autofire:getChildByName("spr_cancelauto")
    local playerSelf =  FishGI.gameScene.playerManager:getMyData()
    if FishGI.isAutoFire then
        spr_autofire:setVisible(false)
        spr_cancelauto:setVisible(true)
        local degree = playerSelf.cannon.node_gun:getRotation()
        playerSelf:shootByDegree(degree +90);
    else
        spr_autofire:setVisible(true)
        spr_cancelauto:setVisible(false)
        playerSelf:endShoot();
    end
end

function CannonPanel:onClickChange( sender )
    print("onClickChange")
    local uiSelectCannon = FishGF.getLayerByName("uiSelectCannon")
    uiSelectCannon:showLayer()
end

return CannonPanel;
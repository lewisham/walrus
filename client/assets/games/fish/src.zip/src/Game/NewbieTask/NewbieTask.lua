local NewbieTask = class("NewbieTask", cc.load("mvc").ViewBase)

NewbieTask.AUTO_RESOLUTION   = true
NewbieTask.RESOURCE_FILENAME = "ui/battle/newbietask/uinewbietask"
NewbieTask.RESOURCE_BINDING  = {
    ["panel"]               = { ["varname"] = "panel" },
    ["img_bg"]              = { ["varname"] = "img_bg" },
    ["spr_prop"]            = { ["varname"] = "spr_prop" },
    ["fnt_prop_num"]        = { ["varname"] = "fnt_prop_num" },
    ["img_desc_bg"]         = { ["varname"] = "img_desc_bg" },
    ["text_desc"]           = { ["varname"] = "text_desc" },
    ["img_process_bg"]      = { ["varname"] = "img_process_bg" },
    ["loading_bar_process"] = { ["varname"] = "loading_bar_process" },
    ["process_percentage"]  = { ["varname"] = "process_percentage" },
    ["spr_draw_effect"]     = { ["varname"] = "spr_draw_effect" },
    ["btn_draw"]            = { ["varname"] = "btn_draw", ["events"]={["event"]="click",["method"]="onClickDraw"}},
}

NewbieTask.TASK_TYPE = {
    type_1 = 1, --获得鱼币数
    type_2 = 2, --击杀鱼数
    type_3 = 3, --击杀获得水晶数
    type_4 = 4, --升级炮倍数
}

function NewbieTask:onCreate( ... )
    self:init()
    self:initView()
end

function NewbieTask:init( )
    FishGI.eventDispatcher:registerCustomListener("onGetNewTaskInfo", self, function(valTab) self:onGetNewTaskInfo(valTab) end)
    FishGI.eventDispatcher:registerCustomListener("onGetNewTaskReward", self, function(valTab) self:onGetNewTaskReward(valTab) end)
    self.bTaskExecuting = false
    self.iCurTaskID = 0
    self.iCurTaskType = 0
    self.iCurTaskData = 0
    self.iTotalTaskData = 1
    self.iPorpId = 0
    self.iPropCount = 0
    self.strTaskDesc = ""
end

function NewbieTask:initView( )
    self.scaleX_,self.scaleY_,self.scaleMin_  = FishGF.getCurScale()
    self.winSize = cc.Director:getInstance():getWinSize();
    self.conSize = self.img_bg:getContentSize()
    self.isNewTask = true
    self:runAction(self.resourceNode_["animation"])
end

function NewbieTask:onEnter( )
    local function callbackStartAni()
        self:sendGetNewTaskInfo()
    end
    self:runAction(cc.Sequence:create(cc.DelayTime:create(3), cc.CallFunc:create(callbackStartAni)))
end

function NewbieTask:onExit( )
    self:stopAllActions()
end

function NewbieTask:startAni()
    self.isAct = true
    self:stopActionByTag(20202)
    local posY = self.winSize.height - self.conSize.height/2*self.scaleMin_
    local act = cc.Sequence:create(cc.MoveTo:create(0.5, cc.p(self:getPositionX(), posY)))
    act:setTag(20202)
    self:runAction(act)

end

function NewbieTask:endAni(callback)
    self:stopActionByTag(20202)
    local posY = self.winSize.height + self.conSize.height/2*self.scaleMin_
    local act = cc.Sequence:create(cc.MoveTo:create(0.5, cc.p(self:getPositionX(),posY)), cc.CallFunc:create(callback))
    act:setTag(20202)
    self:runAction(act)

end

--判断是否开始新手引导
function NewbieTask:judgeIsNewGuide()
    if self.bTaskExecuting == false and self.iCurTaskID == 450000003 then
        print("----------start  newDir---------")
        local useData = {}
        useData.propId = self.iPorpId
        FishGI.GuideManager:onStartPlayStep(1,useData)
        -- local data = {}
        -- data.node = self
        -- FishGI.GuideManager:onPlayStep("prop_fly_end",data)
    end
end

function NewbieTask:onTaskProcess( taskID, taskData )
    self.iCurTaskID = 450000000+taskID
    self.iCurTaskData = taskData
    self.iCurTaskType = FishGI.GameTableData:getNewtaskTable(self.iCurTaskID).task_type
    self.iTotalTaskData = FishGI.GameTableData:getNewtaskTable(self.iCurTaskID).task_data
    self.strTaskDesc = FishGI.GameTableData:getNewtaskTable(self.iCurTaskID).task_text
    self.strTmp = FishGI.GameTableData:getNewtaskTable(self.iCurTaskID).reward
    local tRewardData = string.split(FishGI.GameTableData:getNewtaskTable(self.iCurTaskID).reward, ',')
    self.iPorpId = tRewardData[1]
    self.iPropCount = tRewardData[2]
    if not self.bTaskExecuting then
        self:setIfTaskExecuting(true)
        self:refreshPropData()
    end
    self:refreshProcessData()
    if self.iCurTaskData >= self.iTotalTaskData then
        self:setIfTaskExecuting(false)
        self.resourceNode_["animation"]:play("animation0", true)
    end
end

function NewbieTask:isTaskExecuting()
    return self.bTaskExecuting
end

function NewbieTask:getTaskType()
    return self.iCurTaskType
end

function NewbieTask:setIfTaskExecuting(bTaskExecuting)
    if bTaskExecuting == nil then
        bTaskExecuting = false
    end
    self.bTaskExecuting = bTaskExecuting
    self.img_desc_bg:setVisible(bTaskExecuting)
    self.text_desc:setVisible(bTaskExecuting)
    self.img_process_bg:setVisible(bTaskExecuting)
    self.spr_draw_effect:setVisible(not bTaskExecuting)
    self.btn_draw:setVisible(not bTaskExecuting)
end

function NewbieTask:refreshPropData()
    self.spr_prop:initWithFile("common/prop/"..FishGI.GameTableData:getItemTable(self.iPorpId).res)
    if self.iPorpId == "1002" or self.iPorpId == "1003" then
        self.spr_prop:setScale(0.8)
    else
        self.spr_prop:setScale(1)
    end
    self.fnt_prop_num:setString(FishGF.changePropUnitByID(self.iPorpId,self.iPropCount,false))
    self.text_desc:setString(self.strTaskDesc)
end

function NewbieTask:refreshProcessData()
    self.loading_bar_process:setPercent(self.iCurTaskData/self.iTotalTaskData*100)
    self.process_percentage:setString(tostring(self.iCurTaskData) .. "&" .. tostring(self.iTotalTaskData))
end

function NewbieTask:addTaskData( iTaskData )
    if self.bTaskExecuting and self.iCurTaskData < self.iTotalTaskData then 
        self.iCurTaskData = self.iCurTaskData + iTaskData
        if self.iCurTaskData >= self.iTotalTaskData then
            self.iCurTaskData = self.iTotalTaskData
            self:setIfTaskExecuting(false)
        else
            self:refreshPropData()
            self:refreshProcessData()
        end
    end
end

function NewbieTask:onClickDraw( sender )
    self:sendGetNewTaskReward()
end

function NewbieTask:sendGetNewTaskInfo()
    FishGF.waitNetManager(true,nil,"GetNewTaskInfo")
    self.isNewTask = true
    local valTab = {}
    FishGI.gameScene.net:sendGetNewTaskInfo(valTab)
end

function NewbieTask:sendGetNewTaskReward()
    FishGF.waitNetManager(true,nil,"NewTaskReward")
    local valTab = {}
    valTab.nTaskID = self.iCurTaskID
    FishGI.gameScene.net:GetNewTaskReward(valTab)
end

function NewbieTask:onGetNewTaskInfo(valTab)
    FishGF.waitNetManager(false,nil,"GetNewTaskInfo")
    if valTab.isSuccess then
        if valTab.nTaskID ~= -1 or valTab.nTaskData ~= -1 then
            if self.isNewTask then
                self:startAni()
                self.isNewTask = false
            end
            self:setVisible(true)
            self:onTaskProcess(valTab.nTaskID, valTab.nTaskData)
        else
            self:setVisible(false)
        end
    else
    end
end

function NewbieTask:onGetNewTaskReward(valTab)
    FishGF.waitNetManager(false,nil,"NewTaskReward")
    local playerId = valTab.playerID
    local propId = valTab.nPropID
    local propCount = valTab.nPropNum

    if playerId == FishGI.myData.playerId and not (valTab.isSuccess) then
        print("------onGetNewTaskReward fail-----")
        return 
    end

    if table.getn(valTab.SeniorProps) > 0 then
        for i,v in ipairs(valTab.SeniorProps) do
            if playerId ~= FishGI.myData.playerId then
                FishGMF.refreshSeniorPropData(playerId,v,1)
            else
                FishGMF.refreshSeniorPropData(playerId,v,8)
            end
        end
    else
        if playerId ~= FishGI.myData.playerId then
            FishGMF.addTrueAndFlyProp(playerId,propId,propCount,true)
        else
            FishGMF.addTrueAndFlyProp(playerId,propId,propCount,false)
            FishGMF.setAddFlyProp(playerId,propId,propCount,false)
        end
    end   

    if playerId ~= FishGI.myData.playerId then
        return 
    end

    if valTab.isSuccess then
        self:judgeIsNewGuide()
        local function playDropProp( seniorPropData )
            local propTab = {}
            propTab.playerId = playerId
            propTab.propId = propId
            propTab.propCount = propCount
            propTab.isRefreshData = true
            propTab.isJump = false
            local pos,size = FishGF.getWordPosAndSizeByNode(self.spr_prop)
            propTab.firstPos = pos
            propTab.dropType = "normal"
            propTab.isShowCount = true
            propTab.maxScale = self.scaleMin_
            propTab.seniorPropData = seniorPropData
            FishGI.GameEffect:playDropProp(propTab)
            --FishGF.isUseLimitProp( propTab )
        end
        if table.getn(valTab.SeniorProps) > 0 then
            for i,v in ipairs(valTab.SeniorProps) do
                playDropProp(v)
            end
        else
            playDropProp()
        end
    end
    local function callbackEndAni()
        self:sendGetNewTaskInfo()
    end
    self:endAni(callbackEndAni)
end

return NewbieTask
local SetButton = class("SetButton", cc.load("mvc").ViewBase)

SetButton.isOpen            = false
SetButton.AUTO_RESOLUTION   = false
SetButton.RESOURCE_FILENAME = "ui/battle/uisetbutton"
SetButton.RESOURCE_BINDING  = {    
    ["image_bg"]     = { ["varname"] = "image_bg" },   
    ["btn_openlist"] = { ["varname"] = "btn_openlist" ,      ["events"]={["event"]="click",["method"]="onClickOpenlist"}},
    ["spr_triangle"] = { ["varname"] = "spr_triangle" },
    ["btn_pokedex"]  = { ["varname"] = "btn_pokedex"  ,      ["events"]={["event"]="click",["method"]="onClickPokedex"}},    
    ["btn_sound"]    = { ["varname"] = "btn_sound" ,         ["events"]={["event"]="click",["method"]="onClickSound"}},
    ["btn_exit"]     = { ["varname"] = "btn_exit",           ["events"]={["event"]="click",["method"]="onClickExit"} },

}

function SetButton:onKeyboard(code, event)
    if code == cc.KeyCode.KEY_CTRL then
        if GFishScene then
            local bo = GFishScene:getRoot():isVisible()
            GFishScene:getRoot():setVisible(not bo)
        end
    end
end

function SetButton:test()
    self.keyListener = cc.EventListenerKeyboard:create()
    --handler(self,self.onKeyboard)用来关联方法，如果方法直接放在当前位置则可以直接使用无需handler
    self.keyListener:registerScriptHandler(handler(self,self.onKeyboard),cc.Handler.EVENT_KEYBOARD_RELEASED)
    local eventDispatch = self:getEventDispatcher()
    eventDispatch:addEventListenerWithSceneGraphPriority(self.keyListener,self)
end

function SetButton:onCreate( ... )
    self:openTouchEventListener()
    self:test()
end

function SetButton:onTouchBegan(touch, event) 
    if self.isOpen == true then
        self:setIsOpen()
    end   
    return false
end

function SetButton:onTouchCancelled(touch, event)
    if self.isOpen == true then
        self:setIsOpen()
    end     
end

function SetButton:onClickOpenlist( sender )
    print("onClickOpenlist")
    cc.Director:getInstance():setDisplayStats(self.isOpen)
    -- if GFishScene then
    --     local bo = GFishScene:getRoot():isVisible()
    --     GFishScene:getRoot():setVisible(not bo)
    -- end
    self:setIsOpen()
end

function SetButton:setIsOpen( fScaleX )
    print("setIsOpen")
    fScaleX = fScaleX ~= nil and fScaleX or self.scaleMin_
    self.fScaleX = fScaleX
    self.isOpen = not self.isOpen
    
    if self.posTab == nil then 
        self.posTab = cc.p(self:getPositionX(),self:getPositionY())
    end 

    self:stopAllActions()
    if self.isOpen == true then
        self.spr_triangle:setRotation(0)
        self:runAction(cc.MoveTo:create(0.2,cc.p(self.posTab.x-self.image_bg:getContentSize().width*fScaleX*0.9,self.posTab.y)))
    else
        self.spr_triangle:setRotation(180)
        self:runAction(cc.MoveTo:create(0.2,cc.p(self.posTab.x,self.posTab.y)))
    end
end

function SetButton:onClickPokedex( sender )
    if self.isOpen == false then
        return
    end
    print("onClickPokedex")
    local uiFishForm = FishGF.getLayerByName("uiFishForm")

    uiFishForm.isFromLottery = nil
    uiFishForm:showLayer() 
end

function SetButton:onClickSound( sender )
    if self.isOpen == false then
        return
    end
    print("onClickSound")
    local uiSoundSet = FishGF.getLayerByName("uiSoundSet")

    uiSoundSet:initData()
    uiSoundSet:showLayer()
end

function SetButton:onClickExit( sender )
    if self.isOpen == false then
        return
    end
    print("onClickExit")
    self.parent_:buttonClicked("SetButton", "exit")

end
return SetButton;
local ForgedPanel = class("ForgedPanel", cc.load("mvc").ViewBase)

ForgedPanel.AUTO_RESOLUTION   = false
ForgedPanel.RESOURCE_FILENAME = "ui/battle/uiforged"
ForgedPanel.RESOURCE_BINDING  = {    
    ["image_bg"]        = { ["varname"] = "image_bg" },
    ["btn_forged"]      = { ["varname"] = "btn_forged", ["events"]={["event"]="click",["method"]="onClickForged"}},
}

function ForgedPanel:onCreate( ... )
    self:runAction(self.resourceNode_["animation"])
    self:openTouchEventListener()
    self.isForgedAni = false
end

function ForgedPanel:onEnter()
    self.super.onEnter(self)
    FishGI.eventDispatcher:registerCustomListener("ifNeedForged", self, function(isNeedForged) self:ifForgedAni(isNeedForged) end)
end

function ForgedPanel:onTouchBegan(touch, event)
    if not self:isVisible() then
        return false
    end
    local curPos = touch:getLocation()  
    local size = self.image_bg:getContentSize()
    local locationInNode = self.image_bg:convertToNodeSpace(curPos)
    local rect = cc.rect(0,0,size.width,size.height)
    if cc.rectContainsPoint(rect,locationInNode) then
        return true
    end
    return false
end

function ForgedPanel:onClickForged( sender )
    FishGI.gameScene.uiForgedLayer:showLayer()
end

function ForgedPanel:showView(  )
    self:setVisible(true)
    self:setPositionX(-self.image_bg:getContentSize().width)
    local moveto = cc.MoveTo:create(0.2,cc.p(0,self:getPositionY()))
    moveto:setTag(101010)
    self:stopActionByTag(101010)
    self:runAction(moveto)
end

function ForgedPanel:ifForgedAni( isNeedForged )
    if self.isForgedAni == isNeedForged then
        return
    end
    self.isForgedAni = isNeedForged
    if self.isForgedAni then
        self.resourceNode_["animation"]:play("animation0", true)
    else
        self.resourceNode_["animation"]:pause()
    end
end

return ForgedPanel
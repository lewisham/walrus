local SkillViolentCD = class("SkillViolentCD", cc.load("mvc").ViewBase)

SkillViolentCD.AUTO_RESOLUTION   = false
SkillViolentCD.RESOURCE_FILENAME = "ui/battle/skill/uiskillviolentcd.lua"
SkillViolentCD.RESOURCE_BINDING  = {    
    ["panel"]          = { ["varname"] = "panel" }, 
    ["img_cdbg"]          = { ["varname"] = "img_cdbg" }, 
    ["spr_bar"]          = { ["varname"] = "spr_bar" }, 
    ["panel_size"]          = { ["varname"] = "panel_size" }, 

    ["btn_tworate"] = {["varname"] = "btn_tworate", ["events"]={["event"]="click",["method"]="onClickTwoRate"} },
    ["btn_fourrate"] = {["varname"] = "btn_fourrate", ["events"]={["event"]="click",["method"]="onClickFourRate"} },
}

function SkillViolentCD:onCreate(...)
    self.isCountdown = false;
    self.totalTime = 0;
    self.beginTime = 0;

    self.spr_bar:setVisible(false);
    self.progress = cc.ProgressTimer:create(self.spr_bar);
    self.panel:addChild(self.progress, self.spr_bar:getLocalZOrder());
    self.progress:setPosition(cc.p(self.spr_bar:getPositionX(), self.spr_bar:getPositionY()));
    self.progress:setMidpoint(cc.p(0, 0.5));
    self.progress:setBarChangeRate(cc.p(1,0));
    self.progress:setType(cc.PROGRESS_TIMER_TYPE_BAR);
    
end

function SkillViolentCD:start(time, overFunc)
    if self.isCountdown then
        return;
    end
    self.progress:setPercentage(100);
    self.beginTime = os.time();
    self.callFunc = overFunc;
    self.totalTime = time;
    self.isCountdown = true;
    self:runCountdownAct(time);
    print("begin time:"..self.beginTime.." duration:"..time)
end

function SkillViolentCD:updateTimeByRemainTime(remainTime)
    if not self.isCountdown then
        return;
    end
    self.progress:stopAllActions();
    local percent = remainTime/self.totalTime*100;
    self.progress:setPercentage(percent);
    self:runCountdownAct(remainTime);

end

function SkillViolentCD:updateTimeByCurTime(curTime)
    local remainTime = self.totalTime-(curTime-self.beginTime);
    print("cur time:"..curTime.." remain time:"..remainTime)
    self:updateTimeByRemainTime(remainTime);
end

function SkillViolentCD:runCountdownAct(time)

    local seq = cc.Sequence:create(cc.ProgressTo:create(time,0), cc.CallFunc:create(function(sender) self:over(sender) end));
    self.progress:runAction(seq);
end

function SkillViolentCD:onClickTwoRate(sender)
    print("btn click two rate")
    self.btn_fourrate:setBright(true);
    self.btn_fourrate:setTouchEnabled(true);
    self.btn_tworate:setBright(false);
    self.btn_tworate:setTouchEnabled(false);

    --发送切换两倍的消息
    FishGI.gameScene.net:sendSetViolentRate(2);
end

function SkillViolentCD:onClickFourRate(sender)
    print("btn click four rate")
    self.btn_fourrate:setBright(false);
    self.btn_fourrate:setTouchEnabled(false);
    self.btn_tworate:setBright(true);
    self.btn_tworate:setTouchEnabled(true);

    --发送切换四倍的消息
    FishGI.gameScene.net:sendSetViolentRate(4);
end

function SkillViolentCD:over(sender)
    if not self.isCountdown then
        return;
    end
    print("over")
    self.isCountdown = false;
    self.btn_fourrate:setBright(false);
    self.btn_fourrate:setTouchEnabled(false);
    self.btn_tworate:setBright(true);
    self.btn_tworate:setTouchEnabled(true);
    
    if self.callFunc ~= nil then
        self.callFunc();
        self.callFunc = nil;
    end
end

function SkillViolentCD:getPanelSize()
    return self.panel_size:getContentSize();
end

function SkillViolentCD:getPanelPos()
    return self.panel_size:getPosition();
end

return SkillViolentCD;
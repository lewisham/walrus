local SkillLeftView = class("SkillLeftView", cc.load("mvc").ViewBase)

SkillLeftView.isOpen            = false
SkillLeftView.AUTO_RESOLUTION   = true
SkillLeftView.RESOURCE_FILENAME = "ui/battle/skill/uiskill_list_left"
SkillLeftView.RESOURCE_BINDING  = {    
    ["panel"]             = { ["varname"] = "panel" },  
    ["node_skill_left_1"] = { ["varname"] = "node_skill_left_1" },   
    ["node_skill_left_2"] = { ["varname"] = "node_skill_left_2" },
    ["node_skill_left_3"] = { ["varname"] = "node_skill_left_3" },

    ["node_open"] = { ["varname"] = "node_open" },
    
    ["panel_left"]        = { ["varname"] = "panel_left" },
    ["node_skill"]        = { ["varname"] = "node_skill" },  

    ["image_skill_bg"] = { ["varname"] = "image_skill_bg" },
    

}

SkillLeftView.BTN_ARR  = {    
    FishCD.SKILL_TAG_MISSILE,
    FishCD.SKILL_TAG_BOMB,
    FishCD.SKILL_TAG_SUPERBOMB
}

function SkillLeftView:onCreate( ... )
end

function SkillLeftView:initView()
    self.firstPosX = self.node_skill:getPositionX()
    self:setIsOpen()
    self:openTouchEventListener()
    self.panel_left:setSwallowTouches(false)

    self:runAction(self.resourceNode_["animation"])

    local mode = require("Game/Skill/NormalSkill/SkillBtn")
    mode.RESOURCE_FILENAME = "ui/battle/skill/uiskillitem1"
    for i,v in ipairs(self.BTN_ARR) do
        local node = self["node_skill_left_"..(0+i)]
        self:runAction(self["node_skill_left_"..(0+i)].animation)
        node = mode.new(self, node)
        node:initBtn(v,i,#self.BTN_ARR)
        local btn = node:getBtn()
        btn.parentClasss = node
        self["node_skill_left_"..(0+i)] = node
    end

    local node1 = mode.new(self, self.node_open)
    node1:initNormalBtn("battle/skill/bl_btn_hd.png" )
    local btn1 = node1:getBtn()
    btn1:onClickDarkEffect(self:handler(self,self.onClickOpen))
    btn1.parentClasss = node1
    self.node_open = node1
    
    self:initBtn()
    
    self.arrow = cc.Sprite:create("battle/skill/bl_skill_arrow.png")
    self.panel:addChild(self.arrow,100000)
    self.arrow:setVisible(false)

    local eventDispatcher = self:getEventDispatcher()
    local noticeGetBomb = cc.EventListenerCustom:create("noticeGetBomb", handler(self, self.noticeGetBomb))
    eventDispatcher:addEventListenerWithSceneGraphPriority(noticeGetBomb, self)
end

function SkillLeftView:initBtn()
    for i,v in ipairs(self.BTN_ARR) do
        local node = self["node_skill_left_"..(0+i)]:getBtn()
        self:initBtnByPropId(node,v)
    end
end

function SkillLeftView:initBtnByPropId(node,propId)
    print("----------------SkillLeftView:initBtnByPropId------------------")
    node:setTag(propId)
    local name = string.format("battle/skill/bl_pic_skill_prop_%03d.png",propId)
    local spr_lock = node:getChildByName("spr_lock")
    if not spr_lock:initWithFile(name) then
        print("----initWithFile is faile------")
    end
    node.parentClasss:setState(1)
end

function SkillLeftView:onClickOpen( sender )
	self:setIsOpen()
end

function SkillLeftView:onTouchBegan(touch, event) 
    if not self.isOpen then
        return 
    end
    local curPos = touch:getLocation()
    for k,v in pairs(FishCD.SKILLS) do
        local child = self.image_skill_bg
        local s = child:getContentSize()
        local locationInNode = child:convertToNodeSpace(curPos)
        local rect = cc.rect(0,0,s.width,s.height)
        if cc.rectContainsPoint(rect,locationInNode) then
            return false
        end        
    end

    if self.isOpen == true then
        self:setIsOpen()
    end

    return false
end

function SkillLeftView:setIsOpen(isShow,callBack)  
    if isShow == nil then
        isShow = not self.isOpen
    end
    self.isOpen = isShow
    if callBack == nil then
        callBack = function ( ... ) end
    end
    local aimPos = cc.p(0,0)
    if self.isOpen == true then
        aimPos = cc.p(self.firstPosX,self.node_skill:getPositionY())
    else
        aimPos = cc.p(-268,self.node_skill:getPositionY())
        self.arrow:stopAllActions()
        self.arrow:setVisible(false)
    end

    self.node_skill:stopAllActions()
    local seq = cc.Sequence:create(cc.MoveTo:create(0.2,aimPos),cc.CallFunc:create(callBack))
    self.node_skill:runAction(seq)  

end

function SkillLeftView:getBtnByPropId( propId )
    for i,v in ipairs(self.BTN_ARR) do
        local node = self["node_skill_left_"..(0+i)]:getBtn()
        local tag = node:getTag()
        if tag == propId then
            return node
        end
    end
end

function SkillLeftView:setNewUsedPropId( propId )
    local propId = tonumber(propId)
    print("-------------propId="..propId)
    local newBtnArr = {}
    table.insert( newBtnArr, propId )

    local countArr = {}
    for i,v in ipairs(self.BTN_ARR) do
        if propId ~= v then
            table.insert( newBtnArr, v )
        end
        local fnt = self:getBtnByPropId(v):getChildByName("fnt_count")
        countArr[v] =tonumber(fnt:getString())
        print("-----countArr"..countArr[v])
    end

    self.BTN_ARR = newBtnArr
    self:initBtn()
    for k,v in pairs(FishCD.SKILLS) do
        for i,v2 in ipairs(self.BTN_ARR) do
            if v2 == v then
                local skillView = self:getParent():getParent()
                skillView["btn_skill_"..v] = self:getBtnByPropId(v)
                skillView["Skill_"..v]:initDataByPropId(k, v, skillView["btn_skill_"..v],countArr[v])
            end
        end
    end
end

function SkillLeftView:noticeGetBomb( data )
    local propId = data._userdata
    print("-------------------------add bombid="..propId)
    local item = nil
    for i,v in ipairs(self.BTN_ARR) do
        local node = self["node_skill_left_"..(0+i)]:getBtn()
        local tag = node:getTag()
        if tag == propId then
            item = node
            break 
        end
    end

    if item == nil then
        return 
    end

    local callBack = function ( ... )
        self.arrow:setVisible(true)
        self.arrow:stopAllActions()

        local pos,size = FishGF.getWordPosAndSizeByNode(item)
        local locationInNode = self.panel:convertToNodeSpace(pos)
        self.arrow:setPosition(cc.p(locationInNode.x,locationInNode.y+60))

        local moveTime = 0.3
        local seq = cc.Sequence:create(cc.MoveBy:create(moveTime,cc.p(0,20)),cc.MoveBy:create(moveTime,cc.p(0,-20)))
        self.arrow:runAction(cc.RepeatForever:create(seq))

        local delCallBack = cc.Sequence:create(cc.DelayTime:create(3),cc.CallFunc:create(function ( ... )
            self:setIsOpen(false)
        end))
        self.arrow:runAction(delCallBack)

    end

    self:setIsOpen(true,callBack)

end

return SkillLeftView;
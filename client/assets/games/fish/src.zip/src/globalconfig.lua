--全局配置，内容为只读
SEARCH_SRC="src/"  --脚本文件搜索路径
IS_REVIEW_MODE = false;  --//审核模式默认状态
--是否是内网测试
IS_LOCAL_TEST = false
--是否临时维护
IS_TEMP_REPAIR = false;
REPAIR_MSG = "";
--//热线电话
HOT_LINE ="4008-323-777"
--//默认游戏LOGO下载地址
APP_ICON_PATH = "http://assets.weile.com/icon/weile/";
--加盟微信号
WECHAT_ACCOUNT = ""
--大厅接口版本
AUTO_LOGIN=false 
--当前渠道平台
TARGET_PLATFORM_CHANNEL=1  
--文件版本号(LUA版本号)
FILE_VERSION = 1; 
--大厅更新版本
HALL_UPDATE_VERSION = 1;
--0 吉祥 1 微乐
BRAND=1
--大厅版本好(C++版本号)
HALL_APP_VERSION ={1,6,1}; 


if BRAND == 0 then      --吉祥
    local currentPlatform = cc.Application:getInstance():getTargetPlatform();
    --
    SHORT_NAME = "jxjj"
    --域名前缀
    PREFIX_DOMAIN = "-fish"
    --//默认网址
    WEB_DOMAIN = "jixiang.cn";
    -- 应用名字
    APP_NAME="吉祥街机捕鱼";
    --
    IS_WEILE = false;
    --//应用ID platform 3是安卓 0是windows
    if ((currentPlatform == 3) or (currentPlatform == 0)) then 
        APP_ID = 264 
    else 
        APP_ID = 263 
    end
    --//应用KEY
    APP_KEY = "c494c1AA6fAEEdC396b89f52E5Dfa1BE";
    --地区代码
    REGION_CODE= 0
    --游戏id
    GAME_ID = 456;
    --web数据解密key
    URLKEY = APP_ID .. APP_KEY .. APP_ID;
    --微信登录appid
    WX_APP_ID_LOGIN="wxf27383f02b99b8c4"
    --排行榜
    RANK_URL = "https://userapi-fish.jixiang.cn/rank/index"
    --忘记密码
    FORGOT_URL = "https://u.jixiang.cn/"
    --热更新
    UPDATE_URL = "http://078e03.weile.com/update"
    --//渠道ID
    CHANNEL_ID_LIST = {
    	-- ios自运营
	    ios = 12,
        -- 安卓自运营
        android = 13,
    }
    --//应用ID platform 3是安卓 0 是windows
    if (currentPlatform == 3) or (currentPlatform == 0) then 
        CHANNEL_ID = CHANNEL_ID_LIST.android
    else 
        CHANNEL_ID = CHANNEL_ID_LIST.ios 
    end
elseif BRAND == 1 then  --微乐
    local currentPlatform = cc.Application:getInstance():getTargetPlatform();
    --
    SHORT_NAME = "fish"
    --域名前缀
    PREFIX_DOMAIN = "-fish"
    --//默认网址
    WEB_DOMAIN = "weile.com";
    -- 应用名字
    APP_NAME="微乐捕鱼";
    --
    IS_WEILE = true;
    --//应用ID platform 3是安卓 0 是windows
    if (currentPlatform == 3) or (currentPlatform == 0) then 
        APP_ID = 264 
    else 
        APP_ID = 263 
    end
    --//应用KEY
    APP_KEY = "a2E9AcEAa5Dfec6EcA2A3eEDb36DC6a9";
    --地区代码
    REGION_CODE= 0
    --游戏id
    GAME_ID = 226;

    PRODUCT_ID = 263
    --web数据解密key
    URLKEY = APP_ID .. APP_KEY .. APP_ID;
    --微信登录appid
    WX_APP_ID_LOGIN="wxf27383f02b99b8c4"
    --排行榜
    RANK_URL = "https://userapi-fish.weile.com/fish/rank/"
    --忘记密码
    FORGOT_URL = "http://ii.weile.com/forgot/password/"
    --热更新
    UPDATE_URL = "http://client.weile.com/update"
    --//渠道ID
    CHANNEL_ID_LIST = {
        -- 官网
        weile = 200,
        -- 自运营
        tencent = 225,
        -- 百度
        baidu = 202,
        -- 小米
        mi = 205,
        -- oppo
        oppo = 207,
        -- 360
        qihu = 201,
        -- vivo
        vivo = 206,
        -- 华为
        huawei = 224,
        -- 金立
        jinli = 204,
        -- 联想
        lenovo = 208,
        -- 应用宝
        yyb = 210,
        --ios
        ios = 11,
        --今日头条
        jrtt = 723,
        --广点通
        gdt = 209,
        --三星
        samsung = 230,
        --魅族
        mz = 229,
        --热云
        reyun = 226
    }
    --//应用ID platform 3是安卓 0 是windows
    if (currentPlatform == 3) or (currentPlatform == 0) then 
        CHANNEL_ID = CHANNEL_ID_LIST.tencent
    else 
        CHANNEL_ID = CHANNEL_ID_LIST.ios 
    end
    
end
--  wechar: 微信支付
-- alipay_client : 支付宝
-- unionpay_client : 银联支付
-- appstore : 苹果AppStore
PAY_CONFIG={
	["wechat"]={},
	["alipay_client"]={
		partner="",
		email=" ",
		rsa_private="MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBANY3GTv3SaqX/zNMhf4at61rJg1Cm9GpdHujJ3N5LnEtjXL6BwtGUlPe1A+XOSXoqZB1BeOi+aiE6yHfNs643nIPCLsSAmKZSulrssCDjnPOG/MuL8lcOT8c+rbezeWYmS2sm6ynE2lXxNHEA5u1bP+okR/zEdJIB01YgZUFnTJ1AgMBAAECgYEAqhRBIs1qXdoks1Q0ptYLs9L4+VpDYSoL5AZcUmCKsS2buwgtA5Sn1RN8h4xnwWODDcD8FgrV8ijmj5QsbeF2KuCElg+p4g4Moo1A/xznXfDm0ATY+8IzChuQkBtGoBNW1E5PWD0+BkaEf0+FhJDKVzGRAE+JLEyFbTDS9uZ0XwECQQD51oV+utG3cfNqBnedcrO4z6hROUs0tn+y+PuKPZUlVCH09YEkGyDX1Z9fBIRaUCFNiApl/VDIEChpNkbskqphAkEA23+npV2ABGu/ODJ1Fuu/fdJYIPXSGdvu9OalBkP2EpcKulFAH3gklQRfbkp5EBSX7GCFQkBm021hOLKdGA0IlQJBAND1ycXLP2itWCfPrO/1ZbgnhuIYh3xZP8lTUh+3ji0ghx440ICAaCHdvGRehMx8xL3yELBpBM2wJfyJtxxbN0ECQDssmwGVx2Fpus9nqvFW9PTytBeOremSxUT4uRyLTdeNKLM6HFNfjF0wJJoTMbgIFT0AeGx3+ECfiEpEvN0zBlECQGZ9JA9y91mKJS8ZlJrDc2HTB/wphQf5w5Mp+JuKmAWCk5I+k0TYm/8eAD9zTCTDTfrFG/kn0E3L87sEJ3KKGEY="
	},
	["unionpay_client"]={mode="00"},
	["appstore"]={
		[1] = {
			[6] = "com.weile.buyu.money1",
			[12] = "com.weile.buyu.money2",
			[30] = "com.weile.buyu.money3",
			[50] = "com.weile.buyu.money4",
			[108] = "com.weile.buyu.money5",
			[328] = "com.weile.buyu.money6",
			[648] = "com.weile.buyu.money7"
        },
        [2] = {
            [6] = "com.weile.buyu.money8",
            [12] = "com.weile.buyu.money9",
            [30] = "com.weile.buyu.money10",
            [50] = "com.weile.buyu.money11",
            [108] = "com.weile.buyu.money12",
            [328] = "com.weile.buyu.money13",
            [648] = "com.weile.buyu.money14"
        },
        [3] = {
            [30] = "com.weile.buyu.money15"
        },
        [4] = {
            [6] = "com.weile.buyu.money16"
        }
	}
}

function GET_HALL_UPDATE_URL()
    local version = HALL_WEB_VERSION
    local a_id = "/" .. APP_ID
    local c_id = "/" .. CHANNEL_ID
    local verstr="/" .. table.concat(version, ".")
    local completeUrl = UPDATE_URL..a_id..c_id..verstr.. "/" .. Helper.GetDeviceCode()
    return completeUrl;
end
function GET_SMALL_GAME_UPDATE_URL(gameId, version)
    local a_id = "/" .. APP_ID
    local c_id = "/" .. CHANNEL_ID
	local verstr = "/"..version
    local  completeUrl = UPDATE_URL.. "/game"..a_id..c_id.."/"..gameId..verstr
    return completeUrl
end


--功能开关(1:添加游戏;2:开启福袋)
FUN_SWITCH = 0;
--支付开关(1:微信;2:支付宝;4:银联;8:AppStore)
PAY_SWITCH = -1;

HALL_LOCAL_SETTING_FILE = Helper.writepath .."hallconfig.lua"
--执行本地配置，本地配置会覆盖全局配置
if Helper.IsFileExist(HALL_LOCAL_SETTING_FILE) then
	dofile(HALL_LOCAL_SETTING_FILE);
end
---检查大版本号 比较 更新 server>client
function CompareVersion(serVer,clientVer)
    assert(#clientVer>2,"版本号错误")
    assert(#serVer>2,"版本号错误")
    local bgt=clientVer[1]<serVer[1]
    if not bgt and clientVer[1]==serVer[1] then
        bgt= clientVer[2]<serVer[2]        
    end
    if not bgt and clientVer[2]==serVer[2] then
        bgt= clientVer[3]<serVer[3]        
    end
    return bgt
end

--热更新版本文件
local versionPath
local versionPathTmp = SEARCH_SRC.."version"
if cc.FileUtils:getInstance():isFileExist(cc.FileUtils:getInstance():getWritablePath()..versionPathTmp..".wld") then
    versionPath = cc.FileUtils:getInstance():getWritablePath()..versionPathTmp..".wld"
elseif cc.FileUtils:getInstance():isFileExist(versionPathTmp..".wld") then
    versionPath = versionPathTmp..".wld"
elseif cc.FileUtils:getInstance():isFileExist(cc.FileUtils:getInstance():getWritablePath()..versionPathTmp..".lua") then
    versionPath = cc.FileUtils:getInstance():getWritablePath()..versionPathTmp..".lua"
elseif cc.FileUtils:getInstance():isFileExist(versionPathTmp..".lua") then
    versionPath = versionPathTmp..".lua"
end
HOT_VERSION_FILE=loadfile(cc.FileUtils:getInstance():fullPathForFilename(versionPath))
local ok,ver=pcall(HOT_VERSION_FILE)  --大厅动态版本号 热更新自动增加s
 if ok then
    HALL_WEB_VERSION = ver
 else
    HALL_WEB_VERSION = ver
 end
print("热更新版本："..table.concat(HALL_WEB_VERSION,"."))
HALL_LOCAL_SETTING_FILE = cc.FileUtils:getInstance():fullPathForFilename(SEARCH_SRC.."hallconfig.lua") 
--执行本地配置，本地配置会覆盖全局配置
if HALL_LOCAL_SETTING_FILE and Helper.IsFileExist(HALL_LOCAL_SETTING_FILE) then
    dofile(HALL_LOCAL_SETTING_FILE) 
end

if CompareVersion(HALL_APP_VERSION,HALL_WEB_VERSION) then
    -- todo 执行清理操作
    HALL_WEB_VERSION = HALL_APP_VERSION;
    print("clear---------------------------")
    Helper.DeleteFile(Helper.writepath.."res")
    Helper.DeleteFile(Helper.writepath.."src")
    Helper.DeleteFile(HALL_LOCAL_SETTING_FILE)        
end

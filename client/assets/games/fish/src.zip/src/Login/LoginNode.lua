
local LoginNode = class("LoginNode", cc.load("mvc").ViewBase)

LoginNode.AUTO_RESOLUTION   = true
LoginNode.RESOURCE_FILENAME = "ui/login/uiloginnode"
LoginNode.RESOURCE_BINDING  = {    
       ["panel"]            = { ["varname"] = "panel" },
       ["btn_close"]        = { ["varname"] = "btn_close" ,     ["events"]={["event"]="click",["method"]="onClickclose"}},     
       ["btn_OK"]           = { ["varname"] = "btn_OK",         ["events"]={["event"]="click",["method"]="onClickOK"} }, 
       ["btn_cancel"]       = { ["varname"] = "btn_cancel",         ["events"]={["event"]="click",["method"]="onClickclose"} }, 
       
       ["tf_account"]       = { ["varname"] = "tf_account" },     
       ["tf_password"]      = { ["varname"] = "tf_password" }, 
       
       ["btn_openlist"]     = { ["varname"] = "btn_openlist",         ["events"]={["event"]="click",["method"]="onClickopenlist"} }, 
       ["node_accountlist"] = { ["varname"] = "node_accountlist" }, 
       
}

function LoginNode:onCreate( ... )
    self:initWinEditBox("tf_account")
    self:initWinEditBox("tf_password",true)

    self.tf_account:setNewPlaceHolder(FishGF.getChByIndex(800000131))
    self.tf_password:setNewPlaceHolder(FishGF.getChByIndex(800000132))

    self:openTouchEventListener()

    local mode = require("Login/ChangeAccount")
    local node = self.node_accountlist
    self:runAction(self.node_accountlist.animation)
    node = mode.new(self, node)
    self.node_accountlist = node
    self.node_accountlist:setVisible(false)
end

function LoginNode:showLayer()
    self.super.showLayer(self)
    self.node_accountlist:hideLayer(false)
    local accountTab = FishGI.WritePlayerData:getEndData()
    self:setAccountData(accountTab)
    if accountTab == nil then
        self.node_accountlist:setCurAccount("")
    else
        self.node_accountlist:setCurAccount(accountTab["account"])
    end
    

end

function LoginNode:onTouchBegan(touch, event)
    if not self:isVisible() then
         return false
    end
    return true
end

function LoginNode:onClickclose( sender )
    self:hideLayer() 
end

function LoginNode:onClickopenlist( sender )
    local isOpen = self.node_accountlist:isVisible()
    self:setIsOpenList(not isOpen)
end

function LoginNode:setIsOpenList( isOpen )
    if isOpen == true then
        self.btn_openlist:setRotation(180)
    else
        self.btn_openlist:setRotation(0)
    end
    self.node_accountlist:setVisible( isOpen)
end

function LoginNode:onClickOK( sender )
    self:hideLayer() 
    local account   = self.tf_account:getString()
    local password   = self.tf_password:getString()

    if FishGF.checkAccount(account) and FishGF.checkPassword(password) then
        FishGI.lastLoginType = "btn_accountstart"
        self:getParent().net:loginByUserAccount(account, password);
    else
        return false
    end

    print("zhanghao"..account.."mima"..password)  
end

function LoginNode:setAccountData( accountTab )
    if accountTab == nil then
        self.tf_account:setString("")
        self.tf_password:setString("")
        return 
    end
    local account = accountTab["account"]
    local password = accountTab["password"]

    self.tf_account:setString(account)
    self.tf_password:setString(password)

end

return LoginNode;
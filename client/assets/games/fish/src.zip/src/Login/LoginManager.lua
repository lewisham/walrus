local LoginManager = class("LoginManager", function()
	return cc.Scene:create();
end)

function LoginManager.create()
	local manager = LoginManager.new();
	manager:init();
	return manager;
end


function LoginManager:init()
    self.sceneName = "login"
    self.isLoading = false
    --创建视图 创建网络
    if FishGI.isFirstLoad == true then
        self:initLoadingLayer()
        FishGI.isFirstLoad = false
        self.isThirdLogin = false
        if FishGF.isThirdSdk() and FishGF.isThirdSdkLogin() and CHANNEL_ID ~= CHANNEL_ID_LIST.yyb then
            FishGI.lastLoginType = "btn_accountstart"
            local function loginResult(data)
                FishGI.loginScene.net:loginByThird(data)
            end
            self.isThirdLogin = true
            FishGI.GameCenterSdk:trySDKLogin({type = 1},loginResult)
            return 
        end

    else
        self:initLoginLayer()
        -- FishGF.handleOpenUrl_()
    end
	--self:loadEnd()
    --FishGF.clearSwallowLayer()
    
	self:registerEnterBFgroundEvt()

    local function onNodeEvent(event )
        if event == "enter" then
            self:onEnter()
        elseif event == "enterTransitionFinish" then

        elseif event == "exit" then
            self:onExit()
        elseif event == "exitTransitionStart" then

        elseif event == "cleanup" then

        end

    end
    self:registerScriptHandler(onNodeEvent)
    
end

function LoginManager:onEnter()
    self:loadEnd()
    self.isThirdLogin = false
	FishGI.CommonLayer:addLayerToParent(self)
    if FishGI.isTestAccount then
        local function callback(sender)
        
        end
        FishGF.showMessageLayer(FishCD.MODE_MIN_OK_ONLY,FishGF.getChByIndex(800000312),callback);
        --FishGF.showMessageLayer(FishCD.MODE_MIN_OK_ONLY,"测试号码已加入黑名单 无法进入游戏")
        FishGI.isTestAccount = false;
    end
    print("show message")
    local noDelList = {"doPaySDK"}
    FishGF.clearSwallowLayer(noDelList)
    
    if device.platform == "android" then
        local luaBridge = require("cocos.cocos2d.luaj");
        local javaClassName = "org.cocos2dx.lib.Cocos2dxEditBoxHelper";
        local javaMethodName = "openKeyboard";
        local javaParams = {
        1001
        }
        local javaMethodSig = "(I)V";
        local ok = luaBridge.callStaticMethod(javaClassName, javaMethodName, javaParams, javaMethodSig);
    end

end

function LoginManager:onExit()
    -- FishGF.waitNetManager(true,nil,"LoginManageronExit")
end

function LoginManager:initLoadingLayer()
    self.isLoading = true
    self.loadingLayer = require("Loading/LoadingLayer").new()
    self:addChild(self.loadingLayer,FishCD.ORDER_LOADING)
    FishGI.loading_index = 0
    FishGI.loading_sp = 1
    FishGI.isloadingEnd = true;
    self.loadingLayer:preloadRes(function ( ... )
        -- body
    end)
    self:initLoginLayer()
end

function LoginManager:loadEnd()
    self.isLoading = false
    if self.isThirdLogin == true then
        return 
    end
    FishGF.handleOpenUrl_()

end

function LoginManager:initLoginLayer()

	--创建视图 创建网络
	local loginNet = require("Login/LoginNet").create();
	local loginLayer = require("Login/LoginLayer").create();
	if loginNet ~= nil then
		loginLayer:setNet(loginNet)
		loginLayer:setName("loginLayer")
	end

	self:addChild(loginLayer);
	self.view = loginLayer;
	self.net = loginNet;

end

function LoginManager:registerEnterBFgroundEvt()
    --进入前台
    local function onAppEnterForeground()
        print("___LoginManager____enter");
        FishGI.AudioControl:playLayerBgMusic()
        if self.isEnterBg == false then
            return;
        end
        self.isEnterBg = false
        if self.isLoading == false then
            FishGF.handleOpenUrl_()
        end
        
    end

    --进入后台
    local function onAppEnterBackground()
        print("___LoginManager____back");
        self.isEnterBg = true
    end

    local eventDispatcher = self:getEventDispatcher()
    local forelistener = cc.EventListenerCustom:create("applicationWillEnterForeground", onAppEnterForeground)
    eventDispatcher:addEventListenerWithSceneGraphPriority(forelistener, self)
    local backlistener = cc.EventListenerCustom:create("applicationDidEnterBackground", onAppEnterBackground)
    eventDispatcher:addEventListenerWithSceneGraphPriority(backlistener, self)
	
end

function LoginManager:decode()
end

return LoginManager;

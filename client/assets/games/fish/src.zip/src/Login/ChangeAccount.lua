
local ChangeAccount = class("ChangeAccount", cc.load("mvc").ViewBase)

ChangeAccount.AUTO_RESOLUTION   = true
ChangeAccount.RESOURCE_FILENAME = "ui/login/uichangeaccount"
ChangeAccount.RESOURCE_BINDING  = {    
       ["panel"]       = { ["varname"] = "panel" }, 
       ["scroll_list"] = { ["varname"] = "scroll_list",    ["nodeType"]="viewlist"   },
       ["image_down"]  = { ["varname"] = "image_down" }, 
}

function ChangeAccount:onCreate( ... )
    self.scroll_list:setScrollBarEnabled(false)
    self.scroll_list:setSwallowTouches(false)

    local function scrollviewEvent(sender,eventType)
        if eventType==ccui.ScrollviewEventType.scrollToBottom then
           --print("滚动到底部噢")
           --self.image_top:setVisible(true)
           self.image_down:setVisible(false)
        elseif eventType==ccui.ScrollviewEventType.scrollToTop then
            --print("滚动到顶部噢")
            --self.image_top:setVisible(false)
            self.image_down:setVisible(true)
        elseif eventType== ccui.ScrollviewEventType.scrolling then
            --print("滚动中噢")
            --self.image_top:setVisible(true)
            self.image_down:setVisible(true)
        end
    end
    self.scroll_list:addEventListener(scrollviewEvent)

    self:openTouchEventListener()

    self:initData()
end

function ChangeAccount:initData( )
    --self.WritePlayerData = require("Other/WritePlayerData").create();
    FishGI.WritePlayerData:loadFile("accountlist.plist")
    self:delVisitorAccount()
    self.count = FishGI.WritePlayerData:getMaxKeys()
    print("----self.count="..self.count)
    self.curAccount = ""
    self:upDataListByData()
end

--删除游客账号
function ChangeAccount:delVisitorAccount( )
    local accountList = FishGI.WritePlayerData:getAllData()
    for k,data in pairs(accountList) do
        if data ~= nil then
            if data.isVisitor ~= nil and data.isVisitor ~= "" then
                cc.UserDefault:getInstance():setStringForKey("visitorUnname",data.account)
                local key = FishGI.WritePlayerData:getKey("account",data.account)
                FishGI.WritePlayerData:removeByKey(key)
            end
        end
    end
end

function ChangeAccount:setCurAccount( account )
    if account == nil then
        account = ""
    end
    self.curAccount = account
    --self.text_account:setString(account)
end

function ChangeAccount:getEndAccount()
    return FishGI.WritePlayerData:getEndData()
end

function ChangeAccount:upDataListByData( )
    self.accountListView = {}
    local accountList = FishGI.WritePlayerData:getAllData()
    self.cellW = self.scroll_list:getContentSize().width 
    self.sizeH =self.scroll_list:getContentSize().height 
    self.cellH = 0
    for i=1,self.count do
        local data = accountList[tostring(i)]
        if data ~= nil then
            local accountItem = self:addAccount(i,data.account,data.password)
            self.scroll_list:addChild( accountItem)
            self.accountListView[i] = accountItem
            local image_bg = accountItem.panel:getChildByName("image_bg")
            self.cellH = image_bg:getContentSize().height 
        end
    end

    self:upDataListPos()
end

function ChangeAccount:addAccount(tag,account, password)
    local uiaccountItem = require("ui/login/uiaccountitem").create()
    local accountItem = uiaccountItem.root
    accountItem.nodeType = "cocosStudio"
    accountItem["account"] = account
    accountItem["password"] = password
    local text_account = uiaccountItem["text_account"]
    local btn_del = uiaccountItem["btn_del"]
    accountItem["btn_del"] = btn_del
    btn_del:setTag(tonumber(tag))
    btn_del["account"] = account
    btn_del["password"] = password
--    print("------password="..password)
    btn_del:addTouchEventListener(handler(self, self.onDelAccount))
    text_account:setString(account)
    accountItem.panel = uiaccountItem["panel"] 
    accountItem.image_bg = uiaccountItem["image_bg"] 
    return accountItem
end

function ChangeAccount:upDataListPos()
    self.scroll_list:setInnerContainerSize(cc.size(self.cellW, self.cellH*self.count))
--    print("--------------self.count="..self.count.."----self.cellH="..self.cellH)

    if self.accountListView == nil then
        return
    end
    local topY = self.cellH*self.count
    if topY <= self.sizeH then
        topY = self.sizeH
    end
    for i=1,#self.accountListView do
--        print("----self.i="..i)
        local accountItem = self.accountListView[i]
        accountItem:setPosition(cc.p(self.cellW/2,topY - self.cellH/2 - (#self.accountListView - i)*self.cellH ))

        self:setItemState(accountItem,i%2)
    end
end

function ChangeAccount:setItemState(item, state)
    item.colorState = state
    local image_bg = item.image_bg
    if state == 0 then
        image_bg:setColor(cc.c3b(255,255,255))
    elseif state == 1 then
        image_bg:setColor(cc.c3b(231,231,231))
    end
end

function ChangeAccount:setItemIsChoose(item, isChoose)
    item.isChoose = isChoose
    local image_bg = item.image_bg
    if isChoose == true then
        image_bg:setColor(cc.c3b(191,191,191))
    else
        self:setItemState(item,item.colorState)
    end
end

function ChangeAccount:onTouchBegan(touch, event)
    if not self:isVisible() then
        return false  
    end
    --FishGI.AudioControl:playEffect("sound/com_btn01.mp3")
    local curPos = touch:getLocation()  
    self.touchPos = curPos
    local key = nil 
    for k,child in pairs(self.accountListView) do
        local image_bg = child.image_bg
        local s = image_bg:getContentSize()
        local locationInNode = image_bg:convertToNodeSpace(curPos)
        local rect = cc.rect(0,0,s.width,s.height)
        if cc.rectContainsPoint(rect,locationInNode) then
            key = k
            break
        end
    end
    if key ~= nil then
        for k,child in pairs(self.accountListView) do
            local image_bg = child.image_bg
            if child.isChoose == true then
                self:setItemIsChoose(child,false)
            end
            if k == key then
                self:setItemIsChoose(child,true)
                self.curChose = child
            end
        end
        return true
    end
    self:hideLayer(false)
    return true
end

function ChangeAccount:onTouchEnded(touch, event)
    if not self:isVisible() then
        return false  
    end
    local curPos = touch:getLocation()  
    if math.abs(self.touchPos.y - curPos.y) < 10 and math.abs(self.touchPos.x - curPos.x) < 10 then
        self:onClickOK(self)
    else
        --self:setVisible(false)
    end
end

function ChangeAccount:onDelAccount( sender,eventType )
    FishGI.AudioControl:playEffect("sound/com_btn01.mp3")
    if eventType == ccui.TouchEventType.ended then
        local account = sender["account"]
        local function callback(sender2)
            local tag = sender2:getTag()
            if tag == 2 then
                local newData = {};
                local item = nil
                for key, val in ipairs(self.accountListView) do
                    if val["account"] ~= account then
                        table.insert(newData, val);
                    else
                        item = val
                    end
                end
                if newData ~= {} then
                    item:removeFromParent()
                    self.accountListView = newData
                    if account == self.curAccount then
                        self:setCurAccount("")
                        self:getParent():getParent():getParent():setAccountData(nil)
                    end
                    self:removeByKey(account)
                end
            end
        end
        FishGF.showMessageLayer(FishCD.MODE_MIDDLE_OK_CLOSE,FishGF.getChByIndex(800000378),callback)
    end
end

function ChangeAccount:removeByKey( account )
    local key = FishGI.WritePlayerData:getKey("account",account)
    FishGI.WritePlayerData:removeByKey(key)
    self.count = self.count -1
    if self.count < 0 then
        self.count = 0
    end
    self:upDataListPos()
end

function ChangeAccount:onClickOK( sender )
    --FishGI.AudioControl:playEffect("sound/com_btn01.mp3")
    local AccountTab = {}
    if self.curChose ~= nil and self.curChose["account"] ~= nil then
        AccountTab["account"] = self.curChose["account"]
        AccountTab["password"] = self.curChose["password"]
        FishGI.WritePlayerData:upDataAccount(AccountTab)
    else
        local EndAccount = self:getEndAccount()
        if EndAccount ~= nil then
            AccountTab["account"] = EndAccount["account"]
            AccountTab["password"] = EndAccount["password"]
        else
            AccountTab["account"] = ""
            AccountTab["password"] = ""
        end
    end

    self:getParent():getParent():getParent():setAccountData(AccountTab)
    self:setCurAccount(AccountTab["account"])
    self:hideLayer(false)

end

function ChangeAccount:onClickopenlist( sender )
    self:hideLayer(false)
end

function ChangeAccount:hideLayer(isAct )
    self.super.hideLayer(self,isAct)
    for k,child in pairs(self.accountListView) do
        local image_bg = child.image_bg
        if child.isChoose == true then
            self:setItemIsChoose(child,false)
        end
    end
    --self:setVisible(false)
    self:getParent():getParent():getParent():setIsOpenList(false)
end

return ChangeAccount;
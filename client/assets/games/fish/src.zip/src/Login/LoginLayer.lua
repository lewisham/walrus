
local LoginLayer = class("LoginLayer", cc.load("mvc").ViewBase)

LoginLayer.AUTO_RESOLUTION   = true
LoginLayer.RESOURCE_FILENAME = "ui/login/uiloginlayer"
LoginLayer.RESOURCE_BINDING  = {  
    ["btn_start"]          = { ["varname"] = "btn_start" ,        ["events"]={["event"]="click",["method"]="onClickStart"}},  
    ["btn_close"]          = { ["varname"] = "btn_close" ,        ["events"]={["event"]="click",["method"]="onClickClose"}},
    ["spr_logo"]           = { ["varname"] = "spr_logo"  },   
    ["spr_login_bg"]       = { ["varname"] = "spr_login_bg"  },
    
    ["btn_accountstart"]   = { ["varname"] = "btn_accountstart" , ["events"]={["event"]="click",["method"]="onClickaccountstart"}},
    ["btn_wechat"]         = { ["varname"] = "btn_wechat" ,       ["events"]={["event"]="click",["method"]="onClickwechat"}},
    
    ["text_notice"]        = { ["varname"] = "text_notice"  },    
    ["text_ver"]           = { ["varname"] = "text_ver"  },
    ["btn_yyb_qq"]         = { ["varname"] = "btn_yyb_qq" ,       ["events"]={["event"]="click",["method"]="onClickyybqq"}},
    ["btn_yyb_wechat"]     = { ["varname"] = "btn_yyb_wechat" ,   ["events"]={["event"]="click",["method"]="onClickyybwechat"}},
    
    ["btn_retrieve"]       = { ["varname"] = "btn_retrieve" ,     ["events"]={["event"]="click",["method"]="onClickretrieve"}},
    
    ["node_bg_up_left"]    = { ["varname"] = "node_bg_up_left"  },    
    ["node_bg_up_right"]   = { ["varname"] = "node_bg_up_right"  }, 
    ["node_bg_down_left"]  = { ["varname"] = "node_bg_down_left"  }, 
    ["node_bg_down_right"] = { ["varname"] = "node_bg_down_right"  }, 
    
    ["node_btn"]           = { ["varname"] = "node_btn"  }, 
    ["node_btn_qq_wechat"] = { ["varname"] = "node_btn_qq_wechat"  }, 
    
    ["spr_last_login"]     = { ["varname"] = "spr_last_login"  }, 
}

LoginLayer.btn_list  = {  
    "btn_accountstart",
    "btn_start",
    "btn_wechat",
}

function LoginLayer:onCreate(...)
    self:runAction(self.resourceNode_["animation"])
    self.resourceNode_["animation"]:play("fishrun", true);
    
    
    self.text_notice:setString(FishGF.getChByIndex(800000017))
    local ver = "Ver"..table.concat(require("version"),".").."("..CHANNEL_ID..")";
    self.text_ver:setString(ver)

    self:scaleTop()

    self.uiLoginNode = require("Login/LoginNode").create()
    self.uiLoginNode:setPosition(cc.p(cc.Director:getInstance():getWinSize().width/2,cc.Director:getInstance():getWinSize().height/2))
    self:addChild(self.uiLoginNode,1000)
    self.uiLoginNode:setVisible(false)
    self.uiLoginNode:setScale(self.scaleMin_)
    
    FishGI.myData = nil

    local function onKeyboardFunc(code, event)
        if code == cc.KeyCode.KEY_BACK then
            FishGI.AudioControl:playEffect("sound/com_btn01.mp3")
            self:onClickClose(self.btn_close)
        end
    end
    local listener = cc.EventListenerKeyboard:create();
    listener:registerScriptHandler(onKeyboardFunc, cc.Handler.EVENT_KEYBOARD_RELEASED);
    local eventDispatcher = self:getEventDispatcher();
    eventDispatcher:addEventListenerWithSceneGraphPriority(listener, self);


    local isWifi = FishGF.isWifiConnect();
    if isWifi then
        print("---------------------------------wifi connect");
    end

    if device.platform == "ios" then
		PAY_SWITCH = 8;
        self.spr_logo:setTexture("login/ios_login_pic_logo.png");
    end


    self:updateBtnShow()
end

--更新按键列表
function LoginLayer:updateBtnShow( )

    self.node_btn_qq_wechat:setVisible(false)
    self.node_btn:setVisible(true)
    if FishGF.isThirdSdk() and FishGF.isThirdSdkLogin() then
        self.btn_retrieve:setVisible(false)
        self.btn_start:setVisible(false)
    end

    if CHANNEL_ID == CHANNEL_ID_LIST.yyb then
        self.node_btn_qq_wechat:setVisible(true)
        self.node_btn:setVisible(false)
    elseif CHANNEL_ID == CHANNEL_ID_LIST.huawei then
        self.btn_accountstart:loadTextureNormal("login/login_btn_orange_0.png",0)
        self.btn_accountstart:loadTexturePressed("login/login_btn_orange_1.png",0)
        self.btn_accountstart:loadTextureDisabled("login/login_btn_orange_1.png",0)
        local spr_word = self.btn_accountstart:getChildByName("spr_ksks")
        spr_word:setTexture("login/login_pic_ykdl.png")
    end

    if bit.band(FUN_SWITCH, 32) == 32 then
        self:setIsWechat(false)
    else
        self:setIsWechat(true)
    end

    self:updateLastloginType()

end

function LoginLayer:updateLastloginType( )
    local lastLoginType = cc.UserDefault:getInstance():getStringForKey("lastLoginType")
    local btn = self[lastLoginType]
    if btn == nil or lastLoginType == "" then
        self.spr_last_login:setVisible(false)
        return 
    end
    local pos,size = FishGF.getWordPosAndSizeByNode(btn)
    self.spr_last_login:setPositionX(pos.x)
    self.spr_last_login:setPositionY(pos.y + 50)
end

function LoginLayer:setIsWechat( isOpen )
    self.btn_wechat:setVisible(isOpen)

    local count = 0
    for i,v in ipairs(self.btn_list) do
        local btn = self[v]
        if btn~= nil and btn:isVisible() then
            count = count +1
        end
    end

    local dis = 0
    local index = 0
    if count == 3 then
        dis = 350
        index = -2
    elseif count == 2 then
        dis = 364
        index = -1.5
    elseif count == 1 then
        dis = 0
        index = 0
    end
    local a = 1
    for i,v in ipairs(self.btn_list) do
        local btn = self[v]
        if btn ~= nil and btn:isVisible() then
            btn:setPositionX(dis*(a + index))
            a = a + 1
        end
    end

end

function LoginLayer:scaleTop( )
    self.node_bg_up_left:setScale(self.scaleMin_)
    self.node_bg_up_right:setScale(self.scaleMin_)
    self.node_bg_down_left:setScale(self.scaleMin_)
    self.node_bg_down_right:setScale(self.scaleMin_)
    self.node_btn:setScale(self.scaleMin_)
    self.node_btn_qq_wechat:setScale(self.scaleMin_)

end

function LoginLayer:onEnter( )
    FishGI.AudioControl:playLayerBgMusic()
    FishGI.CIRCLE_COUNT = 0
    FishGMF.setGameState(1)
    FishGI.myData = nil
    FishGI.isEnterBg = false
    FishGI.FRIEND_ROOM_STATUS = 0
    FishGI.FRIEND_ROOMID = nil
    FishGI.IS_RECHARGE = 0

    if device.platform == "android" then
        local luaBridge = require("cocos.cocos2d.luaj");
        local javaClassName = "org.cocos2dx.lib.Cocos2dxEditBoxHelper";
        local javaMethodName = "openKeyboard";
        local javaParams = {
        1001
        }
        local javaMethodSig = "(I)V";
        local ok = luaBridge.callStaticMethod(javaClassName, javaMethodName, javaParams, javaMethodSig);
    end

    --移除监听器
    FishGI.eventDispatcher:removeAllListener();
	if device.platform == "android" or device.platform == "ios" then
		cc.Device:setKeepScreenOn(true);
	end
end

function LoginLayer:setNet(net)
    self.net = net;
end
 
function LoginLayer:onClickStart( sender )
    FishGI.lastLoginType = "btn_start"
    if (bit.band(FUN_SWITCH, 2) == 2 and true or false) then
        --服务器正在维护
        FishGF.showMessageLayer(FishCD.MODE_MIDDLE_OK_ONLY,"服务器正在维护中!",nil);
        return;
    end

    if IS_TEMP_REPAIR then 
        FishGF.showMessageLayer(FishCD.MODE_MIDDLE_OK_ONLY,REPAIR_MSG,nil);
        return;
    end

    if FishGF.isThirdSdk() and FishGF.isThirdSdkLogin() then
        local function loginResult(data)
            FishGI.loginScene.net:loginByThird(data)
        end
        print("third log----------------------------")
        FishGF.waitNetManager(true,nil,nil,0)
        FishGI.GameCenterSdk:trySDKLogin({type = 1},loginResult)
        return
    end
    
    self.net:VisitorLogin()

end

function LoginLayer:onClickaccountstart( sender )
    FishGI.lastLoginType = "btn_accountstart"
    if (bit.band(FUN_SWITCH, 2) == 2 and true or false) then
        --服务器正在维护
        FishGF.showMessageLayer(FishCD.MODE_MIDDLE_OK_ONLY,"服务器正在维护中!",nil);
        return;
    end

    if IS_TEMP_REPAIR then
        FishGF.showMessageLayer(FishCD.MODE_MIDDLE_OK_ONLY,REPAIR_MSG,nil);
        return;
    end

    if FishGF.isThirdSdk() and FishGF.isThirdSdkLogin() then
        local function loginResult(data)
            print("loginResult log----------------------------")
            dump(data)
            FishGI.loginScene.net:loginByThird(data)
        end
        FishGF.waitNetManager(true,nil,nil,0)
        FishGI.GameCenterSdk:trySDKLogin({type = 2},loginResult)
        return
    end

    local accountTab = FishGI.WritePlayerData:getEndData()
    if accountTab ~= nil then
        self.uiLoginNode:setAccountData(accountTab)
    end

    self.uiLoginNode:showLayer() 
    return true
end

function LoginLayer:changeAccount( )
    self.uiLoginNode:showLayer() 
end

function LoginLayer:onClickClose( sender )
    if FishGF.isThirdSdk() and FishGF.isThirdSdkExit() then
        local closeCallback = function ( jsons )
            log("exit game:" .. jsons)
            local result = json.decode(jsons)
            if CHANNEL_ID == CHANNEL_ID_LIST.qihu or CHANNEL_ID == CHANNEL_ID_LIST.baidu then
                local tag = tonumber(result.resultMsg)
                if tag == 2 then
                    os.exit(0);
                end
            else
                local code = tonumber(result.resultCode)
                if code == 0 then
                    os.exit(0);
                end
            end
        end

        FishGI.GameCenterSdk:trySDKGameExit({}, closeCallback)

        return
    end

    local function callback(sender)
        local tag = sender:getTag()
        if tag == 2 then
            os.exit(0);
        end
    end   
    FishGF.showExitMessage(FishGF.getChByIndex(800000139),callback)
end

function LoginLayer:onClickyybqq( sender )
    print("--onClickqq---")
    FishGI.lastLoginType = "btn_yyb_qq"
    if FishGF.isThirdSdk() and 
        FishGI.GameCenterSdkBase.ChannelInfoList[FishGI.GameCenterSdkBase.ChannelIdList[CHANNEL_ID]][FishGI.GameCenterSdkBase.ChannelInfoIndex.is_need_login] then
        local function loginResult(data)
            FishGI.loginScene.net:loginByThird(data)
        end
        FishGI.GameCenterSdk:trySDKLogin({type = 1},loginResult)
    end


end

function LoginLayer:onClickyybwechat( sender )
    print("--onClickwechat---")
    FishGI.lastLoginType = "btn_yyb_wechat"
    if FishGF.isThirdSdk() and 
        FishGI.GameCenterSdkBase.ChannelInfoList[FishGI.GameCenterSdkBase.ChannelIdList[CHANNEL_ID]][FishGI.GameCenterSdkBase.ChannelInfoIndex.is_need_login] then
        local function loginResult(data)
            FishGI.loginScene.net:loginByThird(data)
        end
        FishGI.GameCenterSdk:trySDKLogin({type = 2},loginResult)
    end
end

function LoginLayer:onClickretrieve( sender )
    print("--onClickretrieve---")
    local url = "";
    if FORGOT_URL == nil then
        if BRAND == 0 then
            url = "https://u.jixiang.cn/";
        elseif BRAND == 1 then
            url = "http://ii.weile.com/forgot/password/";
        end
    else
        url = FORGOT_URL
    end

    cc.Application:getInstance():openURL(url);
    
end

function LoginLayer:onClickwechat( sender )
    print("--onClickwechat---")
    FishGI.lastLoginType = "btn_wechat"
    if (bit.band(FUN_SWITCH, 2) == 2 and true or false) then
        --服务器正在维护
        FishGF.showMessageLayer(FishCD.MODE_MIDDLE_OK_ONLY,"服务器正在维护中!",nil);
        return;
    end

    if IS_TEMP_REPAIR then
        FishGF.showMessageLayer(FishCD.MODE_MIDDLE_OK_ONLY,REPAIR_MSG,nil);
        return;
    end
    
    FishGF.setAccountAndPassword(nil,nil,nil)

    local function callfuncAndroid(resultStr)
        FishGF.waitNetManager(false,nil,"StartWechat")
        local ok, resultInfo = pcall(function()         
            return loadstring(resultStr)();
        end)
        resultInfo.method = "wechat";
        if tonumber(resultInfo.status) == 0 then
            FishGI.loginScene.net:loginByThird(resultInfo)
        end
    end

    local function callfuncIOS(arg0, arg1, arg2)
        local resultInfo = json.decode(arg1, 1);
        dump(resultInfo)
        resultInfo.method = "wechat";
        --wechat callfunc ret:return { status=0,code="081eTKWE1PK5P00XijXE1wdlWE1eTKW1"}
        if tonumber(resultInfo.status) == 0 then
            FishGI.loginScene.net:loginByThird(resultInfo)
        end
    end
    if device.platform == "android" then
        FishGF.doWechatLogin(callfuncAndroid);
    elseif device.platform == "ios" then
        FishGF.doWechatLogin(callfuncIOS);
    end

end

function LoginLayer:autoLogin( )

    local lastLoginType = cc.UserDefault:getInstance():getStringForKey("lastLoginType")
    local btn = self[lastLoginType]
    if btn == nil or lastLoginType == "" then
        if FishGF.isThirdSdk() and FishGF.isThirdSdkLogin() and CHANNEL_ID ~= CHANNEL_ID_LIST.yyb then
            FishGI.lastLoginType = "btn_accountstart" 
            local function loginResult(data)
                FishGI.loginScene.net:loginByThird(data)
            end
            FishGI.GameCenterSdk:trySDKLogin({type = 1},loginResult)
            return 
        end
        self:onClickStart(self)
        return 
    end

    if lastLoginType == "btn_accountstart" then
        local result = self:onClickaccountstart(btn)
        if result == true then
            local result2 = self.uiLoginNode:onClickOK(btn)
        end
        self.uiLoginNode:hideLayer(false)
        return 
    end

    for k,v in pairs(self.RESOURCE_BINDING) do
        if v.varname == lastLoginType then
            local backFun = handler(self,self[v.events.method])
            backFun(btn)
            return 
        end
    end

    self:onClickStart(self)

end

return LoginLayer;

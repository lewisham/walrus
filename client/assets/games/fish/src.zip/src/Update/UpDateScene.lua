local UpDateScene = class("UpDateScene", function()
    return cc.Scene:create();
end)

function UpDateScene.create()
    local obj = UpDateScene.new();
    obj:init();
    return obj;
end

function UpDateScene:init()
    self.update = require("Update/UpdateModule/Update").create();

    local function getChannelId()
	    if device.platform == "android" then
	        local luaBridge = require("cocos.cocos2d.luaj");
	        local javaClassName = "com.weile.api.NativeHelper";
	        local javaMethodName = "getChannelId";
	        local javaParams = {
	            "asdawdwad"
	        }
	        local javaMethodSig = "(Ljava/lang/String;)I";
	        local ok, ret = luaBridge.callStaticMethod(javaClassName, javaMethodName, javaParams, javaMethodSig);
	        return ret;
	    end
    end
    
    if device.platform == "android" then
		CHANNEL_ID = getChannelId()
    end
    
    --
    self.view = require("Update/hotUpdate/UpDate").create();
    self:addChild(self.view);

    --大版本更新界面
	self.bigUpdateView = require("Update/bigUpdate/BigUpDate").create();
	self.bigUpdateView:setPosition(cc.p(cc.Director:getInstance():getWinSize().width/2,cc.Director:getInstance():getWinSize().height/2));
	self:addChild(self.bigUpdateView);
	self.bigUpdateView:setVisible(false);

    self:registerListener();
end

function UpDateScene:registerListener()
    local function onNodeEvent(event )
        if event == "enter" then
            self:onEnter()
        elseif event == "enterTransitionFinish" then

        elseif event == "exit" then
            self:onExit()
        elseif event == "exitTransitionStart" then

        elseif event == "cleanup" then

        end

    end
    self:registerScriptHandler(onNodeEvent)

	self.updateCompelteListener=cc.EventListenerCustom:create("updateComplete",handler(self, self.updateComplete))  
    cc.Director:getInstance():getEventDispatcher():addEventListenerWithFixedPriority(self.updateCompelteListener, 2)

	self.updateErrorListener=cc.EventListenerCustom:create("updateError",handler(self, self.checkVersionRetry))  
    cc.Director:getInstance():getEventDispatcher():addEventListenerWithFixedPriority(self.updateErrorListener, 2)

	self.updateNoticeListener=cc.EventListenerCustom:create("updateNotice",handler(self, self.showBigUpdate))  
    cc.Director:getInstance():getEventDispatcher():addEventListenerWithFixedPriority(self.updateNoticeListener, 2)

	self.beginDownloadListener=cc.EventListenerCustom:create("beginDownload",handler(self, self.openUpdateUI))  
    cc.Director:getInstance():getEventDispatcher():addEventListenerWithFixedPriority(self.beginDownloadListener, 2)

	self.updateNoticeListener=cc.EventListenerCustom:create("updating",handler(self, self.updateViewPercent))  
    cc.Director:getInstance():getEventDispatcher():addEventListenerWithFixedPriority(self.updateNoticeListener, 2)
end

function UpDateScene:removeListener()
    cc.Director:getInstance():getEventDispatcher():removeEventListener(self.updateCompelteListener);
    cc.Director:getInstance():getEventDispatcher():removeEventListener(self.updateErrorListener);
    cc.Director:getInstance():getEventDispatcher():removeEventListener(self.updateNoticeListener);
    cc.Director:getInstance():getEventDispatcher():removeEventListener(self.beginDownloadListener);
    cc.Director:getInstance():getEventDispatcher():removeEventListener(self.updateNoticeListener);
end

function UpDateScene:onEnter()
    self:startUpdate();
end

function UpDateScene:onExit()
    self:removeListener()
    self.update = nil;
end

function UpDateScene:showMessageLayer(messageType,strMsg,callback,scene,strHook)
	local curScene = (scene == nil and cc.Director:getInstance():getRunningScene() or scene);
    if curScene == nil or type(curScene) == "number" then
        return
    end
    
    local noticeType = curScene:getChildByName("MessageDialog")
    if noticeType == nil then
        noticeType = require("Message/MessageDialog").create()
        noticeType:setData(messageType,strMsg,callback,strHook)
        noticeType:setName("MessageDialog")
        curScene:addChild(noticeType,3000)
        noticeType:setPosition(cc.p(cc.Director:getInstance():getWinSize().width/2,cc.Director:getInstance():getWinSize().height/2))
		noticeType:setVisible(true);
    else
        noticeType:setData(messageType,strMsg,callback,strHook)
        noticeType:setVisible(true);
    end
end

--更新完成
function UpDateScene:updateComplete(evt)
    local data = evt._userdata;
    local updateId = data.id;
    if updateId == self.update:getId() then
        self:runNextScene();
    end
end

--版本检查失败
function UpDateScene:checkVersionRetry(evt)
    local data = evt._userdata;
    local updateId = data.id;
    if updateId == self.update:getId() then
        print("checkVersionRetry")
        local event = cc.EventCustom:new("cleanUpdate")
        event._userdata = {id = self.update:getId()}
        cc.Director:getInstance():getEventDispatcher():dispatchEvent(event)

        local function callback(sender)
            local tag = sender:getTag()
            if tag == 2 then
                self:startUpdate();
            elseif tag == 3 then
                os.exit(0);
            end
        end
        self:showMessageLayer(3,"版本检测失败，请重试！",callback)
    end
end

--显示大版本更新提示界面
function UpDateScene:showBigUpdate(evt)
    local data = evt._userdata;
    local updateId = data.id;
    local version = data.version;
	local notice = data.notice;
	local func = data.callback;
    if updateId == self.update:getId() then
        local function wifiTips()
            local isWifi = self:isWifiConnect();
            if isWifi == true then
                func();
            else
                local function callback(pSender)
                    local tag = pSender:getTag()
                    if tag == 2 then
                        func()
                    else
                        os.exit(0);
                    end
                end
                self:showMessageLayer(3,"您当前网络环境为非WIFI模式，是否使用流量继续下载更新资源？",callback);
            end
        end
        self.bigUpdateView:setVisible(true)
	    self.bigUpdateView:setCurVersions(version);
	    self.bigUpdateView:setVersionsData(notice);
	    self.bigUpdateView:setUpdateFunc(wifiTips);
    end
end

--开始下载更新
function UpDateScene:openUpdateUI(evt)
    local data = evt._userdata;
    local updateId = data.id;
    if updateId == self.update:getId() then
        print("openUpdateUI")
        self.view:isCheckVer(false);
    end
end

--更新下载进度
function UpDateScene:updateViewPercent(evt)
    local data = evt._userdata
    local updateId = data.id
	local cur = data.cur
	local all = data.total
	local speed = data.speed
	local progress = data.progress

    if updateId == self.update:getId() then
        self.view:receiveData(cur,all,speed);
    end
end

function UpDateScene:startUpdate()
    print("startUpdate")
    local event = cc.EventCustom:new("startUpdate");
    local url = GET_HALL_UPDATE_URL();
    local cmdType = require("Update/UpdateModule/UpdateConstant").CommandType.VERSION_CHECK;
    event._userdata = {id = self.update:getId(), url = url, cmdType = cmdType};
    cc.Director:getInstance():getEventDispatcher():dispatchEvent(event);
end

function UpDateScene:isWifiConnect()
	if device.platform == "android" then
		local luaBridge = require("cocos.cocos2d.luaj");
        local javaClassName = "com.weile.api.GameBaseActivity";
        local javaMethodName = "isNetworkConnected";
        local javaParams = {
        }
        local javaMethodSig = "()Z";
        local isSuccess, isWifi = luaBridge.callStaticMethod(javaClassName, javaMethodName, javaParams, javaMethodSig);
		return isWifi;
    else
        return false
	end
    
end

function UpDateScene:runNextScene()
    self:loadFileConfig();
    mainInstance:createLoginManager();
end

function UpDateScene:loadFileConfig()
    LuaCppAdapter:getInstance():loadDataBin();
    cc.exports.FishGI = nil;
	cc.exports.FishGF = nil;
	cc.exports.FishCD = nil;
	package.loaded["Other/LoadFile"] = nil;
	package.loaded["GlobalCom/ConstantDef"] = nil;
	package.loaded["GlobalCom/GlobalFunc"] = nil;
	package.loaded["GlobalCom/GameFunc"] = nil;
	package.loaded["GlobalCom/GlobalInstance"] = nil;
	package.loaded["Other/NetMessage"] = nil;
	package.loaded["Other/LoadFile"] = nil;
	cc.FileUtils:getInstance():purgeCachedEntries();
    require("Other/LoadFile");

    if FishGI.SYSTEM_STATE == 0 then
        FishGI.serverConfig[1].url = self.update:getData("ip");
        FishGI.serverConfig[1].port = self.update:getData("port");
    end
end

return UpDateScene
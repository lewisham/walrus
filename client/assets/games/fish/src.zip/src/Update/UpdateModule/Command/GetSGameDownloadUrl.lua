local GetSGameDownloadUrl = class("GetSGameDownloadUrl", require("Update/UpdateModule/Command/CommandBase"))

function GetSGameDownloadUrl.create(data)
    local obj = GetSGameDownloadUrl.new()
    obj:init(data)
    return obj
end

function GetSGameDownloadUrl:init(data)
    self.super.init(self)
    self.url = data.url
    self.constant = require("Update/UpdateModule/UpdateConstant");
end

function GetSGameDownloadUrl:doCommand()
    self.super.doCommand(self);
end

function GetSGameDownloadUrl:onHttpComplete()
    print("on http complete GetSGameDownloadUrl")
    local str = self.http:GetData();
    local result = loadstring(str)();
    if result ~= nil and result.url ~= nil then
        dump(result)
        local type = self.constant["CommandType"].GET_UPDATE_LIST
        local data = {url = result.url}
        self.updateManager:createCommand({type = type, data = data})
    end

    self.updateManager:finish(self.id);
end

function GetSGameDownloadUrl:onHttpError(http, strError)
    print("error2:"..strError)
    self.updateManager:updateError();
end

return GetSGameDownloadUrl;
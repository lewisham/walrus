local PayApple = class("PayApple", require("ThridPartySDK/pay/module/PayBase"))

function PayApple.create()
	local obj = PayApple.new();
	obj:init(payInfo);
	return obj;
end

function PayApple:init()
	PayApple.super.init(self);
end

function PayApple:doPay(payInfo)
	payInfo["type"] = "appstore";
	PayApple.super.doPay(self, payInfo)
end

function PayApple:doPayAndroid(payInfo)
	print("暂未开放iap的安卓支付")
end

return PayApple;
local VivoSDKInterface = class("VivoSDKInterface", FishGI.GameCenterSdkBase)

local openId = nil

--[[

Java 方法原型:
public static void doPay(final int payAmount, int cbId)

Java 方法原型:
public static void doLogin()

-- Java 类的名称
local className = "weile/buyu/game/AppActivity"
-- 调用 Java 方法
luaj.callStaticMethod(className, "doBilling", args)

]]

function VivoSDKInterface:trySDKLogin(info, loginCB)
    local function callBackDoLogin( strJson )
        print("--------callBackDoLogin", strJson)
        local resultTab = LIB_CJSON.decode(strJson)
        local resultMsg = LIB_CJSON.decode(resultTab.resultMsg)
        local resultData = {}
        resultData.username = resultMsg.userName
        resultData.authtoken = resultMsg.authToken
        openId = resultMsg.openId
		loginCB(resultData)
    end
    self:doLogin(info, callBackDoLogin)
    return true
end

function VivoSDKInterface:doSDKLogout(info, logoutCB)
    self:doLogout(info, logoutCB)
    return true
end

function VivoSDKInterface:trySDKGameExit(info, exitCallback)
    self:doGameExit(info, exitCallback)
    return true
end

function VivoSDKInterface:trySDKPay(payArgs, payCB)
    local payInfo = {}
    payInfo.order = payArgs.ext.orderNumber
    payInfo.amount = payArgs.ext.orderAmount
    payInfo.signature = payArgs.ext.accessKey
    payInfo.productName = payArgs.name
    payInfo.productDesc = payArgs.name
    payInfo.openId = openId
    self:doPay(payInfo, payCB)
    return true
end

return VivoSDKInterface
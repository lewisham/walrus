local GuideStep = class("GuideStep")

function GuideStep.create(info)
    local obj = GuideStep.new();
    obj:init(info);
    return obj;
end

function GuideStep:init(info)
    self.id = info.stepId;
    self.info = info;
    self.components = {};
end

function GuideStep:createComponent(componentInfo)
    local constant = require("common/BeginnerGuide/BeginnerGuide").COMPONENT;
    if componentInfo.type == constant.SWALLOW then
        local component = require("common/BeginnerGuide/Component/Swallow").create(componentInfo.args);
        table.insert(self.components, component);
    elseif componentInfo.type == constant.POINT then
        local component = require("common/BeginnerGuide/Component/Pointer").create(componentInfo.args);
        table.insert(self.components, component);
    end
end

function GuideStep:doStep(args)
    for key, val in pairs(self.info.components) do
        self:createComponent(val);
    end

    for key, val in pairs(self.components) do
        val:doComponent(args);
    end
end

function GuideStep:stepOver()
    self.id = nil;
    self.info = nil;
    for key, val in pairs(self.components) do
        val:remove();
    end
end

function GuideStep:getId()
    return self.id
end

return GuideStep;
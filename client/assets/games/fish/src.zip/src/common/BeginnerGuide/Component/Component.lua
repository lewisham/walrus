local Component = class("Component")

function Component:init(type)
    self.beginnerGuideComponentNotify =cc.EventListenerCustom:create("beginnerGuideComponentNotify",handler(self, self.onNotify))  
    cc.Director:getInstance():getEventDispatcher():addEventListenerWithFixedPriority(self.beginnerGuideComponentNotify, 1)
    self.type = type;
end

function Component:doComponent(args)
end

function Component:remove()
    cc.Director:getInstance():getEventDispatcher():removeEventListener(self.beginnerGuideComponentNotify)
end

function Component:notify(args)
    args.componentType = self.type;
    local event = cc.EventCustom:new("beginnerGuideComponentNotify")
    event._userdata = args
    cc.Director:getInstance():getEventDispatcher():dispatchEvent(event)
end

function Component:onNotify(evt)
    return evt._userdata;
end

return Component
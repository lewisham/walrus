local Pointer = class("Pointer", require("common/BeginnerGuide/Component/Component"))

function Pointer.create()
    local obj = Pointer.new();
    obj:init();
    return obj;
end

function Pointer:init()
    local constant = require("common/BeginnerGuide/BeginnerGuide").COMPONENT;
    Pointer.super.init(self, constant.POINT)
end

function Pointer:doComponent(args)
    Pointer.super.doComponent(self);
    local pos = cc.p(0, 0);
    local size = cc.size(0, 0);
    if args.node ~= nil then
        pos = cc.p(args.node:getParent():convertToWorldSpace(cc.p(args.node:getPositionX(), args.node:getPositionY())))
        size = cc.size(args.node:getContentSize().width, args.node:getContentSize().height);
    elseif args.pos ~= nil and args.size ~= nil then
        pos = args.pos;
        size = args.size;
    end

    local function frameEvent( frameEventName)
    end
    local function clickCallback(evt, eventName)
        if eventName == ccui.TouchEventType.ended then
            if args.func ~= nil then
                args.func();
            end
        end
    end
    local curScene = cc.Director:getInstance():getRunningScene();
    local fingerTemplate = require("ui/common/uiguideeffect").create();
    self.finger = fingerTemplate.root;
    self.finger.animation = fingerTemplate["animation"];
    self.finger:setPosition(cc.p(pos));
    self.finger:runAction(fingerTemplate["animation"]);
    fingerTemplate["animation"]:setFrameEventCallFunc(frameEvent);
    

    self.clickBtn = ccui.Button:createInstance();
    self.clickBtn:addTouchEventListener(clickCallback);
    self.clickBtn:setPosition(cc.p(pos))
    self.clickBtn:setScale9Enabled(true);
    self.clickBtn:setContentSize(cc.size(size.width, size.height));

    self.targetPos = pos;

    curScene:addChild(self.finger, FishCD.ORDER_LOADING-1);
    curScene:addChild(self.clickBtn, FishCD.ORDER_LOADING-1);

    self:moveTo(self.targetPos);
end

function Pointer:remove()
    print("component pointer remove")
    Pointer.super.remove(self);

    local curScene = cc.Director:getInstance():getRunningScene();
    curScene:removeChild(self.finger);
    curScene:removeChild(self.clickBtn);
    self.finger = nil;
    self.clickBtn = nil;
end

function Pointer:moveTo(clickPos)
    local function callfunc(sender)
        self.finger.animation:play("guide", true);
    end
    self.finger.animation:play("finger", false);
    local speed = 700;
    local distance = math.sqrt(cc.pDistanceSQ(self.targetPos,clickPos));
    local act1 = cc.MoveTo:create(distance/speed, cc.p(self.targetPos));
    local act2 = cc.CallFunc:create(callfunc);
    local act = cc.Sequence:create(act1, act2);
    act:setTag(11112)
    self.finger:setPosition(cc.p(clickPos));
    self.finger:stopActionByTag(11112);
    self.finger:runAction(act);
end

function Pointer:onNotify(evt)
    local constant = require("common/BeginnerGuide/BeginnerGuide").COMPONENT;
    local data = Pointer.super.onNotify(self, evt);
    if data.componentType == constant.SWALLOW then
        
        local clickPos = data.pos;
        self:moveTo(clickPos);
        
    end
end

return Pointer
local ExperienceBattery = class("ExperienceBattery")

function ExperienceBattery.create()
    local obj = ExperienceBattery.new();
    return obj;
end

function ExperienceBattery:test(args)
    dump(args)
end

return ExperienceBattery
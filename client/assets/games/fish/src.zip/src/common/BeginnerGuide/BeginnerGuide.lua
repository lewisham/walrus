
local BeginnerGuide = class("BeginnerGuide")
BeginnerGuide.COMPONENT = {
    SWALLOW = 10001,
    POINT = 10002,
}

function BeginnerGuide.create(stepsInfo)
    local obj = BeginnerGuide.new();
    obj:init(stepsInfo);
    return obj;
end

function BeginnerGuide:init(stepsInfo)
    self.steps = {}
    self.info = stepsInfo

    for key, val in ipairs(self.info) do
        local step = self:createStep(val);
        table.insert(self.steps, step);
    end
end

function BeginnerGuide:createStep(stepInfo)
    local step = require("common/BeginnerGuide/GuideStep").create(stepInfo);
    return step;
end

function BeginnerGuide:start(args)
    if table.maxn(self.steps) > 0 then
        self.steps[1]:doStep(args)
    end
end

function BeginnerGuide:nextStep(args)
    local nextStep = self.steps[2];
    self.steps[1]:stepOver();
    table.remove(self.steps, 1);
    nextStep:doStep(args);
end

function BeginnerGuide:guideOver()
    for key, val in pairs(self.steps) do
        val:stepOver();
    end
end

function BeginnerGuide:clear()
    self:guideOver();
    self.info = nil;
    self.steps = {};
end

function BeginnerGuide:getCurStepId()
    return self.steps[1]:getId();
end

return BeginnerGuide
local GuideManager = class("GuideManager")

function GuideManager.create()
    local obj = GuideManager.new();
    obj:init();
    return obj;
end

GuideManager.CUR_PLAY_TYPE = {
   [1] = { DEF = "TRY_LIMIT_STEP" , FUN = "LimitGunStep"  },  --体验限时炮台

}


GuideManager.TRY_LIMIT_STEP = {
--    "NewbieTask_LimitGun",    --新手任务完成第一个限时炮台任务
    "prop_fly_end",             --道具飞行结束
    "GunOpen",              --炮台打开
    "changeGunLayerOpen",        --换炮层打开
    "tryLimitGun",        --体验限时炮台
}

function GuideManager:init()
    self:initData()
    self.guide = require("common/BeginnerGuide/BeginnerGuide").create(require("luaconfig/GuideConfig"))

end

function GuideManager:clearData()
    self:initData()
    self.guide:clear()
    self.guide = require("common/BeginnerGuide/BeginnerGuide").create(require("luaconfig/GuideConfig"))
end


function GuideManager:initData()
    self.curPlayType = nil
    self.curStep = nil
    self.onFun = nil
    self.keyList = nil 
    self.isWait = false
    self.useData = {}
    self.curKey = nil
end

function GuideManager:onStartPlayStep(playType,data)
    if self.curPlayType == playType then
        return 
    end
    self.curPlayType = playType
    self.curStepData = GuideManager.CUR_PLAY_TYPE[self.curPlayType]
    self.onFun = handler(self,self[self.curStepData.FUN])
    self.keyList = GuideManager[self.curStepData.DEF]
    self.curKey = self.keyList[1]
    self.isWait = true
    self.useData = data
end

function GuideManager:onPlayStep(key,data)
    print("-----------GuideManager--------onPlayStep-----key="..key)
    if self.isWait == false then
        return 
    end
    local keyList = self.keyList
    local fun = self.onFun
    if self.curKey == nil or self.curKey ~= key then
        return
    end
    for k,v in ipairs(keyList) do
        if v == key then
            fun(key,data)
            break
        end
    end

end

function GuideManager:LimitGunStep(key,data)
    self.isWait = false
    print("-----------GuideManager--------LimitGunStep-----key="..key)
    if "NewbieTask_LimitGun" == key then
        local fun = function ( ... )
            self:onLimitGunTouch("touchGet",data)
        end
        local node  = data.node
        -- local constant = require("common/BeginnerGuide/BeginnerGuide").COMPONENT;
        -- local pos = node.btn_draw:getParent():convertToWorldSpace(cc.p(node.btn_draw:getPositionX(), node.btn_draw:getPositionY()));
        -- local guideTab = {
        --     {stepId = 1, components = {{type = constant.SWALLOW, args = {pos = pos, size = cc.size(100, 30)}}, 
        --                                 {type = constant.POINT, args = {pos = pos, size = cc.size(100, 30), parent = node, file = "common/BeginnerGuide/Logic/ExperienceBattery", func = "test"}}}},

        --     {stepId = 2, components = {{type = constant.SWALLOW, args = {pos = cc.p(480, 320), size = cc.size(100, 100)}}, 
        --                                 {type = constant.POINT, args = {pos = cc.p(480, 320), size = cc.size(100, 100)}}}},
        -- }
        
        -- self.guide:playStep(guideTab)
    elseif "prop_fly_end" == key then
        local propId = data.propId
        print("------propId="..propId.."----useData.propId="..self.useData.propId)
        if tonumber(propId) ~= tonumber(self.useData.propId) then
            self.isWait = true
            return 
        end
        local fun = function ( ... )
            self:onLimitGunTouch("touchOpenGun",data)
        end
        local playerSelf =  FishGI.gameScene.playerManager:getMyData()
        local cannon = playerSelf.cannon
        local pos = playerSelf:getCannonPos()
        local size  = cannon:getGunViewSize()
        local args = {
                node = cannon.spr_circle, 
                nodeInfo = {
                    scale = cc.p(cannon:getScaleX()+0.1, cannon:getScaleY()+0.1)
                },
                func = fun
            }
        self.guide:start(args)

    elseif "GunOpen" == key then
        local fun = function ( ... )
            self:onLimitGunTouch("touchChangeGunBtn",data)
        end
        local node  = data.node
        local pos,size = node:getBtnViewData("btn_changecannon")
        local args = {
                    node = node.btn_changecannon,
                    nodeInfo = {
                        scale = cc.p(node:getScaleX(), node:getScaleY())
                    },
                    func = fun
                }
        self.guide:nextStep(args)

    elseif "changeGunLayerOpen" == key then
        local fun = function ( ... )
            self:onLimitGunTouch("touchTryGun",data)
        end
        local scaleX_,scaleY_,scaleMin_  = FishGF.getCurScale()
        local node  = data.node
        local par = data.parent
        local pos,size = FishGF.getWordPosAndSizeByNode(node)
        local args = {
                node = node, 
                nodeInfo = {
                    scale = cc.p(par:getScaleX()+0.1, par:getScaleY()+0.2)
                },
                func = fun
            }
        self.guide:nextStep(args)

    elseif "tryLimitGun" == key then
        self:clearData()
    end

end

function GuideManager:onLimitGunTouch(key,data)
    self.isWait = true
    if "touchGet" == key then
        self.curKey = "prop_fly_end"
        data.node:onClickDraw(data.node)

    elseif "touchOpenGun" == key then
        self.curKey = "GunOpen"
        local playerSelf =  FishGI.gameScene.playerManager:getMyData()
        local cannon = playerSelf.cannon
        cannon.uiCannonChange:setIsOpen(true)

    elseif "touchChangeGunBtn" == key then
        self.curKey = "changeGunLayerOpen"
        local itemData = FishGI.GameTableData:getItemTable(self.useData.propId)
        local uiSelectCannon = FishGF.getLayerByName("uiSelectCannon")
        uiSelectCannon:showLayer(itemData.use_outlook)
    elseif "touchTryGun" == key then
        self.curKey = "tryLimitGun"
        --发送消息
        FishGI.gameScene.net:sendUsePropCannon(0,self.useData.propId)
    end
    

end

return GuideManager;
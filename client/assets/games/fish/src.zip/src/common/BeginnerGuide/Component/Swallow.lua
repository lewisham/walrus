local Swallow = class("Swallow", require("common/BeginnerGuide/Component/Component"));

function Swallow.create()
    local obj = Swallow.new();
    obj:init();
    return obj;
end

function Swallow:init()
    local constant = require("common/BeginnerGuide/BeginnerGuide").COMPONENT;
    Swallow.super.init(self, constant.SWALLOW)
end

function Swallow:createCircle()
    
end

function Swallow:doComponent(args)
    Swallow.super.doComponent(self);

    local curScene = cc.Director:getInstance():getRunningScene();
    local winSize = cc.Director:getInstance():getWinSize();
    local swallowLayer = ccui.Button:createInstance();
    swallowLayer:addTouchEventListener(handler(self, self.swallowCallback));
    swallowLayer:setPosition(cc.p(winSize.width/2, winSize.height/2))
    swallowLayer:setScale9Enabled(true);
    swallowLayer:setSwallowTouches(true);
    swallowLayer:setContentSize(cc.size(winSize.width, winSize.height));
    swallowLayer:setColor(cc.c3b(110, 110, 110));
    swallowLayer:setTag(18823);

    local layerColor = cc.LayerColor:create(cc.c4b(0, 0, 0, 110));
    layerColor:setContentSize(cc.size(winSize.width, winSize.height));
    layerColor:setPosition(cc.p(0, 0));
    layerColor:setAnchorPoint(cc.p(0, 0));
    layerColor:setTag(18824);

    local stencil = self:createStencil(args.node, args.nodeInfo);

    local clip = cc.ClippingNode:create();
    clip:setAlphaThreshold(0.9);
    clip:setStencil(stencil);
    clip:setInverted(true);
    clip:addChild(layerColor);
    clip:setTag(18824)

    curScene:addChild(swallowLayer, FishCD.ORDER_LOADING-1);
    curScene:addChild(clip, FishCD.ORDER_LOADING-1);
end

function Swallow:swallowCallback(sender, eventName)
    if eventName == ccui.TouchEventType.ended then      
            
    elseif eventName == ccui.TouchEventType.began then
        local clickPos = sender:getTouchBeganPosition();
        local args = {pos = clickPos};
        self:notify(args);
    end
end

function Swallow:createStencil(node, args)
    if node == nil then
        --挖正方形的洞
        local newNode = cc.Node:create();
        local stencil = ccui.ImageView:create("common/layerbg/com_tip_bg.png");
        stencil:setOpacity(0);
        stencil:ignoreContentAdaptWithSize(false)
        if args.pos ~= nil then
            newNode:setPosition(cc.p(args.pos));
        end

        if args.size ~= nil then
            stencil:setContentSize(cc.size(args.size.width, args.size.height));
        end
        newNode:addChild(stencil);
        return newNode;
    else
        --根据节点来挖洞
        local newNode = cc.Node:create();
        local stencil = nil;
        if node:getDescription() == "Button" then
            --传进来的节点是按钮
            local scale9Sprite = node:getRendererNormal();
            local templatePath = scale9Sprite:getSprite():getResourceName();
            stencil = ccui.ImageView:create(templatePath);
        else
            local templatePath = node:getResourceName(); 
            stencil = ccui.ImageView:create(templatePath);
        end
        stencil:setColor(cc.c3b(0,0,0))
        stencil:ignoreContentAdaptWithSize(false)
        local size = node:getContentSize()
        stencil:setContentSize(cc.size(size.width,size.height))

        if args.scale ~= nil then
            stencil:setScaleX(args.scale.x);
            stencil:setScaleY(args.scale.y);
        end

        if args.anchor ~= nil then
            stencil:setAnchorPoint(cc.p(args.anchor));
        end

        local worldPos = cc.p(node:getParent():convertToWorldSpace(cc.p(node:getPositionX(), node:getPositionY())))
        newNode:setPosition(worldPos);
        newNode:addChild(stencil);
        return newNode
    end
end

function Swallow:remove()
    print("component pointer remove")
    Swallow.super.remove(self);
    local curScene = cc.Director:getInstance():getRunningScene();
    curScene:removeChildByTag(18823);
    curScene:removeChildByTag(18824);
end

return Swallow;
--
-- Author: Your Name
-- Date: 2017-04-01 11:20:32
-- 朋友场邀请好友 数据缓存 快捷邀请

local InviteHelper = InviteHelper or {}
local HttpParams= require("common.HttpParams")

local inviteDescStr = nil

--设置 邀请好友规则描述 缓存串
function InviteHelper:setInviteDesc(_inviteDesc)
    inviteDescStr = _inviteDesc
end

--清除 邀请 序列串
function InviteHelper:clear()
    printf(" --- InviteHelper:clear 清除 邀请好友规则描述 缓存串")
    inviteDescStr = nil
end

--邀请 (点击邀请后调用) rulestr。规则字符串 ，roomownernick 房主昵称 可nil。 gamename 游戏名字 可nil
function InviteHelper:inviteFriend(callback, rulestr, roomownernick, gamename)
    inviteDescStr = rulestr or inviteDescStr
    if inviteDescStr == nil or inviteDescStr == "" or inviteDescStr == " " then
        printf("InviteHelper 邀请数据为空")
        return
    end
    if not GameClient then
        printf("InviteHelper game disconnected error ")
        return
    end

    local total = 0
    for i = 1, GameClient.roominfo.playersperdesk do
        if GameClient:GetPlayerByChair(i - 1) then
            total = total + 1
        end
    end
    local strPlayersCnt = ""
    local lackCnt = tonumber(checkint(GameClient.roominfo.playersperdesk) - checkint(total))
    if lackCnt > 0 and checkint(total) > 0 then
        strPlayersCnt = string.format(" 缺%d人", lackCnt)
    end

    roomownernick = roomownernick or "代开房间"
    gamename = gamename or checktable(GameClient.gameinfo).name
    gamename = string.gsub(gamename, "麻将", "")
    local title = gamename .. " 房号:" .. tostring(GameClient.roomkey) .. strPlayersCnt

    local roomkey = GameClient.roomkey
    local url = self:getInviteLink(roomkey, roomownernick, {game = gamename, roomid = GameClient.roominfo.id, gameid = GameClient.gameinfo.id, rule = inviteDescStr})

    FishGI.ShareHelper:doShareWebType(title, gg.UserData:GetInviteIconUrl(), url, 0, callback, inviteDescStr)
end


-- 代开邀请好友 (点击邀请后调用)
function InviteHelper:agentInviteFriend(data, roomownernick, playerscnt)
    assert(data, "data nil error ")
    local roomkey = data.roomkey
    if not roomownernick then
        roomownernick = FishGI.myData.nickName
    end
    local title = data.title
    -- 拼接规则作为分享内容
    local rule = data.rule
    local desc = data.desc

    
    local url = self:getInviteLink(roomkey, roomownernick, {game = data.name, roomid = data.roomid, gameid = data.gameid, rule = rule})
    
    local InviteIconUrl = FishGI.WebUserData:GetInviteIconUrl()
    
    FishGI.ShareHelper:doShareWebType(title,InviteIconUrl,url,0,desc,nil)

end


--  房间号。房间规则。【房主 名称】可空
function InviteHelper:getInviteLink(roomkey, roomownernick, exttable)

    local packagename = Helper.packagescheme
    packagename = "weile263://"
    if device.platform == "ios" then
        packagename = "weile263"
    end

    print("------------------------------packagename="..packagename)
    
    local region = 0
    local params = {
        key = roomkey,
        package = packagename,
        appid = APP_ID,
        channelid = CHANNEL_ID,
        roomowner = roomownernick,
        region = region,
    }
    if exttable and type(exttable) == "table" then --扩展参数表
        table.merge(params, exttable)
    end

    local schemeDomain = FishGI.WebUserData:GetSchemeDomain()
    local url = tostring(schemeDomain) .. "/joinRoom?key=" .. tostring(roomkey) .. "&data=" .. tostring(Helper.Base64Encode(HttpParams:BuildQuery(params)))

    printf("InviteHelper getInviteLink url :%s ", url)
    return url
end


return InviteHelper

--[[
* @brief 图片下载缓存
]]

--下载队列,多个请求存在时,按顺序下载
local downloadlist = {};
--默认路径,决定是在SD卡还是data目录
local cachePath = Helper.GetCachePath()
-- printf("cachePath ---------------"..cachePath)
--assert(Helper.CreateDir(cachePath),"cache folder create error :"..tostring(cachePath))
-- cc.FileUtils:getInstance():createDirectory(cachePath)
-- local cachePath = device.writablePath .. "cache/"
-- printf("cachePath ---------------"..cachePath)
-- Helper.CreateDir("/cache/");
local dllist = {}; --下载列表
local nIndex = 1; --正在下载的索引
local nAddIndex = 0; --添加的索引
local bDownloading = false; --//是否正在下载
local downloadobj;
local ImageDownload = {
    headers_ = "" --下载的附带http请求头
};

--http请求对象,不支持https
local httpClient = CHttpClient:New();
--下载事件回调
local e = httpClient.event;

--下载失败列表,如果下载的文件在这个列表中,则直接跳过
local downloadfailedlst = {};

local function nextIndexAdd_()
    dllist[nIndex] = nil;
    nIndex = nIndex + 1;
end

local function startWith(source, str,case_sensitive)
    assert(source,"StartWith source is nil")
    str= str or ""
    local len = string.len(str)
    if case_sensitive then --大小写敏感
        return string.sub(source, 1, len) == str
    else
        return string.lower(string.sub(source, 1, len)) == string.lower(str)
    end
end

--获取路径或 文件扩展名
local function getFileExt(filename)
    return filename:match(".+%.(%w+)$")
end

--下载完成通知,如果err为nil,则成功,否则err为失败原因
local function onComplete_(err)
    local filename
    if err then
        downloadfailedlst[httpClient.url] = err;
        printf("下载失败,url=" .. httpClient.url .. ",err=" .. err);
    else --//下载成功
        filename = downloadobj.filename
    end

    for k, v in pairs(downloadobj.callback) do
        v(filename, err,downloadobj.tagobj);
    end
    nextIndexAdd_()
    bDownloading = false;
    ImageDownload:StartDownload();
end

function e.OnHttpClose(http, nErrorCode)
    onComplete_("与服务器连接关闭!");
end

function e.OnHttpComplete(http)
    onComplete_();
end

function e.OnHttpError(http, strError)
    onComplete_(strError);
end

-- 下载进度变化
function e.OnHttpDataArrival(http, size, dowanload, speed)
    if downloadobj and downloadobj.onProgressChanged then
        downloadobj.onProgressChanged()
    end
end

function ImageDownload:SetProgressChangeListener(listener)
    self.onProgressChanged=listener
end

--启动下载,这个函数不应该在文件外被调用
function ImageDownload:StartDownload()

    local obj = dllist[nIndex];
    if obj == nil then
        return false;
    end
    bDownloading = true;
    if not httpClient:Start(obj.url, obj.filename, self.headers_) then
        bDownloading = false;
        onComplete_("连接到下载地址失败!");
        nextIndexAdd_()
        return self:StartDownload();
    else
        downloadobj = obj;
        return true;
    end
end

--[[
* @brief 启动下载
* @param url 下载的地址,仅支持http协议,不支持https和ftp
* @param callback 下载回调函数,回调函数原型为
* @param cuspath 自定义下载路径
* @code
	function(filename,err)
		--filename：如果成功,则filename为下载的文件路径,失败则该值为nil
		--err:如果成功,则该值忽略,否则,该值为错误原因
	end
* @endcode
]]
function ImageDownload:Start(url,callback,tagobj,cuspath)
    if startWith(url, "://") then
        url = "http" .. url
    end
    assert(callback ,"ImageDownload callback nil")
    local ext= getFileExt(url) or "tmp"
   -- printf("---  %s, %s ",Helper.sha1(url),ext)
    local fpath=cuspath or cachePath
    local filename = fpath .. Helper.sha1(url) .. "." ..ext;

    if Helper.IsFileExist(filename) then --//文件存在,直接返回
        callback(filename);
        return filename;
    end
    local err = downloadfailedlst[url];
    if err then --//曾经下载过,但是失败了
        printf(url .. "上次下载失败")
        callback(nil, "无效地址：" .. err);
        return;
    end

    local o = dllist.url;
    if o == nil then
        o = {}
        setmetatable(o, self);
        nAddIndex = nAddIndex + 1
        dllist[nAddIndex] = o;
        o.url = url;
        o.index = nAddIndex;
        o.tagobj=tagobj
        o.callback = {};
    end

    table.insert(o.callback, callback);
    o.filename = filename;
    if not bDownloading then
       return self:StartDownload();
    end
end

function ImageDownload:CancelAll()
    if httpClient then
        httpClient:Cancel()
        -- httpClient:Release()
        -- httpClient = nil
    end

    dllist = {}
end



--[[
* @brief 加载网络图片
* @parm url 地址
* @parm image 需要加载资源的控件
]]
function ImageDownload:LoadHttpImageAsyn(url, image, finishcall)
    if (url and string.len(url) > 0) and image then
        if startWith(url, "http") or startWith(url, "://") then --网址
            image:retain();
            self:Start(url, function(path, err)
                if path then
                    image:loadTexture(path);
                    if finishcall then
                        finishcall()
                    end
                end

                if nil ~= finish then
                    finish();
                end
                image:release();
            end);
        else --//直接加载图标
            image:loadTexture(url)
            if finishcall then
                finishcall()
            end
        end
    end
end

return ImageDownload
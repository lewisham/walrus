local config = {
    saig = {
        APP_NAME = "龟兔赛跑",
        APP_ID_android = "368",
        APP_ID_ios = "367",
        APP_ID_windows = "368",
        APP_KEY = "633E848B26EfD1bcD05d48D8AE5f21f2",
        GAME_ID = "366",
        VER = 0,
    },
    fknz = {
        APP_NAME = "疯狂牛仔",
        APP_ID_android = "368",
        APP_ID_ios = "367",
        APP_ID_windows = "368",
        APP_KEY = "633E848B26EfD1bcD05d48D8AE5f21f2",
        GAME_ID = "456",
        VER = 0,
    }
}

return config